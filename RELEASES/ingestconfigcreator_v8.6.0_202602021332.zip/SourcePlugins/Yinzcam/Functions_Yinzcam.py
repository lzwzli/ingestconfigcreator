from Library.FunctionFiles.Functions import *

# ----------------------------------------------------------------
# Feature custom info
# ----------------------------------------------------------------
def fn_feature_custom_info():
    feature_custom_info_fileSource = {}
    feature_custom_info_fileImport = {}
    feature_custom_info = []

    feature_custom_info_fileSource["key"] = "fileSourceDirectory"
    feature_custom_info_fileSource["value"] = "/srv/yinzcamjail/home/yinzcam/SFTP/<client_name>"

    feature_custom_info.append(feature_custom_info_fileSource)

    feature_custom_info_fileImport["key"] = "fileImportMatch"
    feature_custom_info_fileImport["value"] = "*.csv"

    feature_custom_info.append(feature_custom_info_fileImport)

    return feature_custom_info