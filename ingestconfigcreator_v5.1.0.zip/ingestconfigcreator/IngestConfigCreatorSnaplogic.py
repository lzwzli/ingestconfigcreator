import argparse, sys, os
from datetime import datetime
sys.path.append(os.path.join(os.path.dirname(sys.path[0]),f'ingestconfigcreator{os.sep}FlatFile_source'))
sys.path.append(os.path.join(os.path.dirname(sys.path[0]),f'ingestconfigcreator{os.sep}KIP_source'))
sys.path.append(os.path.join(os.path.dirname(sys.path[0]),f'ingestconfigcreator{os.sep}SL_API_source'))
# from IngestConfigCreatorLibrary import *
from IngestConfigCreatorLibrary_Functions import *
from IngestConfigCreatorLibrary_Classes import *
from Functions_FlatFile import *
from Functions_KIP import *
from Functions_SL_API import *
from version import *

def ingestconfigcreator_snaplogic():
    # create TraceLog object
    tracelog = Logger()

    # report version
    tracelog.log(f"Running IngestConfigCreator version {version}. Released {releasedate}.")
    tracelog.log("")

    # try import dependencies
    try:
        import pandas
        import openpyxl
        import numpy
    except ModuleNotFoundError:
        print("Please run 'py setup.py install' to install dependency packages.")
        sys.exit(1)

    # parse arguments
    parser = argparse.ArgumentParser()
    parser.add_argument('--sourcetype', help="source type. FF=Flat File sources / KIP=KIP acquired sources / SLAPI=Snaplogic acquired sources")
    parser.add_argument('--ddfile', help="input path to data dictionary file")
    parser.add_argument('--database', help="database name, i.e. tepperqa")
    parser.add_argument('--client', help="client abbreviation name, i.e. tepper")
    parser.add_argument('--sourcename', help="source name, i.e. dynamics")
    parser.add_argument('--delimiter', help="field delimiter")
    parser.add_argument('--enclosedby', help="character enclosing value")
    parser.add_argument('--copyffoptions', help="additional copy into file format options")
    parser.add_argument('--fileimportmatch', help="non regex pattern to match all files to be imported")
    parser.add_argument('--filedateregex', help="regex pattern to get file date from file name")
    parser.add_argument('--pgpkey', help="pgp key account to decrypt .gpg or .pgp files")
    parser.add_argument('--acqpipeline', help="Snaplogic path to acquire pipeline")
    args = parser.parse_args()

    source_type = args.sourcetype
    client = args.client
    database = args.database
    source_name = args.sourcename
    dd_file = args.ddfile
    copy_ff_options = args.copyffoptions
    delimiter = args.delimiter
    enclosed_by = args.enclosedby
    file_import_match = args.fileimportmatch
    filedate_regex = args.filedateregex
    pgp_key = args.pgpkey
    acq_pl = args.acqpipeline


    # ask for arguments
    # source type
    source_type_list = ['FF', 'KIP', 'SLAPI']
    while source_type not in source_type_list:
        source_type = input("Enter \"FF\" for Flat File source, \"KIP\" for KIP acquire source, \"SLAPI\" for Snaplogic acquire source: ")
    tracelog.append(f"Source Type = {source_type}")

    # client
    while client is None:
        client = input("Enter client abbreviation: ")
    tracelog.append(f"Client = {client}")

    # database
    while database is None:
        database = input("Enter database name: ")
    tracelog.append(f"Database = {database}")

    # source_name
    while source_name is None:
        source_name = input("Enter source name: ")
    tracelog.append(f"Source Name = {source_name}")

    # dd_file
    while dd_file is None:
        print("Select Excel data dictionary file from dialog. Dialog may be hidden behind other windows.")
        dd_file = fileDialog(("Excel", ".xlsx"), "Select Excel data dictionary file")
        # exit if no file provided when user hits cancel
        if dd_file == "":
            tracelog.log("ERROR: No File Selected. Exiting.")
            sys.exit()

    tracelog.log(f"Data Dict. File = {dd_file}")

    # Copy Into File Format Options
    while copy_ff_options is None:
        copy_ff_options = input("[Optional] Enter any custom Copy Into file format options: ")

    if copy_ff_options == "":
        copy_ff_options = None

    tracelog.append(f"Add. Copy Into format options = {copy_ff_options}")

    # Copy Into File Format Options
    while filedate_regex is None:
        if source_type == "KIP":
            filedate_regex = input("[Optional] Enter a custom regex to get file date from file name. Default is '[0-9]{14}': ")
        else:
            filedate_regex = input("[Optional] Enter a custom regex to get file date from file name. Default is '[0-9]{8,12}': ")

    if filedate_regex == "" or filedate_regex == None:
        if source_type == "KIP":
            filedate_regex = '[0-9]{14}'
        else:
            filedate_regex = '[0-9]{8,12}'

    tracelog.append(f"Filedate Regex = {filedate_regex}")

    # process flat file source
    if source_type == "FF" or source_type == "SLAPI":
        # delimiter
        while delimiter is None or delimiter == "":
            delimiter = input("Enter column delimiter character: ")
        tracelog.append(f"Column Delimiter = {delimiter}")

        # enclosed by
        while enclosed_by is None:
            enclosed_by = input("[Optional] Enter character enclosing values: ")

        if enclosed_by == "":
            enclosed_by = None
        tracelog.append(f"Enclosing character = {enclosed_by}")

        # file_import_match
        while file_import_match is None or ("." not in file_import_match):
            file_import_match = input("Enter the pattern to match all files to be imported. Must end with file extension. Not a regex.: ")
        tracelog.append(f"File Import Match = {file_import_match}")

        # ask for pgp key if file_import_match ends with gpg or pgp
        if source_type=="FF" and ".gpg" in file_import_match or ".pgp" in file_import_match:
            while pgp_key is None:
                pgp_key = input("Enter the Snaplogic account to decrypt the input file: ")
            tracelog.append(f"PGP Key = {pgp_key}")

        # acquire pipeline
        if source_type=="SLAPI":
            while acq_pl is None:
                acq_pl = input("Enter Snaplogic path to acquire pipeline: ")
            tracelog.append(f"Acquire Pipeline = {acq_pl}")

        # create command with integrated arguments
        if enclosed_by == None or enclosed_by == 'None':
            cmd = f"python .\\IngestConfigCreator.py --sourcetype {source_type} --client {client} --database {database} --sourcename {source_name} --delimiter '{delimiter}' --copyffoptions \"{copy_ff_options}\" --filedateregex '{filedate_regex}' --enclosedby None --fileimportmatch '{file_import_match}' --ddfile '{dd_file}'"
        else:
            if enclosed_by == '"':
                cmd = f"python .\\IngestConfigCreator.py --sourcetype {source_type} --client {client} --database {database} --sourcename {source_name} --delimiter '{delimiter}' --copyffoptions \"{copy_ff_options}\" --filedateregex '{filedate_regex}' --enclosedby '{enclosed_by}' --fileimportmatch '{file_import_match}' --ddfile '{dd_file}'"
            else:
                cmd = f"python .\\IngestConfigCreator.py --sourcetype {source_type} --client {client} --database {database} --sourcename {source_name} --delimiter '{delimiter}' --copyffoptions \"{copy_ff_options}\" --filedateregex '{filedate_regex}' --enclosedby '{enclosed_by}' --fileimportmatch '{file_import_match}' --ddfile '{dd_file}'"

        if source_type=="FF" and pgp_key != None:
            cmd += f" --pgpkey {pgp_key}"

        if source_type=="SLAPI":
            cmd += f" --acqpipeline {acq_pl}"

        tracelog.log("")
        tracelog.log("Command with arguments:")
        tracelog.log("")
        tracelog.log(cmd)
        tracelog.log("")

        if source_type=="FF":
            # call create config flat file
            create_config_flatfile(source_name, client, database, dd_file, file_import_match, filedate_regex, delimiter, enclosed_by, copy_ff_options, pgp_key, tracelog)

        if source_type=="SLAPI":
            # call create config API
            create_config_sl_api(source_name, client, database, dd_file, file_import_match, filedate_regex, delimiter, enclosed_by, copy_ff_options, acq_pl, tracelog)

    # process KIP source
    elif source_type == "KIP":

        # create command with integrated arguments
        cmd = f"python .\\IngestConfigCreator.py --sourcetype {source_type} --client {client} --database {database} --sourcename {source_name} --copyffoptions {copy_ff_options} --filedateregex '{filedate_regex}' --ddfile '{dd_file}'"

        tracelog.log("")
        tracelog.log("Command with arguments:")
        tracelog.log("")
        tracelog.log(cmd)
        tracelog.log("")

        # call create config KIP
        create_config_KIP(source_name, client, database, dd_file, filedate_regex, copy_ff_options, tracelog)

if __name__ == "__main__":
    ingestconfigcreator_snaplogic()