version = "8.3.6"
releasedate = "2025-09-05"
