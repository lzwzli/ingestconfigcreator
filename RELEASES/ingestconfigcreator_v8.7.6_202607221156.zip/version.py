version = "8.7.6"
releasedate = "2026-07-21"
