from Library.FunctionFiles.Functions import *

# custom_filedate = "TO_CHAR(REGEXP_SUBSTR(REPLACE(SPLIT_PART(SPLIT_PART(METADATA$FILENAME, '/', -1), '-', -1),'-',''), '[0-9]{14}', 1, 1))"
custom_filedate = "TO_CHAR(SUBSTR(REGEXP_SUBSTR(SPLIT_PART(METADATA$FILENAME, '/', -1), '[0-9]{20}'), 1, 14))"

# Create Feature file
def fn_create_feature_file_custom(source_name:str, table_name_list:list, db_folder:str, runlog:object, repo_root_folder:str, client:str):
    print_section(msg="Working on Feature File", runlog=runlog)

    feature_file = {}
    feature_file_append = []

    # create sources key value dictionary per table
    sources_list = []
    transform_groups0_sources = []
    transform_groups1_sources = []
    for table in table_name_list:
        table_name = table[0].lower()
        has_bus_rule = table[1]
        sources_dict = {}
        sources_dict["name"] = table_name
        sources_dict["configurationFileName"] = f"{table_name}.json"
        sources_dict["hasBusinessRules"] = has_bus_rule
        if table_name == "dynamicscontact":
            transform_groups1_sources.append(table_name)
        else:
            transform_groups0_sources.append(table_name)

        sources_list.append(sources_dict)

    feature_file["sources"] = sources_list
    feature_file["featureName"] = source_name.lower()

    # transform groups
    transformGroupsList = []

    transformGroupsDict0 = {}
    transformGroupsDict0["runOrder"] = 0
    transformGroupsDict0["sources"] = transform_groups0_sources
    transformGroupsList.append(transformGroupsDict0)

    transformGroupsDict1 = {}
    transformGroupsDict1["runOrder"] = 1
    transformGroupsDict1["sources"] = transform_groups1_sources
    transformGroupsList.append(transformGroupsDict1)

    feature_file["transformGroups"] = transformGroupsList

    # define output folder and filename
    # filename
    filename = f"{source_name.lower()}.json"

    # output JSON
    writeJSON(filecontent=feature_file, filename=filename, filetype="feature", client=client, source_name=source_name, db_folder=db_folder, repo_root_folder=repo_root_folder, runlog=runlog)

    return