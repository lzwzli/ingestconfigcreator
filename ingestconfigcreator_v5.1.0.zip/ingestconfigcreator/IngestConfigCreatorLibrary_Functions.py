import os, sys, json
from datetime import date
from tkinter import Tk
from tkinter.filedialog import askopenfilename, askdirectory
from IngestConfigCreatorLibrary_Classes import *

indent = " "*3

# ----------------------------------------------------------------
# Functions
# ----------------------------------------------------------------
# file write
def filewrite(folder: str, filename: str, content: str):
    os.makedirs(folder, exist_ok=True)
    filetowrite = open(folder + filename, "w")
    filetowrite.write(content)
    filetowrite.close()


# create all parts of folder path
def create_folders(folderpath: str, tracelog: object):
    os.makedirs(folderpath, exist_ok=True)
    tracelog.log(f"Create folder: {folderpath}")


# console section output
def print_section(msg: str, tracelog: object):
    seperatorline = "-" * 100
    tablefiller = "-" * 5
    tracelog.log("")
    tracelog.log(seperatorline)
    tracelog.log(f"{tablefiller} {msg} {tablefiller}")
    tracelog.log(seperatorline)


# console section details output
def print_section_detail(msg: str, tracelog: object):
    top, bottom = msg.split("\n")
    tracelog.log(top)
    tracelog.log(indent + f"{bottom}")
    tracelog.log("")


# lookup using query
def qlookup(df: object, lookupcol: str, returncol: str):
    returncols = df.query(f'{lookupcol}=="Y"')[returncol].dropna(how='all').tolist()
    returncols += df.query(f'{lookupcol}=="y"')[returncol].dropna(how='all').tolist()
    return returncols


# lookup using index
def ilookup(worksheet: object, lookupcol: str):
    returnidx = worksheet.index[worksheet[lookupcol] == "Y"].tolist()
    returnidx += worksheet.index[worksheet[lookupcol] == "y"].tolist()
    return returnidx


# lookup value of one column and return another
def clookup(worksheet: object, lookupcol: str, lookupval: str, returncol: str):
    returncols = worksheet.query(f'{lookupcol}=="{lookupval}"')[returncol].dropna(how='all').tolist()
    return returncols


# get column array
def getDDLcolumns(column_list: list, ddl_type: str):
    collist = []
    if ddl_type == "import":
        for row in column_list:
            if str(row[2]).upper() == "VARIANT":
                collist.append(f"\t{str(row[1]).upper()}\tVARIANT")
            else:
                collist.append(f"\t{str(row[1]).upper()}\tVARCHAR(16777216)")
    elif ddl_type == "stage":
        for row in column_list:
            collist.append(f"\t{str(row[1]).upper()}\t{str(row[2])}")
    else:
        raise Exception(f"ERROR: DDLtype not valid. Only \"import\" or \"stage\" allowed.")
    return collist


# create phone formatter business rule
def create_phone_formatter_busrule(table_name: str, primary_keys_list: list, phone_columns: list,
                                   platform: str = "Snaplogic"):
    PFQuery = ""
    PFBusRule = {}

    RuleNameKey = "ruleName"
    RunOrderKey = "runOrder"
    RunPositionKey = "runPosition"
    RuleQueryKey = "ruleQuery"

    if platform == "Snaplogic":
        RuleNameKey = RuleNameKey.upper()
        RunOrderKey = RunOrderKey.upper()
        RunPositionKey = RunPositionKey.upper()
        RuleQueryKey = RuleQueryKey.upper()

    PFBusRule[RuleNameKey] = f"{table_name}_1_4"
    PFBusRule[RunOrderKey] = 1
    PFBusRule[RunPositionKey] = 4

    # set phone columns
    ph_set_query = ""
    ph_from_query = ""
    for ph in phone_columns:
        ph_set_query += f" dest.{ph}formatted = sor.{ph}formatted,"
        ph_from_query += f" &database.public.fn_phoneformatter(stg.{ph}) as {ph}formatted,"

    # trim last comma
    ph_set_query = ph_set_query[:-1]
    ph_from_query = ph_from_query[:-1]

    # set primary keys
    pk_string = ""
    pk_join = ""
    pk_sor_where = ""
    pk_set_where = ""
    for pk in primary_keys_list:
        pk_string += f" stg.{pk},"
        pk_join += f" stg.{pk} = imp.{pk} AND "
        pk_sor_where += f" imp.{pk} is not null AND "
        pk_set_where += f" dest.{pk} = sor.{pk} AND "

    # trim trailing characters
    pk_string = pk_string[:-1]
    pk_join = pk_join[:-5]
    pk_sor_where = pk_sor_where[:-5]
    pk_set_where = pk_set_where[:-5]

    PFQuery += f"UPDATE &database.stage.{table_name} dest"
    PFQuery += f" SET"
    PFQuery += ph_set_query
    PFQuery += " FROM (SELECT DISTINCT"
    PFQuery += f"{pk_string}, "
    PFQuery += ph_from_query
    PFQuery += " FROM"
    PFQuery += f" &database.stage.{table_name} stg"
    PFQuery += f" LEFT JOIN"
    PFQuery += f" &database.import.{table_name} imp"
    PFQuery += f" ON{pk_join}"
    PFQuery += f" WHERE"
    PFQuery += pk_sor_where
    PFQuery += ") sor"
    PFQuery += " WHERE"
    PFQuery += pk_set_where
    PFQuery += ";"

    PFBusRule[RuleQueryKey] = PFQuery

    # convert PFBusRule list into JSON
    json_PFBusRule = json.dumps(PFBusRule, indent=2, separators=(", ", ": "))

    return json_PFBusRule


# create unique work table business rule
def create_unique_worktable_busrule(table_name: str, keyhash: str, tracelog: object, platform: str = "Snaplogic"):
    tracelog.log(f"Create unique table for {table_name}")

    RuleNameKey = "ruleName"
    RunOrderKey = "runOrder"
    RunPositionKey = "runPosition"
    RuleQueryKey = "ruleQuery"

    if platform == "Snaplogic":
        RuleNameKey = RuleNameKey.upper()
        RunOrderKey = RunOrderKey.upper()
        RunPositionKey = RunPositionKey.upper()
        RuleQueryKey = RuleQueryKey.upper()

    WTQuery = ""
    WTBusRule = {}

    WTBusRule[RuleNameKey] = f"{table_name}_1_1"
    WTBusRule[RunOrderKey] = 1
    WTBusRule[RunOrderKey] = 1

    WTQuery += f"CREATE OR REPLACE TABLE &database.TMP.{table_name} AS "
    WTQuery += f"SELECT *, {keyhash} "
    WTQuery += f"FROM &database.IMPORT.{table_name}"

    WTBusRule[RuleQueryKey] = WTQuery

    # convert business rule list into JSON
    json_WTBusRule = json.dumps(WTBusRule, indent=2, separators=(", ", ": "))

    return json_WTBusRule


# Create Import DDL
def create_import_DDL(table_name: str, column_list: list, version: str, db_folder: str, tracelog: object):
    # initialize Import DDL Document
    ImportDDL = Document()

    # IMPORT - read column list and create column list for table creation
    importcolumns = getDDLcolumns(column_list, "import")

    # create complete import DDL per table
    ImportDDL.append(
        f"/*{table_name} (Import) grantObjectName={table_name} version={version} generated by config generator */")
    ImportDDL.newline(f"CREATE OR REPLACE TABLE IMPORT.{table_name}")
    ImportDDL.newline("(")
    ImportDDL.newline("\tFILEDATE\tVARCHAR(16777216),")
    ImportDDL.newline("\tFILENAME\tVARCHAR(16777216),")
    ImportDDL.newline("\tFILEROWNUMBER\tNUMBER(38, 0),")
    ImportDDL.newlinelist(importcolumns)
    ImportDDL.newline(");")

    # define output folder and filename
    output_folder = f"{db_folder}data_repo{os.sep}import{os.sep}"
    filename = f"{table_name}.sql"

    # write import DDL to file
    filewrite(output_folder, filename, ImportDDL.out())

    # trace log
    print_section_detail(f"IMPORT DDL - {filename}\nCreated in: {output_folder}", tracelog)


# Create Stage DDL
def create_stage_DDL(table_name: str, column_list: list, PrimayKeys: str, PhoneColumns: list, StandardizationInd: int,
                     RawAudienceInd: int, version: str, db_folder: str, tracelog: object):
    indent = " " * 3

    # STAGE - read column list and datatype and create column list for table creation
    stagecolumns = getDDLcolumns(column_list, "stage")

    # add phone columns to stage column list suffixed with "formatted"
    if RawAudienceInd == "1" and len(PhoneColumns) > 0:
        tracelog.log(f"Phone columns count = {len(PhoneColumns)}")
        tracelog.log(f"{indent}Adding phone columns")
        for phone_cols_key in PhoneColumns:
            stagecolumns.append(f"\t{phone_cols_key.upper()}formatted\tVARCHAR")
    elif RawAudienceInd != "1" and len(PhoneColumns) > 0:
        tracelog.log("Phone columns found, but not creating them as RawAudienceIndicator = 0")

    # if standardizationindicator is true, add standardizationrowid column
    if StandardizationInd == "1":
        stagecolumns.append("\tSTANDARDIZATIONROWID\tNUMBER(38,0)")

    # if rawaudienceindicator is true, add rawaudienceid column
    if RawAudienceInd == "1":
        stagecolumns.append("\tRAWAUDIENCEID\tNUMBER(38,0)")

    # add dwinsert and update date columns
    stagecolumns.append("\tDWINSERTDATE\tTIMESTAMP_LTZ(9)")
    stagecolumns.append("\tDWUPDATEDATE TIMESTAMP_LTZ(9)")

    # initialize Stage DDL document
    StageDDL = Document()

    # create complete import DDL per table
    StageDDL.append(
        f"/*{table_name} (Stage) grantObjectName={table_name} version={version} generated by config generator */")
    StageDDL.newline(f"CREATE TABLE IF NOT EXISTS STAGE.{table_name.upper()}")
    StageDDL.newline("(")
    StageDDL.newline("\tFILEDATE\tVARCHAR(16777216),")
    StageDDL.newline("\tFILENAME\tVARCHAR(16777216),")
    StageDDL.newline("\tFILEROWNUMBER\tNUMBER(38, 0),")

    # add KEYHASH column if primary key contains KEYHASH
    if "KEYHASH" in PrimayKeys:
        StageDDL.newline("\tKEYHASH\tVARCHAR(16777216),")

    StageDDL.newlinelist(stagecolumns)

    if PrimayKeys != "PRIMARY KEY ()":
        StageDDL.append(",")
        StageDDL.newline(f"\t{PrimayKeys}")
    StageDDL.newline(");")

    # define output folder and filename
    output_folder = f"{db_folder}data_repo{os.sep}stage{os.sep}"
    filename = f"{table_name}.sql"

    # write stage DDL to file
    filewrite(output_folder, filename, StageDDL.out())

    # trace log
    print_section_detail(f"STAGE DDL - {filename}\nCreated in: {output_folder}", tracelog)

    # return StageDDL
    return StageDDL.out()


# Create deployment script calls
def create_deployment_scripts(client_name: str, database: str, environment: str, source_name: str, repo_name: str,
                              resources: list):
    script = ""

    if repo_name == "data":
        for res in resources:
            script += f".\\installComponent.ps1 -cn {client_name} -toDB {database} -env {environment} -fr {source_name} -s {res[0]} -c {res[1]} -silent\n"
    elif repo_name == "config":
        for res in resources:
            script += f".\\installConfig.ps1 -cn {client_name} -toDB {database} -env {environment} -fr {source_name} -cf masterimport -s {res[0]} -c {res[1]} -silent\n"
    else:
        raise Exception(f"{repo_name} not recognized.")

    return script


# Get client Snaplogic project name
def get_client_project(client_name: str):
    CICD_Clients = ["NJD", "FLYERS", "RAMS", "TEPPER"]

    client_name = client_name.upper()

    if client_name in CICD_Clients:
        return f"{client_name}_CICD"
    else:
        return client_name


# Create truncate query
def create_truncate_query(table_name: str, db_folder: str, tracelog: object):
    # initialize query document
    query = Document()

    # write query
    query.append(f"TRUNCATE TABLE &database.IMPORT.{table_name.upper()};")

    # define output folder and filename
    output_folder = f"{db_folder}config_repo{os.sep}masterimport{os.sep}sources{os.sep}"
    filename = f"{table_name.lower()}-truncate.sql"

    # write query to file
    filewrite(output_folder, filename, query.out())

    # trace log
    print_section_detail(f"TRUNCATE - {filename}\nCreated in: {output_folder}", tracelog)

    return filename


# Create merge SP
def create_merge_sp(table_name: str, primary_keys_list: list, column_list: list, db_folder: str, tracelog: object,
                    standardization_indicator: str):
    # define SP name
    merge_sp_name = f"stage.sp_mergeinto{table_name.lower()}()"
    # initialize merge query document
    mergesp = Document()

    # write query
    mergesp.append(
        f"/* sp_MergeInto{table_name.upper()} (stage) grantobjectname=stage.sp_MergeInto{table_name.upper()} version=1 */")
    mergesp.newline("!set exit_on_error=true;")
    mergesp.newline("!set variable_substitution=true;")
    mergesp.newline("")
    mergesp.newline(f"CREATE OR REPLACE PROCEDURE {merge_sp_name}")
    mergesp.newline("\treturns varchar not null")
    mergesp.newline("\tlanguage sql")
    mergesp.newline("\texecute as caller")
    mergesp.newline("AS")
    mergesp.newline("$$")
    mergesp.newline("\tBEGIN")

    if standardization_indicator == "1":
        mergesp.newline(
            f"\t\tMERGE INTO &database.STAGE.{table_name.upper()} dest USING &database.TMP.{table_name.upper()}RawAudience sor ON")
    else:
        mergesp.newline(
            f"\t\tMERGE INTO &database.STAGE.{table_name.upper()} dest USING &database.TMP.{table_name.upper()}Unique sor ON")

    for pk in primary_keys_list:
        mergesp.newline(f"\t\t\tlower(dest.{pk}) = lower(sor.{pk}) AND")

    mergesp.trimend(4)
    mergesp.newline("\t\tWHEN MATCHED AND")
    mergesp.newline("\t\t(")

    mergesp.newline(f"\t\t\tNOT EQUAL_NULL(dest.FILEDATE, sor.FILEDATE) OR")
    mergesp.newline(f"\t\t\tNOT EQUAL_NULL(dest.FILENAME, sor.FILENAME) OR")
    mergesp.newline(f"\t\t\tNOT EQUAL_NULL(dest.FILEROWNUMBER, sor.FILEROWNUMBER) OR")

    for row in column_list:
        mergesp.newline(f"\t\t\tNOT EQUAL_NULL(dest.{row[1]}, sor.{row[1]}) OR")

    # add standardizationrowid and rawudienceid column if table is customer source
    if standardization_indicator == "1":
        mergesp.newline("\t\t\tdest.STANDARDIZATIONROWID <> sor.STANDARDIZATIONROWID OR")
        mergesp.newline("\t\t\tdest.RAWAUDIENCEID <> sor.RAWAUDIENCEID")
    else:
        mergesp.trimend(3)

    mergesp.newline("\t\t)")
    mergesp.newline("\t\tTHEN UPDATE SET")

    mergesp.newline(f"\t\t\tdest.FILEDATE = sor.FILEDATE,")
    mergesp.newline(f"\t\t\tdest.FILENAME = sor.FILENAME,")
    mergesp.newline(f"\t\t\tdest.FILEROWNUMBER = IFNULL(sor.FILEROWNUMBER,0),")

    for row in column_list:
        mergesp.newline(f"\t\t\tdest.{row[1]} = sor.{row[1]},")

    # add standardizationrowid and rawudienceid column if table is customer source
    if standardization_indicator == "1":
        mergesp.newline("\t\t\tdest.STANDARDIZATIONROWID = sor.STANDARDIZATIONROWID,")
        mergesp.newline("\t\t\tdest.RAWAUDIENCEID = sor.RAWAUDIENCEID,")

    mergesp.newline("\t\t\tdest.DWUPDATEDATE = now()")
    mergesp.newline("\t\tWHEN NOT MATCHED THEN INSERT")
    mergesp.newline("\t\t(")

    mergesp.newline(f"\t\t\tFILEDATE,")
    mergesp.newline(f"\t\t\tFILENAME,")
    mergesp.newline(f"\t\t\tFILEROWNUMBER,")

    for row in column_list:
        mergesp.newline(f"\t\t\t{row[1]},")

    # add standardizationrowid and rawudienceid column if table is customer source
    if standardization_indicator == "1":
        mergesp.newline("\t\t\tSTANDARDIZATIONROWID,")
        mergesp.newline("\t\t\tRAWAUDIENCEID,")

    mergesp.newline("\t\t\tDWUPDATEDATE,")
    mergesp.newline("\t\t\tDWINSERTDATE")

    mergesp.newline("\t\t) VALUES")
    mergesp.newline("\t\t(")

    mergesp.newline(f"\t\t\tsor.FILEDATE,")
    mergesp.newline(f"\t\t\tsor.FILENAME,")
    mergesp.newline(f"\t\t\tIFNULL(sor.FILEROWNUMBER,0),")

    for row in column_list:
        mergesp.newline(f"\t\t\tsor.{row[1]},")

    # add standardizationrowid and rawudienceid column if table is customer source
    if standardization_indicator == "1":
        mergesp.newline("\t\t\tsor.STANDARDIZATIONROWID,")
        mergesp.newline("\t\t\tsor.RAWAUDIENCEID,")

    mergesp.newline("\t\t\tnow(),")
    mergesp.newline("\t\t\tnow()")
    mergesp.newline("\t\t);")

    mergesp.newline(f"\tRETURN 'FINISHED CALLING STORED PROCEDURE sp_MergeInto{table_name.upper()}';")
    mergesp.newline("\tEND;")
    mergesp.newline("$$;")

    # define output folder and filename
    output_folder = f"{db_folder}data_repo{os.sep}stage{os.sep}"
    filename = f"sp_mergeinto{table_name.lower()}.sql"

    # write query to file
    filewrite(output_folder, filename, mergesp.out())

    # trace log
    print_section_detail(f"MERGEINTO - {filename}\nCreated in: {output_folder}", tracelog)

    return merge_sp_name


# Create unique tmp table SP
def create_unique_sp(table_name: str, primary_keys_list: list, column_list: list, db_folder: str, tracelog: object,
                     standardization_indicator: str):
    # define SP name
    unique_sp_name = f"tmp.sp_createtable{table_name.lower()}unique()"

    # initialize merge query document
    uniquesp = Document()

    # write query
    uniquesp.append(
        f"/* sp_CreateTable{table_name.upper()}Unique (tmp) grantobjectname=tmp.sp_CreateTable{table_name.upper()}Unique version=1 */")
    uniquesp.newline("!set exit_on_error=true;")
    uniquesp.newline("!set variable_substitution=true;")
    uniquesp.newline("")
    uniquesp.newline(f"CREATE OR REPLACE PROCEDURE {unique_sp_name}")
    uniquesp.newline("\treturns varchar not null")
    uniquesp.newline("\tlanguage sql")
    uniquesp.newline("\texecute as caller")
    uniquesp.newline("AS")
    uniquesp.newline("$$")
    uniquesp.newline("\tBEGIN")
    uniquesp.newline(f"\t\tCREATE OR REPLACE TABLE &database.TMP.{table_name.upper()}UNIQUE")
    uniquesp.newline("\t\tAS")
    uniquesp.newline("\t\tSELECT DISTINCT")
    uniquesp.newline("\t\t\tFILEDATE,")
    uniquesp.newline("\t\t\tFILENAME,")
    uniquesp.newline("\t\t\tFILEROWNUMBER,")

    for row in column_list:
        uniquesp.newline(f"\t\t\t{row[1]},")

    if standardization_indicator == "1":
        uniquesp.newline("\t\t\tSTANDARDIZATIONROWID")
    else:
        # remove trailing comma
        uniquesp.trimend(1)

    uniquesp.newline("\t\tFROM")
    uniquesp.newline("\t\t(")

    uniquesp.newline("\t\t\tSELECT")
    uniquesp.newline("\t\t\t\tIFNULL(CAST(FILEDATE AS STRING), '') FILEDATE,")
    uniquesp.newline("\t\t\t\tIFNULL(CAST(FILENAME AS STRING), '') FILENAME,")
    uniquesp.newline("\t\t\t\tCAST(IFNULL(FILEROWNUMBER,0) AS NUMBER(38,0)) FILEROWNUMBER,")

    # add columns and cast to appropriate datatype
    for row in column_list:
        if "TIMESTAMP" in row[2] or "DATETIME" in row[2].upper():
            uniquesp.newline(f"\t\t\t\tCAST(to_datetime({row[1].upper()}) AS TIMESTAMP) {row[1].upper()},")
        elif "NUMBER(38)" in row[2] or "NUMBER(38,0)" in row[2]:
            uniquesp.newline(f"\t\t\t\tCAST(to_integer({row[1].upper()}) AS INT) {row[1].upper()},")
        elif "NUMBER(38,2)" in row[2]:
            uniquesp.newline(f"\t\t\t\tCAST(to_money({row[1].upper()}) AS NUMBER(38,2)) {row[1].upper()},")
        elif "NUMBER" in row[2]:
            uniquesp.newline(f"\t\t\t\tCAST(to_double({row[1].upper()}) AS {row[2]}) {row[1].upper()},")
        elif "BOOLEAN" in row[2]:
            uniquesp.newline(f"\t\t\t\tTRY_TO_BOOLEAN(CAST({row[1].upper()} AS VARCHAR)) {row[1].upper()},")
        elif "VARIANT" in row[2]:
            uniquesp.newline(f"\t\t\t\tCAST({row[1].upper()} AS VARIANT) {row[1].upper()},")
        # treat everything else as varchar
        else:
            uniquesp.newline(f"\t\t\t\tIFNULL(CAST({row[1].upper()} AS STRING), '') {row[1].upper()},")

    if standardization_indicator == "1":
        uniquesp.newline("\t\t\t\tCast(TO_INTEGER(STANDARDIZATIONROWID) AS INT) STANDARDIZATIONROWID,")

    uniquesp.newline("\t\t\t\tROW_NUMBER() OVER")
    uniquesp.newline("\t\t\t\t(PARTITION BY")

    # add primary key columns
    for row in column_list:
        if row[1] in primary_keys_list:
            if "TIMESTAMP" in row[2] or "DATETIME" in row[2].upper():
                uniquesp.newline(f"\t\t\t\t\tLOWER(CAST(to_datetime({row[1].upper()}) AS TIMESTAMP)),")
            elif "NUMBER(38)" in row[2] or "NUMBER(38,0)" in row[2]:
                uniquesp.newline(f"\t\t\t\t\tLOWER(CAST(to_integer({row[1].upper()}) AS INT)),")
            elif "NUMBER(38,2)" in row[2]:
                uniquesp.newline(f"\t\t\t\t\tLOWER(CAST(to_money({row[1].upper()}) AS NUMBER(38,2))),")
            elif "BOOLEAN" in row[2]:
                uniquesp.newline(f"\t\t\t\tTRY_TO_BOOLEAN(CAST({row[1].upper()} AS VARCHAR)) {row[1].upper()},")
            # treat everything else as varchar
            else:
                uniquesp.newline(f"\t\t\t\t\tLOWER(IFNULL(CAST({row[1].upper()} AS STRING), '')),")

    # remove trailing comma
    uniquesp.trimend(1)
    uniquesp.newline("\t\t\t\t\tORDER BY")
    uniquesp.newline("\t\t\t\t\t\tto_datetime(FILEDATE) DESC,")
    uniquesp.newline("\t\t\t\t\t\tFILENAME DESC,")
    uniquesp.newline("\t\t\t\t\t\tFILEROWNUMBER DESC")
    uniquesp.newline("\t\t\t\t) therealrownumber")
    uniquesp.newline("\t\t\tFROM")

    if standardization_indicator == "1":
        uniquesp.newline(f"\t\t\t\t&database.TMP.{table_name.upper()}melissa")
    else:
        uniquesp.newline(f"\t\t\t\t&database.IMPORT.{table_name.upper()}")
    uniquesp.newline("\t\t) a")
    uniquesp.newline("\t\tWHERE a.therealrownumber = 1;")

    uniquesp.newline(f"\tRETURN 'FINISHED CALLING STORED PROCEDURE sp_CreateTable{table_name.upper()}Unique';")
    uniquesp.newline("\tEND;")
    uniquesp.newline("$$;")

    # define output folder and filename
    output_folder = f"{db_folder}data_repo{os.sep}tmp{os.sep}"
    filename = f"sp_createtable{table_name.lower()}unique.sql"

    # write query to file
    filewrite(output_folder, filename, uniquesp.out())

    # trace log
    print_section_detail(f"TMPCREATETABLEUNIQUE - {filename}\nCreated in: {output_folder}", tracelog)

    return unique_sp_name


# Create upgrade script for stage table
def create_schema_drift_script(table_name: str, stage_DDL: str, old_columns: list, db_folder: str, tracelog: object):
    table_name = table_name.upper()

    BackupTableName = f"&database.STAGE.{table_name}_BACKUP_{date.today().strftime('%Y%m%d')}"

    Backup_Table_Query = f"CREATE OR REPLACE TABLE {BackupTableName} CLONE &database.STAGE.{table_name};"
    Create_Stage_Query = stage_DDL.replace("CREATE TABLE IF NOT EXISTS", "CREATE OR REPLACE TABLE").replace(
        f"STAGE.{table_name}", f"STAGE.{table_name} COPY GRANTS")

    Insert_Query = Document()
    Insert_Query.newline(f"INSERT INTO &database.STAGE.{table_name}")
    Insert_Query.newline("(")
    Insert_Query.newline("\tFILEDATE,")
    Insert_Query.newline("\tFILENAME,")
    Insert_Query.newline("\tFILEROWNUMBER,")
    Insert_Query.newline("\tDWINSERTDATE,")
    Insert_Query.newline("\tDWUPDATEDATE,")

    old_columns_indent = []

    for col in old_columns:
        old_columns_indent.append(f"\t{col}")

    Insert_Query.newlinelist(old_columns_indent)
    Insert_Query.newline(")")
    Insert_Query.newline("SELECT")
    Insert_Query.newline("\tFILEDATE,")
    Insert_Query.newline("\tFILENAME,")
    Insert_Query.newline("\tFILEROWNUMBER,")
    Insert_Query.newline("\tDWINSERTDATE,")
    Insert_Query.newline("\tDWUPDATEDATE,")
    Insert_Query.newlinelist(old_columns_indent)
    Insert_Query.newline(f"FROM {BackupTableName};")

    Final_Script = Document()
    Final_Script.append("!set variable_substitution=true;")
    Final_Script.newline("--Backup Stage Table")
    Final_Script.newline(Backup_Table_Query)
    Final_Script.newline("")
    Final_Script.newline("--Create Stage Table")
    Final_Script.newline(Create_Stage_Query)
    Final_Script.newline("")
    Final_Script.newline("--Insert Backup Into Stage Table")
    Final_Script.newline(Insert_Query.out())

    # define output folder and filename
    output_folder = f"{db_folder}data_repo{os.sep}stage{os.sep}upgrade{os.sep}"
    filename = f"Update_stage_{table_name}.sql"

    # write stage DDL to file
    filewrite(output_folder, filename, Final_Script.out())

    # trace log
    print_section_detail(f"STAGE Schema Drift script - {filename}\nCreated in: {output_folder}", tracelog)

    return filename


def validate(input_val: str, values: dict):
    default_val = values[0]
    result = None

    if str(default_val).lower() == "int":
        try:
            result = int(input_val)
        except:
            result = 0
    else:
        for val in values:
            if str(input_val) == str(val):
                result = input_val
            else:
                result = default_val

    return result


# file dialog
def fileDialog(filetype: tuple, title: str):
    tk = Tk()
    tk.withdraw()
    filename = askopenfilename(filetypes=[filetype], title=title)

    return filename


# folder dialog
def folderDialog(title: str):
    tk = Tk()
    tk.withdraw()
    folder = askdirectory(title=title)

    return folder