import sys, os
sys.path.append("..")
from IngestConfigCreatorLibrary_Functions import *
from IngestConfigCreatorLibrary_Classes import *

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Submissions rule 3_0 for historical inserts
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def fn_submissions_bus_rule_3_0(col_list:list, FieldName_col:str, FormName_col:str, FormID_col:str, variant_col:str, FieldID_col:str, FieldLabel_col:str, master_form_id:str):
    select_columns = ""

    # column logic
    # generic column logic
    column_logic = "\n\tMAX("
    column_logic += "\n\t\tIFNULL(("
    column_logic += f"\n\t\t\tCASE WHEN TRIM(LOWER(FSB.value:label::STRING)) IN"
    column_logic += "\n\t\t\t\t(SELECT TRIM(LOWER(<colname>)) FROM &database.STAGE.FORMSTACKFORMQUESTIONS WHERE <colname> IS NOT NULL)"
    column_logic += "\n\t\t\tTHEN IFNULL(FSB.value:value<srcname>::STRING, FSB.value:value::STRING)"
    column_logic += "\n\t\t\tELSE ''"
    column_logic += "\n\t\t\tEND"
    column_logic += "\n\t\t), '')"
    column_logic += "\n\t) AS <colname>,"

    # gender logic
    gender_logic = f"\n\tMAX("
    gender_logic += f"\n\t\tCASE WHEN"
    gender_logic += f"\n\t\t\tLOWER(FSB.value:label::STRING) IN ('gender')"
    gender_logic += f"\n\t\tTHEN IFNULL(FSB.value:value[0]::STRING, FSB.value:value::STRING)"
    gender_logic += f"\n\t\tELSE ''"
    gender_logic += f"\n\t\tEND"
    gender_logic += f"\n\t) AS <colname>"

    # country logic
    country_logic = f"\n\tMAX("
    country_logic += f"\n\t\tCASE WHEN"
    country_logic += f"\n\t\t\tLOWER(FSB.value:label::STRING) IN ('country', 'countrycode')"
    country_logic += f"\n\t\tTHEN IFNULL(FSB.value:value[0]::STRING, FSB.value:value::STRING)"
    country_logic += f"\n\t\tELSE ''"
    country_logic += f"\n\t\tEND"
    country_logic += f"\n\t) AS <colname>"

    # miscdata logic
    miscdata_logic = f"\n\tLISTAGG("
    miscdata_logic += f"\n\t\tCASE WHEN TRIM(LOWER(FSB.value:label::STRING)) IN"
    miscdata_logic += "\n\t\t\t\t(SELECT TRIM(LOWER(MISCDATA)) FROM &database.STAGE.FORMSTACKFORMQUESTIONS WHERE MISCDATA IS NOT NULL)"

    # for col in col_list:
    #     if col[1].lower() != "id" and col[1].lower() != "formname" and col[1].lower() != "formid" and col[1].lower() != "miscdata":
    #         miscdata_logic += f"\n\t\t\tSELECT TRIM(LOWER({col[1]})) AS MISCQUESTIONS FROM &database.STAGE.FORMSTACKFORMQUESTIONS WHERE {col[1]} IS NOT NULL"
    #         miscdata_logic += "\n\t\t\tUNION"
    #
    # miscdata_logic = miscdata_logic[:-9]

    # miscdata_logic += f"\n\t\t)"
    miscdata_logic += f"\n\t\tTHEN FDB.{FieldName_col} || ': ' || IFNULL(FSB.value:value[0]::STRING, FSB.value:value::STRING)"
    miscdata_logic += f"\n\t\tELSE NULL"
    miscdata_logic += f"\n\t\tEND"
    miscdata_logic += f"\n\t, ', ') AS MiscData,"

# --------------------------------------------------------------------------------------------

    # MAIN RULE BUILD
    rulequerydoc = Document()
    rulequerydoc.append("INSERT INTO &database.IMPORT.FORMSTACKSUBMISSIONS")
    rulequerydoc.newline("(")
    rulequerydoc.newline("\tFILEDATE,")
    rulequerydoc.newline("\tFILENAME,")
    rulequerydoc.newline("\tFILEROWNUMBER,")

    # generate column list
    for col in col_list:
        rulequerydoc.newline(f"\t{col[1]},")

        if col[1].lower() == "id":
            select_columns += f"\n\tFSB.ID as {col[1]},"
        elif col[1].lower() == "formname":
            select_columns += f"\n\tFDB.{FormName_col} as {col[1]},"
        elif col[1].lower() == "formid":
            select_columns += f"\n\tFDB.{FormID_col} as {col[1]},"
        elif col[1].lower() == "timestamp":
            select_columns += f"\n\tMAX(FSB.timestamp) AS {col[1]},"

        # name and address related fields
        elif col[1].lower() == "firstname" or col[1].lower() == "middlename" or col[1].lower() == "lastname" or "address" in col[1].lower() or col[1].lower() == "city" or col[1].lower() == "state":
            select_columns += column_logic.replace("<srcname>", f":{col[0]}").replace("<colname>", col[1])

        # country
        elif col[1].lower() == "country":
            select_columns += country_logic.replace("<colname>", col[1])

        # gender
        elif col[1].lower() == "gender":
            select_columns += gender_logic.replace("<colname>", col[1])

        # misc data
        elif col[1].lower() == "miscdata":
            select_columns += miscdata_logic

        # everything else
        else:
            select_columns += column_logic.replace("<srcname>", "[0]").replace("<colname>", col[1])

    rulequerydoc.trimend(1)

    rulequerydoc.newline(")")
    rulequerydoc.newline("SELECT")
    rulequerydoc.newline("\tCURRENT_DATE() AS FILEDATE,")
    rulequerydoc.newline("\t1 AS FILENAME,")
    rulequerydoc.newline("\tROW_NUMBER() OVER (PARTITION BY FSB.ID ORDER BY FSB.ID) AS FILEROWNUMBER,")

    rulequerydoc.append(select_columns)

    rulequerydoc.trimend(1)

    rulequerydoc.newline("FROM")
    rulequerydoc.newline("(")
    rulequerydoc.newline("\tSELECT DISTINCT")
    rulequerydoc.newline("\t\tID,")
    rulequerydoc.newline("\t\tvalue,")
    rulequerydoc.newline("\t\ttimestamp,")
    rulequerydoc.newline("\t\tkey")
    rulequerydoc.newline(f"\tFROM &database.IMPORT.FORMSTACKSUBMISSIONSBLOB SB, lateral flatten(input => {variant_col}:data)")
    rulequerydoc.newline(") FSB")
    rulequerydoc.newline("INNER JOIN")
    rulequerydoc.newline("(")
    rulequerydoc.newline("\tSELECT")
    rulequerydoc.newline(f"\t\t{FieldID_col} AS FIELDID,")
    rulequerydoc.newline(f"\t\t{FieldName_col} AS FIELDNAME,")
    rulequerydoc.newline(f"\t\t{FieldLabel_col} AS FIELDLABEL,")
    rulequerydoc.newline(f"\t\t{FormName_col} AS FORMNAME,")
    rulequerydoc.newline(f"\t\t{FormID_col} AS FORMID")
    rulequerydoc.newline("\tFROM &database.STAGE.FORMSTACKFORMDETAILSBLOB")
    rulequerydoc.newline(") FDB")
    rulequerydoc.newline(f"ON FSB.KEY = FDB.{FieldID_col}")
    rulequerydoc.newline("WHERE")
    rulequerydoc.newline(f"\tFSB.{FormID_col} IN (")
    rulequerydoc.newline("\t\tSELECT ID")
    rulequerydoc.newline("\t\tFROM &database.STAGE.FORMSTACKFORMLIST")
    rulequerydoc.newline(f"\t\tWHERE ID <> {master_form_id}")
    rulequerydoc.newline("\t)")
    rulequerydoc.newline("GROUP BY")
    rulequerydoc.newline("\tFSB.ID,")
    rulequerydoc.newline(f"\tFDB.{FormName_col},")
    rulequerydoc.newline(f"\tFDB.{FormID_col}")
    rulequerydoc.newline(f";")

    return rulequerydoc