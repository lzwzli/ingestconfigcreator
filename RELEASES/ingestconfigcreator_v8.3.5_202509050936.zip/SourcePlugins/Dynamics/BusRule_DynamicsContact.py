from Library.FunctionFiles.Functions import *
from SourcePlugins.Dynamics.RawAudienceArchiveColumns import *

def dynamicscontact_busrules(col_list:list, pk:list, rawaud_ind:int, bus_rule_obj:object, db_folder:str, runlog:object):
    output_folder = f"{db_folder}ForReferenceOnly{os.sep}DynamicsContact_BusRules{os.sep}"
    runlog.log("Generate Dynamics Contact Business Rules.")
    runlog.log("")


    if rawaud_ind == "1":
        dynamicscontact_merge_rawaudience_archive(col_list=col_list, pk=pk, bus_rule_obj=bus_rule_obj, output_folder=output_folder, runorder=2, runposition=4)
        dynamicscontact_delete_rawaudience(col_list=col_list, pk=pk, bus_rule_obj=bus_rule_obj, output_folder=output_folder, runorder=3, runposition=4)
        dynamicscontact_merge_archive(col_list=col_list, pk=pk, bus_rule_obj=bus_rule_obj, output_folder=output_folder, runorder=4, runposition=4)
        dynamicscontact_delete_stage(col_list=col_list, pk=pk, bus_rule_obj=bus_rule_obj, output_folder=output_folder, runorder=5, runposition=4)

    return

def dynamicscontact_merge_rawaudience_archive(col_list:list, pk:list, bus_rule_obj:object, output_folder:str, runorder:int=2, runposition:int=4):
    # ----------------------------------------------------------------
    # Rule 2_4
    # ----------------------------------------------------------------
    busrule = {}
    busrule["ruleName"] = f"DynamicsContact_{runorder}_{runposition}"
    busrule["runOrder"] = runorder
    busrule["runPosition"] = runposition

    rulequerydoc = Document()
    rulequerydoc.append("MERGE INTO &database.STAGE.RAWAUDIENCEARCHIVE dest")
    rulequerydoc.newline("USING (")
    rulequerydoc.newline("\tSELECT raw.*")
    rulequerydoc.newline("\tFROM &database.STAGE.DYNAMICSCONTACT dc")
    rulequerydoc.newline("\tLEFT JOIN &database.STAGE.RAWAUDIENCE raw")
    rulequerydoc.newline("\t\tON dc.RAWAUDIENCEID = raw.RAWAUDIENCEID")
    rulequerydoc.newline("\t\tAND LOWER(raw.RAWAUDIENCETABLE) = LOWER('stage.dynamicscontact')")
    rulequerydoc.newline("\tWHERE")
    rulequerydoc.newline("\t\tdc.STATECODE = 1")
    rulequerydoc.newline(") src")
    rulequerydoc.newline("ON dest.RAWAUDIENCEID = src.RAWAUDIENCEID")
    rulequerydoc.newline("WHEN NOT MATCHED THEN INSERT (")

    for col in rawaud_cols:
        rulequerydoc.newline(f"\t{col},")

    rulequerydoc.trimend(1)

    rulequerydoc.newline(")")
    rulequerydoc.newline("VALUES (")

    for col in rawaud_cols:
        rulequerydoc.newline(f"\tsrc.{col},")

    rulequerydoc.trimend(1)

    rulequerydoc.newline(");")

    # write out Rule Query to file
    filewrite(folder=output_folder, filename=f"DYNAMICSCONTACT_{runorder}_{runposition} MERGE RAWAUDIENCEARCHIVE RULE QUERY.sql", content=rulequerydoc.out())

    busrule["ruleQuery"] = rulequerydoc.out_str()

    bus_rule_obj.add_rule(busrule)

    return

def dynamicscontact_delete_rawaudience(col_list: list, pk: list, bus_rule_obj: object, output_folder: str, runorder:int=3, runposition:int=4):
    # ----------------------------------------------------------------
    # Rule 3_4
    # ----------------------------------------------------------------
    busrule = {}
    busrule["ruleName"] = f"DynamicsContact_{runorder}_{runposition}"
    busrule["runOrder"] = runorder
    busrule["runPosition"] = runposition

    rulequerydoc = Document()
    rulequerydoc.append("DELETE FROM &database.STAGE.RAWAUDIENCE")
    rulequerydoc.newline("WHERE RAWAUDIENCEID IN (")
    rulequerydoc.newline("\tSELECT raw.RAWAUDIENCEID")
    rulequerydoc.newline("\tFROM &database.STAGE.DYNAMICSCONTACT dc")
    rulequerydoc.newline("\tINNER JOIN &database.STAGE.RAWAUDIENCE raw")
    rulequerydoc.newline("\t\tON dc.rawaudienceid = raw.rawaudienceid")
    rulequerydoc.newline("\t\tAND LOWER(raw.RAWAUDIENCETABLE) = LOWER('stage.dynamicscontact')")
    rulequerydoc.newline("\tWHERE (")
    rulequerydoc.newline("\t\tdc.STATECODE = 1")
    rulequerydoc.newline("\t);")

    # write out Rule Query to file
    filewrite(folder=output_folder, filename=f"DYNAMICSCONTACT_{runorder}_{runposition} DELETE FROM RAWAUDIENCE RULE QUERY.sql", content=rulequerydoc.out())

    busrule["ruleQuery"] = rulequerydoc.out_str()

    bus_rule_obj.add_rule(busrule)

    return

def dynamicscontact_merge_archive(col_list:list, pk:list, bus_rule_obj:object, output_folder:str, runorder:int=4, runposition:int=4):
    # ----------------------------------------------------------------
    # Rule 4_4
    # ----------------------------------------------------------------
    busrule = {}
    busrule["ruleName"] = f"DynamicsContact_{runorder}_{runposition}"
    busrule["runOrder"] = runorder
    busrule["runPosition"] = runposition

    rulequerydoc = Document()
    rulequerydoc.append("MERGE INTO &database.STAGE.DYNAMICSCONTACTARCHIVE dest")
    rulequerydoc.newline("USING (")
    rulequerydoc.newline("\tSELECT sc.*")
    rulequerydoc.newline("\tFROM &database.STAGE.DYNAMICSCONTACT dc")
    rulequerydoc.newline("\tLEFT JOIN &database.STAGE.RAWAUDIENCE raw")
    rulequerydoc.newline("\t\tON dc.RAWAUDIENCEID = raw.RAWAUDIENCEID")
    rulequerydoc.newline("\t\tAND LOWER(raw.RAWAUDIENCETABLE) = LOWER('stage.dynamicscontact')")
    rulequerydoc.newline("\tWHERE")
    rulequerydoc.newline("\t\tdc.STATECODE = 1")
    rulequerydoc.newline("\t\tAND raw.RAWAUDIENCEID IS NULL")
    rulequerydoc.newline(") src")
    rulequerydoc.newline("ON dest.RAWAUDIENCEID = src.RAWAUDIENCEID")
    rulequerydoc.newline("WHEN NOT MATCHED THEN INSERT (")

    insert_cols = [["", "FILEDATE", "VARCHAR"], ["", "FILENAME", "VARCHAR"], ["", "FILEROWNUMBER", "NUMBER(38,0)"], ["", "DWINSERTDATE", "TIMESTAMP_LTZ(9)"], ["", "DWUPDATEDATE", "TIMESTAMP_LTZ(9)"], ["", "RAWAUDIENCEID", "NUMBER(38,0)"], ["", "STANDARDIZATIONROWID", "VARCHAR"]] + col_list

    for col in insert_cols:
        rulequerydoc.newline(f"\t{col[1]},")

    rulequerydoc.trimend(1)

    rulequerydoc.newline(")")
    rulequerydoc.newline("VALUES (")

    for col in insert_cols:
        rulequerydoc.newline(f"\tsrc.{col[1]},")

    rulequerydoc.trimend(1)

    rulequerydoc.newline(");")

    # write out Rule Query to file
    filewrite(folder=output_folder, filename=f"DYNAMICSCONTACT_{runorder}_{runposition} MERGE DYNAMICSCONTACTARCHIVE RULE QUERY.sql", content=rulequerydoc.out())

    busrule["ruleQuery"] = rulequerydoc.out_str()

    bus_rule_obj.add_rule(busrule)

    return

def dynamicscontact_delete_stage(col_list: list, pk: list, bus_rule_obj: object, output_folder: str, runorder:int=5, runposition:int=4):
    # ----------------------------------------------------------------
    # Rule 5_4
    # ----------------------------------------------------------------
    busrule = {}
    busrule["ruleName"] = f"DynamicsContact_{runorder}_{runposition}"
    busrule["runOrder"] = runorder
    busrule["runPosition"] = runposition

    rulequerydoc = Document()
    rulequerydoc.append("DELETE FROM &database.STAGE.DYNAMICSCONTACT")
    rulequerydoc.newline("WHERE CONTACTID IN (")
    rulequerydoc.newline("\tSELECT dc.CONTACTID")
    rulequerydoc.newline("\tFROM &database.STAGE.DYNAMICSCONTACT dc")
    rulequerydoc.newline("\tLEFT JOIN &database.STAGE.RAWAUDIENCE raw")
    rulequerydoc.newline("\t\tON dc.RAWAUDIENCEID = raw.RAWAUDIENCEID")
    rulequerydoc.newline("\t\tAND LOWER(raw.RAWAUDIENCETABLE) = LOWER('stage.dynamicscontact')")
    rulequerydoc.newline("\tWHERE (")
    rulequerydoc.newline("\t\tdc.STATECODE = 1")
    rulequerydoc.newline("\t\tAND raw.RAWAUDIENCEID IS NULL")
    rulequerydoc.newline("\t\tAND dc.CONTACTID IN (")
    rulequerydoc.newline("\t\t\tSELECT CONTACTID")
    rulequerydoc.newline("\t\t\tFROM &database.STAGE.DYNAMICSCONTACTARCHIVE")
    rulequerydoc.newline("\t\t\tGROUP BY CONTACTID")
    rulequerydoc.newline("\t\t)")
    rulequerydoc.newline("\t);")

    # write out Rule Query to file
    filewrite(folder=output_folder, filename=f"DYNAMICSCONTACT_{runorder}_{runposition} DELETE FROM DYNAMICSCONTACT RULE QUERY.sql", content=rulequerydoc.out())

    busrule["ruleQuery"] = rulequerydoc.out_str()

    bus_rule_obj.add_rule(busrule)

    return