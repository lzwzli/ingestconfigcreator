version = "8.7.5"
releasedate = "2026-06-25"
