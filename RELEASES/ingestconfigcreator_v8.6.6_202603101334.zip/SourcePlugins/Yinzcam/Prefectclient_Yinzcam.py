# ----------------------------------------------------------------
# deploy_config custom
# ----------------------------------------------------------------
def fn_deploy_config_custom(source_name:str, config_dict:dict):
    # override dict values
    tab = "\t\t"
    config_dict["flowObject"] = "yinzcam_flow"
    config_dict["flowModuleName"] = '"yinzcam.py"'
    config_dict["flowPackageName"] = '"prefectshared-yinzcam"'

    return config_dict

# ----------------------------------------------------------------
# block_config custom
# ----------------------------------------------------------------
def fn_block_config_custom(source_name:str, block_dict:dict):
    block_dict["flowName"] = '"yinzcam-flow"'

    return block_dict