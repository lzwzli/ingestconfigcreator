version = "8.5.2"
releasedate = "2025-11-17"
