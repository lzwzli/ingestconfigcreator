import sys, os
sys.path.append("..")
from IngestConfigCreatorLibrary_Functions import *
from IngestConfigCreatorLibrary_Classes import *

# add business rules
def fn_busrules_append(worksheet:object, busrules_obj:object, database_folder:str, tracelog:object):
    tracelog.log("")
    tracelog.log("Adding Fanatics specific business rules")

    # get table name
    table_name = worksheet.table_name()

    # get primary keys
    pk = worksheet.primary_keys()

    # add rules for FanaticsOrderDetails
    if table_name.upper() == "FANATICSORDERDETAILS":
        tracelog.log(f"{indent}Generate FanaticsOrderDetails Rules")
        # rule 1
        busrule = {}
        busrule["RULENAME"] = "FanaticsOrderDetails_1_0"
        busrule["RUNORDER"] = 1
        busrule["RUNPOSITON"] = 0
        busrule["RULEQUERY"] = "TRUNCATE TABLE &database.IMPORT.FANATICSORDERDETAILS;"

        json_busrule = json.dumps(busrule, indent=2, separators=(", ", ": "))

        busrules_obj.add_rule(json_busrule)

        # rule 2
        busrule.clear()

        busrule["RULENAME"] = "FanaticsOrderDetails_2_0"
        busrule["RUNORDER"] = 2
        busrule["RUNPOSITON"] = 0

        rulequery = f"INSERT INTO &database.IMPORT.FANATICSORDERDETAILS "
        rulequery += f"SELECT FILEDATE, FILENAME, FILEROWNUMBER, "

        for key in pk:
            rulequery += f"{key}, "

        rulequery = rulequery[:-2]

        rulequery += f" FROM &database.IMPORT.FANATICSFEEDIMPORT;"

        busrule["RULEQUERY"] = rulequery

        json_busrule = json.dumps(busrule, indent=2, separators=(", ", ": "))

        busrules_obj.add_rule(json_busrule)

        tracelog.log("")
        return

    # add rules for FanaticsUserDetails
    elif table_name.upper() == "FANATICSUSERDETAILS":
        tracelog.log(f"{indent}Generate FanaticsOrderDetails Rules")
        # rule 1
        busrule = {}
        busrule["RULENAME"] = "FanaticsUserDetails_1_0"
        busrule["RUNORDER"] = 1
        busrule["RUNPOSITON"] = 0
        busrule["RULEQUERY"] = "TRUNCATE TABLE &database.IMPORT.FANATICSUSERDETAILS;"

        json_busrule = json.dumps(busrule, indent=2, separators=(", ", ": "))

        busrules_obj.add_rule(json_busrule)

        # rule 2
        busrule.clear()

        busrule["RULENAME"] = "FanaticsUserDetails_2_0"
        busrule["RUNORDER"] = 2
        busrule["RUNPOSITON"] = 0

        rulequery = f"INSERT INTO &database.IMPORT.FANATICSUSERDETAILS "
        rulequery += f"SELECT FILEDATE, FILENAME, FILEROWNUMBER, "

        for key in pk:
            rulequery += f"{key}, "

        rulequery = rulequery[:-2]

        rulequery += f" FROM &database.IMPORT.FANATICSFEEDIMPORT;"

        busrule["RULEQUERY"] = rulequery

        json_busrule = json.dumps(busrule, indent=2, separators=(", ", ": "))

        busrules_obj.add_rule(json_busrule)

        tracelog.log("")
        return

# append sources config
def fn_sources_append(worksheet:object, database_folder:str, sources_obj:object, tracelog:object, isPrefect=0):
    tracelog.log("Running Fanatics specific sources append function")

    # get table name
    if isPrefect == 0:
        table_name = worksheet.table_name()
    else:
        table_name = worksheet.table_name().lower()

    # add RowCountCheckOverride if table is order details or user details
    if table_name.upper() == "FANATICSORDERDETAILS" or table_name.upper() == "FANATICSUSERDETAILS":
        if isPrefect == 0:
            tracelog.log(f"Add ROWCOUNTCHECKOVERRIDE = 1 in {table_name} sources file")
            sources_obj.append("ROWCOUNTCHECKOVERRIDE", 1)
        else:
            tracelog.log(f"Add rowCountCheckOverride = 1 in {table_name} sources file")
            sources_obj.append("rowCountCheckOverride", 1)

    return







