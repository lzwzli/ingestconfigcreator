import sys
sys.path.append('..')
from IngestConfigCreatorLibrary_Functions import *
from IngestConfigCreatorLibrary_Classes import *

# Create FLATTENJSON CTE for use in Flatten SQL Insert query
def flattenjson(table_name, table_name_raw, column_list):
    jsonelements = []
    flattendoc = Document()
    # create JSON elements list
    for col in column_list:
        jsonelements.append(f"\t\traw.JSONDATA:{col[0]}::STRING AS {col[1].upper()}")

    flattendoc.append("\tSELECT")
    flattendoc.newline("\t\traw.FILEDATE,")
    flattendoc.newline("\t\traw.FILENAME,")
    flattendoc.newline("\t\traw.FILEROWNUMBER,")
    flattendoc.newlinelist(jsonelements)
    flattendoc.newline(f"\tFROM &database.IMPORT.{table_name_raw} raw")
    flattendoc.newline("\tWHERE raw.FILENAME NOT IN(")
    flattendoc.newline("\t\tSELECT DISTINCT FILENAME")
    flattendoc.newline(f"\t\tFROM &database.STAGE.{table_name}")
    flattendoc.newline("\t)")

    return flattendoc.out()