import sys
from version import *
from IngestConfigCreatorLegacy import *
from IngestConfigCreatorPrefect import *
from IngestConfigCreatorSnaplogic import *

def ingestconfigcreator():

    # build choice list
    choices = []
    choices.append(["prefect", "Create a Prefect based source ingest resources. Requires:\n   - data dictionary Excel file for the source"])
    choices.append(["snaplogic", "Create a Snaplogic based source ingest resources. Requires:\n   - data dictionary Excel file for the source"])
    choices.append(["legacy", "Create a Snaplogic based source ingest resources but using Transform instead of Flatten. Requires:\n   - data dictionary Excel file for the source"])

    # build prompt list
    chIdx = 1
    promptMenu = []
    prompt = ""
    for ch in choices:
        promptType = ch[0]
        promptText = f"{chIdx}. {ch[1]}"
        promptMenu.append(promptType)

        prompt = f"{prompt}\n{promptText}\n"
        chIdx += 1

    prompt = prompt.lstrip("\n")

    # display prompts
    sep = "=" * 50
    print(sep)
    print("SELECT A DESIRED FUNCTION:")
    print(sep)

    print(prompt)

    userChoice = 99
    while int(userChoice) > len(promptMenu) or int(userChoice) == 0:
        userChoice = input("Enter choice number: ")
        if not userChoice.isnumeric():
            print("Invalid choice")
            userChoice = 99
        elif int(userChoice) > len(promptMenu) or int(userChoice) == 0:
            print("Invalid choice")

    # parse choices
    choiceType = promptMenu[int(userChoice)-1]
    if choiceType == 'prefect':
        ingestconfigcreator_prefect()
    elif choiceType == 'snaplogic':
        ingestconfigcreator_snaplogic()
    elif choiceType == 'legacy':
        ingestconfigcreator_legacy()

if __name__ == "__main__":
    ingestconfigcreator()