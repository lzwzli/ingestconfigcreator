from Library.FunctionFiles.Functions import *
from SourcePlugins.Salesforce.StandardizationColumns import *
from SourcePlugins.Salesforce.RawAudienceArchiveColumns import *

history_select_list = ["ID", "NAME", "BILLINGSTREET", "BILLINGCITY", "BILLINGSTATE", "BILLINGPOSTALCODE", "BILLINGCOUNTRY", "PHONE"]

def salesforceaccount_busrules(col_list:list, pk:list, rawaud_ind:int, bus_rule_obj:object, db_folder:str, runlog:object):
    output_folder = f"{db_folder}ForReferenceOnly{os.sep}SALESFORCEACCOUNT_BusRules{os.sep}"
    runlog.log("Generate Salesforce Account Business Rules.")
    runlog.log("")

    salesforceaccount_update_import(col_list=col_list, pk=pk, bus_rule_obj=bus_rule_obj, output_folder=output_folder, runorder=0, runposition=0)
    if rawaud_ind == "1":
        AddStdMerge = False
        for col_def in col_list:
            if col_def[1].upper == "DW_ACCOUNT_AUDIENCE_ID__C":
                AddStdMerge = True
        if AddStdMerge:
            salesforceaccount_merge_standardization(col_list=col_list, pk=pk, bus_rule_obj=bus_rule_obj, output_folder=output_folder, runorder=1, runposition=0)

        salesforceaccount_merge_rawaudience_archive(col_list=col_list, pk=pk, bus_rule_obj=bus_rule_obj, output_folder=output_folder, runorder=2, runposition=4)
        salesforceaccount_delete_rawaudience(col_list=col_list, pk=pk, bus_rule_obj=bus_rule_obj, output_folder=output_folder, runorder=3, runposition=4)
        salesforceaccount_merge_archive(col_list=col_list, pk=pk, bus_rule_obj=bus_rule_obj, output_folder=output_folder, runorder=4, runposition=4)
        salesforceaccount_delete_stage(col_list=col_list, pk=pk, bus_rule_obj=bus_rule_obj, output_folder=output_folder, runorder=5, runposition=4)

    return

def salesforceaccount_update_import(col_list:list, pk:list, bus_rule_obj:object, output_folder:str, runorder:int=0, runposition:int=0):
    # ----------------------------------------------------------------
    # Rule 0_0
    # ----------------------------------------------------------------
    busrule = {}
    busrule["RULENAME"] = f"SalesforceAccount_{runorder}_{runposition}"
    busrule["RUNORDER"] = runorder
    busrule["RUNPOSITION"] = runposition

    rulequerydoc = Document()
    rulequerydoc.append("UPDATE &database.IMPORT.SALESFORCEACCOUNT dest")
    rulequerydoc.newline("SET dest.BILLINGSTREET = src.NEWBILLINGSTREET")
    rulequerydoc.newline("\tFROM (")
    rulequerydoc.newline("\t\tSELECT")
    rulequerydoc.newline("\t\t\tID,")
    rulequerydoc.newline("\t\t\tBILLINGSTREET,")
    rulequerydoc.newline("\t\t\tREPLACE(REPLACE(REPLACE(REGEXP_REPLACE(BILLINGSTREET,'[0-9]{8,}_[0-9]{1,}\\\\|[0-9]+\\\\|[0-9]+\\\\|',''),'\\n',' '),'\\r',' '),'  ',' ') AS NEWBILLINGSTREET")
    rulequerydoc.newline("\t\tFROM")
    rulequerydoc.newline("\t\t\t&database.IMPORT.SALESFORCEACCOUNT")
    rulequerydoc.newline("\t\tWHERE")
    rulequerydoc.newline("\t\t\tBILLINGSTREET LIKE '%\\n%'")
    rulequerydoc.newline("\t) src")
    rulequerydoc.newline("WHERE")
    rulequerydoc.newline("\tdest.ID = src.ID")
    rulequerydoc.newline(";")

    # write out Rule Query to file
    filewrite(folder=output_folder, filename=f"SALESFORCEACCOUNT_{runorder}_{runposition} UPDATE IMPORT SALESFORCEACCOUNT RULE QUERY.sql", content=rulequerydoc.out())

    busrule["RULEQUERY"] = rulequerydoc.out_str()

    bus_rule_obj.add_rule(busrule)

    return

def salesforceaccount_merge_standardization(col_list:list, pk:list, bus_rule_obj:object, output_folder:str, runorder:int=1, runposition:int=0):
    # ----------------------------------------------------------------
    # Rule 1_0
    # ----------------------------------------------------------------
    busrule = {}
    busrule["RULENAME"] = f"SalesforceAccount_{runorder}_{runposition}"
    busrule["RUNORDER"] = runorder
    busrule["RUNPOSITION"] = runposition

    def select_cols():
        colstring = Document()
        for col in std_cols:
            if col[1].upper() == "RAWPHONE" or col[1].upper() == "PHONENUMBER":
                colstring.newline(f"\t\tCOALESCE(NULLIF(sa.PHONE,''), NULLIF(sa.HOMEPHONE,''), NULLIF(sa.MOBILEPHONE,''), '') AS {col[1]},")
            elif col[0] == "":
                colstring.newline(f"\t\t'' AS {col[1]},")
            elif col[1] == "STANDARDIZATIONDATE" or col[1] == "DWINSERTDATE" or col[1] == "DWUPDATEDATE":
                colstring.newline(f"\t\tCURRENT_TIMESTAMP() AS {col[1]},")
            else:
                colstring.newline(f"\t\tIFNULL(sa.{col[0]},'') AS {col[1]},")

        colstring.trimend(1)
        return colstring.out()

    rulequerydoc = Document()
    rulequerydoc.append("MERGE INTO &database.STAGE.STANDARDIZATION dest USING (")
    rulequerydoc.newline("\tSELECT")
    rulequerydoc.newline(select_cols())
    rulequerydoc.newline("\tFROM &database.IMPORT.SALESFORCEACCOUNT sa")
    rulequerydoc.newline("\t\tINNER JOIN &database.STAGE.SALESFORCEUSER su")
    rulequerydoc.newline("\t\t\tON sa.LASTMODIFIEDBYID = su.ID")
    rulequerydoc.newline("\t\tAND su.USERNAME ILIKE %DATASVC%@KAGR.COM%")
    rulequerydoc.newline("\tLEFT JOIN &database.STAGE.AUDIENCE a")
    rulequerydoc.newline("\t\tON sa.DW_CONTACT_AUDIENCE_ID__C = a.AUDIENCEID::VARCHAR")
    rulequerydoc.newline(") sor")
    rulequerydoc.newline("ON")

    for col in std_pk_cols:
        rulequerydoc.newline(f"LOWER(dest.{col}) = LOWER(sor.{col}) AND")
    rulequerydoc.trimend(4)

    rulequerydoc.newline("WHEN NOT MATCHED THEN INSERT (")

    for col in std_cols:
        rulequerydoc.newline(f"\t{col[1]},")

    rulequerydoc.newline(") VALUES (")

    for col in std_cols:
        rulequerydoc.newline(f"\tsor.{col[1]},")

    rulequerydoc.newline(");")

    # write out Rule Query to file
    filewrite(folder=output_folder, filename=f"SALESFORCEACCOUNT_{runorder}_{runposition} MERGE STAGE STANDARDIZATION RULE QUERY.sql", content=rulequerydoc.out())

    busrule["RULEQUERY"] = rulequerydoc.out_str()

    bus_rule_obj.add_rule(busrule)

    return

def salesforceaccount_merge_archive(col_list:list, pk:list, bus_rule_obj:object, output_folder:str, runorder:int=1, runposition:int=4):
    # ----------------------------------------------------------------
    # Rule 1_4
    # ----------------------------------------------------------------
    busrule = {}
    busrule["RULENAME"] = f"SalesforceAccount_{runorder}_{runposition}"
    busrule["RUNORDER"] = runorder
    busrule["RUNPOSITION"] = runposition

    rulequerydoc = Document()
    rulequerydoc.append("MERGE INTO &database.STAGE.SALESFORCEACCOUNTARCHIVE dest")
    rulequerydoc.newline("USING (")
    rulequerydoc.newline("\tSELECT sa.*")
    rulequerydoc.newline("\tFROM")
    rulequerydoc.newline("\t\t&database.STAGE.SALESFORCEACCOUNT sa")
    rulequerydoc.newline("\tWHERE (")
    rulequerydoc.newline("\t\tLOWER(sa.ISDELETED) = 'true'")
    rulequerydoc.newline("\t\tAND EQUAL_NULL(TRIM(sa.MASTERRECORDID),'')")
    rulequerydoc.newline("\t)")
    rulequerydoc.newline(") src")
    rulequerydoc.newline("ON dest.ID = src.ID")
    rulequerydoc.newline("WHEN NOT MATCHED THEN INSERT (")

    insert_cols = [["", "FILEDATE", "VARCHAR"], ["", "FILENAME", "VARCHAR"], ["", "FILEROWNUMBER", "NUMBER(38,0)"], ["", "DWINSERTDATE", "TIMESTAMP_LTZ(9)"], ["", "DWUPDATEDATE", "TIMESTAMP_LTZ(9)"]] + col_list.tolist()

    for col in insert_cols:
        rulequerydoc.newline(f"\t{col[1]},")

    rulequerydoc.trimend(1)

    rulequerydoc.newline(")")
    rulequerydoc.newline("VALUES (")

    for col in insert_cols:
        rulequerydoc.newline(f"\tsrc.{col[1]},")

    rulequerydoc.trimend(1)

    rulequerydoc.newline(");")

    # write out Rule Query to file
    filewrite(folder=output_folder, filename=f"SALESFORCEACCOUNT_{runorder}_{runposition} MERGE SALESFORCEACCOUNTARCHIVE RULE QUERY.sql", content=rulequerydoc.out())

    busrule["RULEQUERY"] = rulequerydoc.out_str()

    bus_rule_obj.add_rule(busrule)

    return

def salesforceaccount_merge_rawaudience_archive(col_list:list, pk:list, bus_rule_obj:object, output_folder:str, runorder:int=2, runposition:int=4):
    # ----------------------------------------------------------------
    # Rule 2_4
    # ----------------------------------------------------------------
    busrule = {}
    busrule["RULENAME"] = f"SalesforceAccount_{runorder}_{runposition}"
    busrule["RUNORDER"] = runorder
    busrule["RUNPOSITION"] = runposition

    rulequerydoc = Document()
    rulequerydoc.append("MERGE INTO &database.STAGE.RAWAUDIENCEARCHIVE dest")
    rulequerydoc.newline("USING (")
    rulequerydoc.newline("\tSELECT raw.*")
    rulequerydoc.newline("\tFROM &database.STAGE.SALESFORCEACCOUNT sa")
    rulequerydoc.newline("\tLEFT JOIN &database.STAGE.RAWAUDIENCE raw")
    rulequerydoc.newline("\t\tON sa.RAWAUDIENCEID = raw.RAWAUDIENCEID")
    rulequerydoc.newline("\t\tAND LOWER(raw.RAWAUDIENCETABLE) = LOWER('stage.salesforceaccount')")
    rulequerydoc.newline("\tWHERE")
    rulequerydoc.newline("\t\tLOWER(sa.ISDELETED) = 'true'")
    rulequerydoc.newline("\t\tAND EQUAL_NULL(TRIM(sa.MASTERRECORDID),'')")
    rulequerydoc.newline(") src")
    rulequerydoc.newline("ON dest.RAWAUDIENCEID = src.RAWAUDIENCEID")
    rulequerydoc.newline("WHEN NOT MATCHED THEN INSERT (")

    for col in rawaud_cols:
        rulequerydoc.newline(f"\t{col},")

    rulequerydoc.trimend(1)

    rulequerydoc.newline(")")
    rulequerydoc.newline("VALUES (")

    for col in rawaud_cols:
        rulequerydoc.newline(f"\tsrc.{col},")

    rulequerydoc.trimend(1)

    rulequerydoc.newline(");")

    # write out Rule Query to file
    filewrite(folder=output_folder, filename=f"SALESFORCEACCOUNT_{runorder}_{runposition} MERGE RAWAUDIENCEARCHIVE RULE QUERY.sql", content=rulequerydoc.out())

    busrule["RULEQUERY"] = rulequerydoc.out_str()

    bus_rule_obj.add_rule(busrule)

    return

def salesforceaccount_delete_rawaudience(col_list: list, pk: list, bus_rule_obj: object, output_folder: str, runorder:int=3, runposition:int=4):
    # ----------------------------------------------------------------
    # Rule 3_4
    # ----------------------------------------------------------------
    busrule = {}
    busrule["RULENAME"] = f"SALESFORCEACCOUNT_{runorder}_{runposition}"
    busrule["RUNORDER"] = runorder
    busrule["RUNPOSITION"] = runposition

    rulequerydoc = Document()
    rulequerydoc.append("DELETE FROM &database.STAGE.RAWAUDIENCE")
    rulequerydoc.newline("WHERE RAWAUDIENCEID IN (")
    rulequerydoc.newline("\tSELECT raw.RAWAUDIENCEID")
    rulequerydoc.newline("\tFROM &database.STAGE.SALESFORCEACCOUNT sa")
    rulequerydoc.newline("\tINNER JOIN &database.STAGE.RAWAUDIENCE raw")
    rulequerydoc.newline("\t\tON sa.rawaudienceid = raw.rawaudienceid")
    rulequerydoc.newline("\t\tAND LOWER(raw.RAWAUDIENCETABLE) = LOWER('stage.salesforceaccount')")
    rulequerydoc.newline("\tWHERE (")
    rulequerydoc.newline("\t\tLOWER(sa.ISDELETED) = 'true'")
    rulequerydoc.newline("\t\tAND EQUAL_NULL(TRIM(sa.MASTERRECORDID),'')")
    rulequerydoc.newline("\t);")

    # write out Rule Query to file
    filewrite(folder=output_folder, filename=f"SALESFORCEACCOUNT_{runorder}_{runposition} DELETE FROM RAWAUDIENCE RULE QUERY.sql", content=rulequerydoc.out())

    busrule["RULEQUERY"] = rulequerydoc.out_str()

    bus_rule_obj.add_rule(busrule)

    return

def salesforceaccount_delete_stage(col_list: list, pk: list, bus_rule_obj: object, output_folder: str, runorder:int=5, runposition:int=4):
    # ----------------------------------------------------------------
    # Rule 5_4
    # ----------------------------------------------------------------
    busrule = {}
    busrule["RULENAME"] = f"SalesforceAccount_{runorder}_{runposition}"
    busrule["RUNORDER"] = runorder
    busrule["RUNPOSITION"] = runposition

    rulequerydoc = Document()
    rulequerydoc.append("DELETE FROM &database.STAGE.SALESFORCEACCOUNT")
    rulequerydoc.newline("WHERE ID IN (")
    rulequerydoc.newline("\tSELECT")
    rulequerydoc.newline("\t\tsa.ID")
    rulequerydoc.newline("\tFROM")
    rulequerydoc.newline("\t\t&database.STAGE.SALESFORCEACCOUNT sa")
    rulequerydoc.newline("\tWHERE (")
    rulequerydoc.newline("\t\tLOWER(sa.ISDELETED) = 'true'")
    rulequerydoc.newline("\t\tAND EQUAL_NULL(TRIM(sa.MASTERRECORDID),'')")
    rulequerydoc.newline("\t\tAND sa.ID IN (")
    rulequerydoc.newline("\t\t\tSELECT")
    rulequerydoc.newline("\t\t\t\tID")
    rulequerydoc.newline("\t\t\tFROM")
    rulequerydoc.newline("\t\t\t\t&database.STAGE.SALESFORCEACCOUNTARCHIVE")
    rulequerydoc.newline("\t\t\tGROUP BY ID")
    rulequerydoc.newline("\t\t)")
    rulequerydoc.newline("\t);")

    # write out Rule Query to file
    filewrite(folder=output_folder, filename=f"SALESFORCEACCOUNT_{runorder}_{runposition} DELETE FROM SALESFORCEACCOUNT RULE QUERY.sql", content=rulequerydoc.out())

    busrule["RULEQUERY"] = rulequerydoc.out_str()

    bus_rule_obj.add_rule(busrule)

    return