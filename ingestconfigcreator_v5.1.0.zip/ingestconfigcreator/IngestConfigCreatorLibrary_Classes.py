import os, json
import pandas as pd
import IngestConfigCreatorLibrary_Functions as fn

# ----------------------------------------------------------------
# Classes
# ----------------------------------------------------------------
# read table sheet
class SourceTable:
    def __init__(self, workbook:str, worksheet:str, tracelog:object):
        self.tracelog = tracelog
        try:
            self.worksheet = pd.read_excel(workbook, sheet_name=worksheet)
        except:
            raise Exception(f"ERROR: {worksheet} not found. Moving on to next table.")

    def tableinfo(self):
        # initialize variables
        TableInfo = {}

        TableInfoArray = self.worksheet[["TableInfo", "InfoValue"]].dropna(how='all').to_numpy()
        for infoitem in TableInfoArray:
            TableInfo[infoitem[0]] = infoitem[1]

        return TableInfo

    def table_name(self):
        # store table info in variables
        # TableName. Exit loop if TableName not found or if it is empty.
        try:
            TableName = str(self.tableinfo()["TableName"]).strip()
        except:
            self.tracelog.log(f"ERROR: TableName not found in TableInfo section.")
            self.tracelog.log(f"Exiting config creation for {self.worksheet}.")
            self.tracelog.log("")
            TableName = "nan"
            raise Exception

        if TableName == "nan":
            self.tracelog.log(f'ERROR: TableName empty or set to "nan" in TableInfo section.')
            self.tracelog.log(f"Exiting config creation for {self.worksheet}.")
            raise Exception

        return TableName

    def filereceiptcheck(self):
        # FileReceiptCheck
        try:
            FileReceiptCheck = fn.validate(str(self.tableinfo()["FileReceiptCheck"]).strip().replace("nan", "0"),[0,1])
        except:
            self.tracelog.log("WARNING: FileReceiptCheck not found in TableInfo section. Defaulting to 0.")
            self.tracelog.log("")
            FileReceiptCheck = 0

        return FileReceiptCheck

    def threshold(self):
        # Threshold
        try:
            Threshold = fn.validate(str(self.tableinfo()["Threshold"]).strip().replace("nan", "0"),["int"])
        except:
            self.tracelog.log("Threshold not found in TableInfo section. Defaulting to 0.")
            self.tracelog.log("")
            Threshold = 0

        return Threshold

    def standardization_ind(self):
        # StandardizationIndicator
        try:
            StandardizationIndicator = fn.validate(str(self.tableinfo()["StandardizationIndicator"]).strip().replace("nan", "0"),[0,1])
        except:
            self.tracelog.log("WARNING: StandardizationIndicator not found in TableInfo section. Defaulting to 0.")
            self.tracelog.log("")
            StandardizationIndicator = 0

        return StandardizationIndicator

    def standardization_sheet(self):
        StandardizationSheet = ""
        try:
            StandardizationSheet = str(self.tableinfo()["StandardizationSheet"]).strip().replace("nan", "0")
        except:
            StandardizationSheet = str(self.table_name()) + "_STANDARDIZATION"
            self.tracelog.log(f"WARNING: StandardizationSheet not found in TableInfo section. Assuming {StandardizationSheet}.")
            self.tracelog.log("")

        return StandardizationSheet

    def rawaudience_ind(self):
        # RawAudienceIndicator
        try:
            RawAudienceIndicator = fn.validate(str(self.tableinfo()["RawAudienceIndicator"]).strip().replace("nan", "0"),[0,1])
        except:
            self.tracelog.log("WARNING: RawAudienceIndicator not found in TableInfo section. Defaulting to 0.")
            self.tracelog.log("")
            RawAudienceIndicator = 0

        return RawAudienceIndicator

    def rawaudience_sheet(self):
        RawAudienceSheet = ""
        try:
            RawAudienceSheet = str(self.tableinfo()["RawAudienceSheet"]).strip().replace("nan", "0")
        except:
            RawAudienceSheet = str(self.table_name()) + "_RAWAUDIENCE"
            self.tracelog.log(f"WARNING: RawAudienceSheet not found in TableInfo section. Assuming {RawAudienceSheet}.")
            self.tracelog.log("")

        return RawAudienceSheet

    def sourcedate_ind(self):
        # SourceDateIndicator
        try:
            SourceDateIndicator = str(self.tableinfo()["SourceDateIndicator"]).strip().upper().replace("NAN", "")
        except:
            try:
                SourceDateIndicator = str(self.tableinfo()["SourceDate"]).upper().replace("NAN", "")
            except:
                self.tracelog.log(f"ERROR: SourceDateIndicator not found.")
                self.tracelog.log("")
                SourceDateIndicator = ""

        return SourceDateIndicator

    def filesuffixmap(self):
        # FileSuffixMap. Exit loop if not found or empty.
        try:
            FileSuffixMap = str(self.tableinfo()["FileSuffixMap"]).strip()
        except:
            self.tracelog.log(f"ERROR: FileSuffixMap not found in TableInfo section. Exiting config creation for {self.worksheet}")
            self.tracelog.log("")
            raise Exception

        if FileSuffixMap == "nan":
            self.tracelog.log(f'ERROR: FileSuffixMap empty or set to "nan" in TableInfo section.')
            self.tracelog.log(f"Exiting config creation for {self.worksheet}.")
            raise Exception

        return FileSuffixMap

    def filematchtext(self):
        # FileMatchText. Exit loop if not found or empty.
        try:
            FileMatchText = str(self.tableinfo()["FileMatchText"]).strip()
        except:
            self.tracelog.log(f"ERROR: FileMatchText not found in TableInfo section. Exiting config creation for {self.worksheet}")
            self.tracelog.log("")
            raise Exception

        if FileMatchText == "nan":
            self.tracelog.log(f'ERROR: FileMatchText empty or set to "nan" in TableInfo section.')
            self.tracelog.log(f"Exiting config creation for {self.worksheet}.")
            raise Exception

        return FileMatchText

    def create_keyhash(self):
        # Create Keyhash indicator
        try:
            CreateKeyhash = fn.validate(str(self.tableinfo()["CreateKeyhash"]).strip().replace("nan", "0"),[0,1])
            self.tracelog.log(f"CreateKeyhash = {CreateKeyhash} for {self.table_name()}")
        except:
            try:
                CreateKeyhash = fn.validate(str(self.tableinfo()["CreateKeyHash"]).replace("nan", "0"),[0,1])
                self.tracelog.log(f"CreateKeyhash = {CreateKeyhash} for {self.table_name()}")
            except:
                self.tracelog.log("WARNING: CreateKeyhash not found in TableInfo section. Defaulting to 0.")
                self.tracelog.log("")
                CreateKeyhash = 0
                raise Exception

        if CreateKeyhash == "1":
            pk = self.primary_keys()
            keyhash = "SHA2("
            for key in pk:
                keyhash += f"IFNULL(TO_CHAR({key}), '') || '-' ||"
            keyhash[:-10]
            keyhash += ", 512) AS KEYHASH"
        else:
            keyhash = ""

        return CreateKeyhash, keyhash

    def columns(self):
        self.columnsArray = self.worksheet[["SourceColumnName", "ColumnName", "DataType"]].dropna(how='all').to_numpy()
        return self.columnsArray

    def primary_keys(self):
        return fn.qlookup(self.worksheet, "PrimaryKey", "ColumnName")

    def primary_keys_string(self):
        pk_columns = self.primary_keys()

        # generate concatenated Primary Key columns string
        primary_keys = ""
        for pk in pk_columns:
            primary_keys += f"{str(pk).upper()},"

        # strip out command new line character from last row
        primary_keys = primary_keys[:-1]

        # create primary key string for use in Stage DDL
        return primary_keys, f"PRIMARY KEY ({primary_keys})"

    def old_columns(self):
        old_cols=[]
        new_cols = self.new_columns()
        all_cols = self.worksheet["ColumnName"].dropna(how='all').tolist()
        for col in all_cols:
            if col not in new_cols:
                old_cols.append(col)

        return old_cols

    def new_columns(self):
        return fn.qlookup(self.worksheet, "IsNew", "ColumnName")

    def check_schema_drift(self):
        try:
            newcols = self.new_columns()
            oldcols = []
            if len(newcols) > 0:
                oldcols = self.old_columns()
                schemadrift = 1
            else:
                schemadrift = 0
        except Exception as e:
            raise Exception(e)

        return [schemadrift,oldcols]

    def phone_columns(self):
        return fn.qlookup(self.worksheet, "IsPhone", "ColumnName")

    def salesforce_object_name(self):
        # Salesforce Object Name. Exit loop if not found or empty.
        try:
            SalesforceObjectName = str(self.tableinfo()["SalesforceObjectName"]).strip()
        except:
            self.tracelog.log(f"ERROR: SalesforceObjectName not found in TableInfo section. Exiting config creation for {self.worksheet}")
            self.tracelog.log("")
            raise Exception

        if SalesforceObjectName == "nan":
            self.tracelog.log(f'ERROR: SalesforceObjectName empty or set to "nan" in TableInfo section.')
            self.tracelog.log(f"Exiting config creation for {self.worksheet}.")
            raise Exception

        return SalesforceObjectName

# Logger
class Logger:
    def __init__(self):
        self.tracelog_msg = ""
        print(self.tracelog_msg)

    def log(self, msg:str):
        self.tracelog_msg += f"{msg}\n"
        print(self.tracelog_msg)

    def append(self, msg:str):
        self.tracelog_msg += f"{msg}\n"

    def out(self):
        if "Error" in self.tracelog_msg or "ERROR" in self.tracelog_msg:
            self.log("WARNING: Completed with Errors.")
        else:
            self.log("Completed successfully.")

        return self.tracelog_msg

# Document
class Document:
    def __init__(self):
        self.Doc = ""

    def newline(self, str:str):
        self.Doc += f"\n{str}"

    def append(self, str):
        self.Doc += str

    def newlinelist(self, strlist:list):
        # add a new line for each item in list
        for str in strlist:
            self.newline(f"{str},")
        # remove last comma
        self.Doc = self.Doc[:-1]

    def trimend(self, num_char_to_trim:int):
        # remove the last num_char_to_trim characters
        self.Doc = self.Doc[:0-num_char_to_trim]

    # output document string
    def out(self):
        return self.Doc

    # output document string without newline and tabs for use in JSON
    def out_str(self, trimdoublespace=1):
        self.Doc_str = self.Doc
        self.Doc_str = self.Doc_str.replace("\t","")
        self.Doc_str = self.Doc_str.replace("\n"," ")

        if trimdoublespace == 1:
            self.Doc_str = self.Doc_str.replace("  "," ")

        return self.Doc_str

# Standardization Sheet
class StdSheet:
    def __init__(self, workbook:str, worksheet:str, busrule_obj:object, platform:str="Snaplogic"):

        self.busrule_obj = busrule_obj
        self.ddfile = workbook

        self.RuleNameKey = "ruleName"
        self.RunOrderKey = "runOrder"
        self.RunPositionKey = "runPosition"
        self.RuleQueryKey = "ruleQuery"

        if platform == "Snaplogic":
            self.RuleNameKey = self.RuleNameKey.upper()
            self.RunOrderKey = self.RunOrderKey.upper()
            self.RunPositionKey = self.RunPositionKey.upper()
            self.RuleQueryKey = self.RuleQueryKey.upper()

        # store original value
        worksheet_ori = worksheet

        try:
            self.worksheet = pd.read_excel(workbook, sheet_name=worksheet)
        except:
            try:
                worksheet = worksheet.replace("STANDARDIZAION", "Standardization")
                self.worksheet = pd.read_excel(workbook, sheet_name=worksheet)
            except:
                try:
                    worksheet = worksheet.replace("Standardization", "standardization")
                    self.worksheet = pd.read_excel(workbook, sheet_name=worksheet)
                except:
                    raise Exception(f"ERROR: {worksheet_ori} not found. Attempts at other variations also failed. Moving on to next table.")

        # get info key value pairs
        # initialize Info dictionary
        self.Info = {}

        InfoArray = self.worksheet[["InfoKey", "InfoValue"]].dropna(how='all').to_numpy()
        for item in InfoArray:
            self.Info[item[0]] = item[1]

    # get import table value
    def import_table(self):
        ImportTableName = str(self.Info["ImportTableName"]).strip()

        return ImportTableName

    # get stage table value
    def stage_table(self):
        StageTableName = str(self.Info ["StageTableName"]).strip()

        return StageTableName

    # get JoinTable values
    def join_tables(self):
        JoinTableList = []
        JoinKeys = ["B","C","D"]
        for key in JoinKeys:
            try:
                JoinTable = self.Info[f"JoinTable{key}"]
                JoinTableName, JoinTableCondition = JoinTable.split(",")
                JoinTableList.append([key,1,JoinTableName.strip(),JoinTableCondition.strip()])
            except:
                JoinTableList.append([key,0,"",""])

        return JoinTableList

    # get list of standardization fields
    def fields(self):
        fieldsarray = self.worksheet[["Field", "PrimaryField", "SecondaryField", "TertiaryField"]].to_numpy()

        return fieldsarray

    # helper function to check for nan and wrap it with ifnull
    def checknan(self, input:str):
        if input != "nan":
            # if input value has a dot, assume its intentional. Use value as is
            if "." in input:
                col = f"IFNULL({input},'')"
            # otherwise, append with main import table alias A
            else:
                col = f"IFNULL(A.{input},'')"
        else:
            col = f"''"

        return col

    # helper function to check for nan and wrap it with nullif
    def checknan_nullif(self, input:str):
        if input != "nan":
            # if input value has a dot, assume its intentional. Use value as is
            if "." in input:
                col = f"(NULLIF({input},'')"
            # otherwise, append with main import table alias A
            else:
                col = f"NULLIF(A.{input},'')"
        else:
            col = f"NULL"

        return col

    # generate column list
    def columns_string(self):
        fldarr = self.fields()
        select_columns = ""
        fullname = ""
        join_columns = ""
        rownum_columns = "row_number() over (partition by "
        for fld in fldarr:
            # initialize column variable
            col = ''
            # store value of primary column
            col1 = self.checknan_nullif(str(fld[1]))
            # store value of secondary column
            col2 = self.checknan_nullif(str(fld[2]))
            # store value of tertiary column
            col3 = self.checknan_nullif(str(fld[3]))
            # build coalesce query based on column data availability
            # all 3 columns have values
            if col1 != 'NULL' and col2 != 'NULL' and col3 != 'NULL':
                col = f"COALESCE({col1},{col2},{col3},'')"
            # only primary and secondary have values
            elif col1 != 'NULL' and col2 != 'NULL' and col3 == 'NULL':
                col = f"COALESCE({col1},{col2},'')"
            # only primary have values
            elif col1 != 'NULL' and col2 == 'NULL' and col3 == 'NULL':
                col = self.checknan(str(fld[1]))
            # no columns have values
            else:
                col = "''"

            # map columns to column names
            if fld[0] == "RAWEMAIL":
                select_columns += f"\n\t\t{col} as \"EmailAddress\", "
                rownum_columns += f"\n\t\t\tLOWER({col}),"
            elif fld[0] == "RAWPREFIX":
                select_columns += f"\n\t\t{col} as \"RawPrefix\", "
            elif fld[0] == "RAWFIRSTNAME":
                select_columns += f"\n\t\t{col} as \"RawFirstName\", "
                rownum_columns += f"\n\t\t\tLOWER({col}),"

                fullname += f"{col} || "
            elif fld[0] == "RAWMIDDLENAME":
                select_columns += f"\n\t\t{col} as \"RawMiddleName\", "
                rownum_columns += f"\n\t\t\tLOWER({col}),"

                if col == "''":
                    fullname += "' '"
                else:
                    fullname += f"IFNULL(NULLIF(' ' || {col} || ' ','  '),' ')"
            elif fld[0] == "RAWLASTNAME":
                select_columns += f"\n\t\t{col} as \"RawLastName\", "
                rownum_columns += f"\n\t\t\tLOWER({col}),"

                #full name
                fullname += f" || {col}"
                fullname_clause = f"IFNULL({fullname},'')"
                select_columns += f"\n\t\t{fullname_clause} as \"FullName\", "
                rownum_columns += f"\n\t\t\tLOWER({fullname_clause}),"

            elif fld[0] == "RAWSUFFIX":
                select_columns += f"\n\t\t{col} as \"RawSuffix\", "
            elif fld[0] == "RAWCOMPANY":
                select_columns += f"\n\t\t{col} as \"CompanyName\", "
                rownum_columns += f"\n\t\t\tLOWER({col}),"
            elif fld[0] == "RAWADDRESS1":
                select_columns += f"\n\t\t{col} as \"AddressLine1\", "
                rownum_columns += f"\n\t\t\tLOWER({col}),"
            elif fld[0] == "RAWADDRESS2":
                select_columns += f"\n\t\t{col} as \"AddressLine2\", "
                rownum_columns += f"\n\t\t\tLOWER({col}),"
            elif fld[0] == "RAWADDRESS3":
                select_columns += f"\n\t\t{col} as \"AddressLine3\", "
                rownum_columns += f"\n\t\t\tLOWER({col}),"
            elif fld[0] == "RAWCITY":
                select_columns += f"\n\t\t{col} as \"City\", "
                rownum_columns += f"\n\t\t\tLOWER({col}),"
            elif fld[0] == "RAWSTATE":
                select_columns += f"\n\t\t{col} as \"State\", "
                rownum_columns += f"\n\t\t\tLOWER({col}),"
            elif fld[0] == "RAWZIP":
                select_columns += f"\n\t\t{col} as \"PostalCode\", "
                rownum_columns += f"\n\t\t\tLOWER({col}),"
            elif fld[0] == "RAWCOUNTRY":
                select_columns += f"\n\t\t{col} as \"Country\", "
                rownum_columns += f"\n\t\t\tLOWER({col}),"
            elif fld[0] == "RAWPHONE":
                select_columns += f"\n\t\t{col} as \"PhoneNumber\", "
                rownum_columns += f"\n\t\t\tLOWER({col}),"

            # build join columns
            if str(fld[0]) != "nan":
                if str(fld[0])=="RAWFULLNAME":
                    join_columns += f"LOWER({fullname_clause}) = LOWER(IFNULL(std.{fld[0]},'')) \n\t\tAND "
                else:
                    join_columns += f"LOWER({col}) = LOWER(IFNULL(std.{fld[0]},'')) \n\t\tAND "

        join_columns = join_columns[:-8]
        rownum_columns = rownum_columns[:-1]

        rownum_columns += "\n\t\torder by 1 desc) rownumber"

        return select_columns, join_columns, rownum_columns

    # create standardization query for sources file
    def std_query(self):
        # instantiate standardization query document
        queryDoc = Document()

        col_select=["RecordID", "EmailAddress", "RawPrefix", "RawFirstName", "RawMiddleName", "RawLastName", "FullName", "RawSuffix", "CompanyName", "AddressLine1", "AddressLine2", "AddressLine3", "City", "State", "PostalCode", "Country", "PhoneNumber", "StandardizationDate"]
        # get columns string for select, joins and rownum
        select_cols, join_cols, rownum_cols = self.columns_string()

        # get join tables
        join_tables = self.join_tables()
        self.join_clause = ""
        self.join_count = 0
        for table in join_tables:
            if table[1] == 1:
                self.join_clause += f"\tLEFT JOIN &database.{table[2]} {table[0]} ON \n\t\t{table[3]}\n"
                self.join_count += 1

        # start building query document
        queryDoc.append("SELECT")
        queryDoc.newline("\tRoute,")

        # add select columns
        for col in col_select:
            queryDoc.newline(f"\t\"{col}\",")

        # remove trailing comma
        queryDoc.trimend(1)

        queryDoc.newline("FROM")
        queryDoc.newline("(")
        queryDoc.newline("\tSELECT")
        queryDoc.newline("\t\tABS((random() % 5)) Route,")
        queryDoc.newline("\t\tto_char(current_timestamp(),'YYYYMMDDHHMISSFF3') || cast(row_number() over (partition by 1 order by 1) as string) as \"RecordID\",")
        queryDoc.append(f"{select_cols}")
        queryDoc.newline("\t\tto_char(current_timestamp(),'YYYY-MM-DD HH24:MI:SS.FF3') as \"StandardizationDate\", ")
        queryDoc.newline(f"\t\t{rownum_cols}")
        queryDoc.newline(f"\tFROM &database.IMPORT.{str(self.import_table())} A")

        # if there are join tables, add join clause
        if self.join_count > 0:
            queryDoc.newline(self.join_clause)
            queryDoc.trimend(1)

        queryDoc.newline("\tLEFT JOIN &database.STAGE.STANDARDIZATION std ON ")
        queryDoc.newline(f"\t\t{join_cols}")
        queryDoc.newline("\tWHERE std.RAWFIRSTNAME IS NULL")
        queryDoc.newline(") sub")
        queryDoc.newline("WHERE sub.rownumber = 1 &limitCode;")

        return queryDoc

    # create query for standardization business rule
    def busrule_query(self):
        table = str(self.import_table())
        select_cols, join_cols, rownum_cols = self.columns_string()

        # instantiate business rule query document
        queryDoc = Document()

        queryDoc.append(f"CREATE OR REPLACE TABLE &database.TMP.{table}melissa AS")
        queryDoc.newline(f"SELECT A.*, IFNULL(std.standardizationrowid,0) standardizationrowid")
        queryDoc.newline(f"FROM &database.IMPORT.{table} A")

        # if there are join tables, add join clause
        if self.join_count > 0:
            queryDoc.newline(self.join_clause)
            queryDoc.trimend(1)

        queryDoc.newline(f"LEFT JOIN &database.STAGE.STANDARDIZATION std ON ")
        queryDoc.newline(join_cols)
        queryDoc.newline(";")

        # set output string function to not trim double space
        trimdoublespace = 0
        return queryDoc.out_str(trimdoublespace)

    # create standardization business rule
    def create_std_busrule(self):
        table = str(self.import_table())
        StdBusRule = {}
        StdBusRule[self.RuleNameKey] = f"{table}_1_1"
        StdBusRule[self.RunOrderKey] = 1
        StdBusRule[self.RunPositionKey] = 1
        StdBusRule[self.RuleQueryKey] = self.busrule_query()

        # convert bus rule list into JSON
        json_StdBusRule = json.dumps(StdBusRule, indent=2, separators=(", ", ": "))

        # add to business rule object
        self.busrule_obj.add_rule(json_StdBusRule)

# Rawaudience Sheet
class RawAudSheet:
    def __init__(self, workbook:str, worksheet:str, table_name:str, busrule_obj:object, platform:str="Snaplogic"):
        self.table_name = table_name
        self.busrule_obj = busrule_obj

        self.RuleNameKey = "ruleName"
        self.RunOrderKey = "runOrder"
        self.RunPositionKey = "runPosition"
        self.RuleQueryKey = "ruleQuery"

        if platform == "Snaplogic":
            self.RuleNameKey = self.RuleNameKey.upper()
            self.RunOrderKey = self.RunOrderKey.upper()
            self.RunPositionKey = self.RunPositionKey.upper()
            self.RuleQueryKey = self.RuleQueryKey.upper()

        # store original worksheet value
        worksheet_ori = worksheet

        try:
            self.worksheet = pd.read_excel(workbook, sheet_name=worksheet, skiprows=[0])
        except:
            try:
                worksheet = worksheet.replace("RAWAUDIENCE", "RawAudience")
                self.worksheet = pd.read_excel(workbook, sheet_name=worksheet, skiprows=[0])
            except:
                try:
                    worksheet = worksheet.replace("RawAudience", "rawaudience")
                    self.worksheet = pd.read_excel(workbook, sheet_name=worksheet, skiprows=[0])
                except:
                    raise Exception(f"ERROR: {worksheet_ori} not found. Attempts at other variations also failed. Moving on to next table.")

    # helper function to get source value given a raw audience column name
    def src_value(self, raw_audience_col_name:str):
        src_col = self.worksheet.query(f'COLUMN_NAME=="{raw_audience_col_name}"')["SOURCE_VALUE"].tolist()[0]

        return src_col

    # build raw audience query
    def stg_ra_query(self):
        col_list = ["RAWAUDIENCETABLE", "RAWAUDIENCESOURCE", "RAWAUDIENCESUBSOURCE", "SOURCEACCOUNTID", "SOURCEACCOUNTSECONDARYID"]
        col_list_str = ""

        for col in col_list:
            col_list_str += f"{col}, "
        col_list_str = col_list_str[:-2]

        # source id
        src_acc_id = str(self.src_value("SOURCEACCOUNTID"))
        src_acc_id_val = "''"
        if src_acc_id.strip() != "nan":
            src_acc_id_val = f"CAST(src.{src_acc_id} as string)"
        else:
            raise Exception("SOURCEACCOUNTID value empty.")

        # secondary source id
        sec_acc_id = str(self.src_value("SOURCEACCOUNTSECONDARYID"))
        sec_acc_id_val = "''"
        if sec_acc_id != "nan":
            sec_acc_id_val = f"CAST(src.{sec_acc_id} as string)"

        # build query
        query = ""
        query += "INSERT INTO &database.STAGE.RawAudience ("
        query += col_list_str
        query += ")"
        query += " SELECT "
        query += col_list_str
        query += " FROM (SELECT DISTINCT "
        for col in col_list:
            colval = str(self.src_value(col))
            if colval != "nan":
                if colval == src_acc_id:
                    query += f"{src_acc_id_val} as {col}, "
                elif colval == sec_acc_id:
                    query += f"{sec_acc_id_val} as {col}, "
                elif col == "RAWAUDIENCETABLE" or col == "RAWAUDIENCESOURCE" or col == "RAWAUDIENCESUBSOURCE":
                    query += f"'{colval}' as {col}, "
                elif "(" in colval or ")" in colval:
                    query += f"{colval} as {col}, "
                else:
                    query += f"src.{colval} as {col}, "
            else:
                query += f"'' as {col}, "
        query += f"ROW_NUMBER() OVER (PARTITION BY LOWER(CAST(src.{src_acc_id} as string)) ORDER BY LOWER(CAST(src.{src_acc_id} as string)) DESC) rownumber"
        query += f" FROM &database.TMP.{self.table_name}UNIQUE src"
        query += f" LEFT JOIN &database.STAGE.RAWAUDIENCE rawaud"
        query += f" ON LOWER({src_acc_id_val}) = LOWER(rawaud.SOURCEACCOUNTID)"
        query += f" AND LOWER({sec_acc_id_val}) = LOWER(rawaud.SOURCEACCOUNTSECONDARYID)"
        query += f" AND LOWER(rawaud.RAWAUDIENCETABLE) = LOWER('{self.src_value('RAWAUDIENCETABLE')}')"
        query += f" WHERE rawaud.RAWAUDIENCEID IS NULL)rawaud_values"
        query += " WHERE rawaud_values.rownumber = 1;"

        return query

    # create raw audience business rule
    def create_stg_rawaud_busrule(self):

        RABusRule = {}
        RABusRule[self.RuleNameKey] = f"{self.table_name}_1_3"
        RABusRule[self.RunOrderKey] = 1
        RABusRule[self.RunPositionKey] = 3
        RABusRule[self.RuleQueryKey] = self.stg_ra_query()

        # convert bus rule list into JSON
        json_RABusRule = json.dumps(RABusRule, indent=2, separators=(", ", ": "))

        # add to business rules object
        self.busrule_obj.add_rule(json_RABusRule)

    # build temp raw audience table query
    def tmp_ra_query(self):
        # source id
        src_acc_id = str(self.src_value("SOURCEACCOUNTID"))
        src_acc_id_val = "''"
        if src_acc_id != "nan":
            src_acc_id_val = f"CAST(src.{src_acc_id} as string)"

        # secondary source id
        sec_acc_id = str(self.src_value("SOURCEACCOUNTSECONDARYID"))
        sec_acc_id_val = "''"
        if sec_acc_id != "nan":
            sec_acc_id_val = f"CAST(src.{sec_acc_id} as string)"

        # build query
        query = ""
        query += f"CREATE OR REPLACE TABLE &database.TMP.{self.table_name}RawAudience"
        query += " AS SELECT src.*, rawaud.RAWAUDIENCEID"
        query += f" FROM &database.TMP.{self.table_name}UNIQUE src"
        query += f" INNER JOIN &database.STAGE.RAWAUDIENCE rawaud"
        query += f" ON {src_acc_id_val} = rawaud.SOURCEACCOUNTID"
        query += f" AND {sec_acc_id_val} = rawaud.SOURCEACCOUNTSECONDARYID"
        query += f" AND LOWER(rawaud.RAWAUDIENCETABLE) = LOWER('{self.src_value('RAWAUDIENCETABLE')}');"

        return query

    # create temp raw audience table business rule
    def create_tmp_rawaud_busrule(self):
        TMPRABusRule = {}
        TMPRABusRule[self.RuleNameKey] = f"{self.table_name}_2_3"
        TMPRABusRule[self.RunOrderKey] = 2
        TMPRABusRule[self.RunPositionKey] = 3
        TMPRABusRule[self.RuleQueryKey] = self.tmp_ra_query()

        # convert bus rule list into JSON
        json_TMPRABusRule = json.dumps(TMPRABusRule, indent=2, separators=(", ", ": "))

        # add to business rules object
        self.busrule_obj.add_rule(json_TMPRABusRule)

    # helper function to check casing and determine if value should be treated as string or column reference
    def col_or_str(self, input_str:str, table_name:str):
        if input_str == "nan" or input_str == "":
            return "''''"
        elif "(" in input_str or ")" in input_str:
            return input_str
        elif input_str == input_str.upper():
            return f"{table_name}.{input_str}"
        else:
            return f"'{input_str}'"

    # create control rawaudience source query
    def ctrl_ra_src_query(self):
        col_list_all = ["RAWAUDIENCETABLE", "RAWAUDIENCESOURCE", "RAWAUDIENCESUBSOURCE", "SOURCEACCOUNTID", "SOURCEACCOUNTSECONDARYID", "ACCOUNTTYPE", "ORGANIZATION", "MEMBERSHIPLEVEL", "ACCOUNTPIN", "ACCOUNTREPRESENTATIVENAME", "ACCOUNTREPRESENTATIVEPHONE", "SOURCEINSERTDATE", "SOURCEUPDATEDATE", "SALUTATION", "PREFIX", "SUFFIX", "TITLE", "BIRTHDATE", "FIRSTNAME", "MIDDLENAME", "LASTNAME", "GENDER", "METROAREA", "ADDRESS1", "ADDRESS2", "ADDRESS3", "CITY", "STATE", "ZIP", "COUNTRY", "LATITUDE", "LONGITUDE", "DISTANCETOVENUE", "PHONE1", "PHONE2", "PHONE3", "FAXNUMBER", "EMAIL", "EMAIL2", "EMAIL3", "EMAIL4", "CONTACTTYPE"]

        tbl_alias = "stg"
        col_logic_list = {}

        # get SOURCEACCOUNTID value
        src_acc_id = self.col_or_str(str(self.src_value("SOURCEACCOUNTID")), tbl_alias)

        # get SOURCEACCOUNTSECONDARYID value
        src_acc_secid = self.col_or_str(str(self.src_value("SOURCEACCOUNTSECONDARYID")), tbl_alias)

        # create per column logic
        for col in col_list_all:
            # first check if value should be considered string, column name, or expression
            try:
                colval_raw = self.src_value(col)
                colval = self.col_or_str(colval_raw, tbl_alias)
            except:
                colval = "''"

            if col == "ORGANIZATION":
                colval = f"COALESCE(std.COMPANYNAME, {colval}, '')"

            elif col == "SOURCEINSERTDATE":
                colval = f"MIN({colval})"

            elif col == "SOURCEUPDATEDATE":
                colval = f"MAX({colval})"

            elif col == "PREFIX":
                colval = f"COALESCE(std.NAMEPREFIX, {colval}, '')"

            elif col == "SUFFIX":
                colval = f"COALESCE(std.NAMESUFFIX, {colval}, '')"

            elif col == "BIRTHDATE":
                colval = f"COALESCE(NULLIF(TRIM({colval}), ''), '1900-01-01')"

            elif col == "COUNTRY":
                colval = f"CASE WHEN UPPER(COALESCE(std.COUNTRYNAME, {colval})) IN ('UNITED STATES OF AMERICA', 'UNITED STATES', 'US', 'USA', '') THEN 'United States of America' ELSE COALESCE(std.COUNTRYNAME, {colval}) END"

            elif col == "DISTANCETOVENUE":
                colval = f"CASE WHEN std.DISTANCETOVENUE = '5265.00000' THEN '-1.00000' ELSE COALESCE(std.DISTANCETOVENUE, {colval}, '0.00000') END"

            elif col == "FIRSTNAME":
                colval = f"COALESCE(std.NAMEFIRST, {colval}, '')"

            elif col == "MIDDLENAME":
                colval = f"COALESCE(std.NAMEMIDDLE, {colval}, '')"

            elif col == "LASTNAME":
                colval = f"COALESCE(std.NAMELAST, {colval}, '')"

            elif col == "PHONE1":
                colval = f"COALESCE(std.PHONENUMBER, {colval}, '')"

            elif col == "PHONE2" or col == "PHONE3" or col == "FAXNUMBER" or col == "EMAIL2" or col == "EMAIL3" or col == "EMAIL4" or col == "CONTACTTYPE":
                colval = f"COALESCE({colval}, '')"

            elif col == "SALUTATION" or col == "GENDER" or col == "ADDRESS1" or col == "ADDRESS2" or col == "ADDRESS3" or col == "CITY" or col == "STATE" or col == "ZIP" or col == "LATITUDE" or col == "LONGITUDE" or col == "EMAIL":
                colval = f"COALESCE(std.{col}, {colval}, '')"

            else:
                colval = colval

            colval = colval.replace(", ,", ", ")

            # build column list with column alias
            col_logic_list[col] = [col, colval]

            #-------------------------------------------------------------------------------
            # 2023-07-17: commenting this out as it was causing issues.
            # # if source column name is the same as standardization, prefix with SRC_
            # if colval_raw == col:
            #     col_logic_list[col] = [f"SRC_{colval_raw}", colval]
            # else:
            #     col_logic_list[col] = [col, colval]
            # -------------------------------------------------------------------------------

        col_logic_list["STANDARDIZATIONROWID"] = ["STANDARDIZATIONROWID", f"{tbl_alias}.STANDARDIZATIONROWID"]
        col_logic_list["VALIDEMAIL"] = ["VALIDEMAIL","COALESCE(CASE WHEN std.RESULTS ILIKE '%ES01%' THEN 1 ELSE 0 END, 0)"]
        col_logic_list["VALIDADDRESS"] = ["VALIDADDRESS","COALESCE(CASE WHEN std.RESULTS ILIKE '%AS01%' OR std.RESULTS ILIKE '%AS02%' OR std.RESULTS ILIKE '%AS03%' THEN 1 ELSE 0 END, 0)"]
        col_logic_list["VALIDPHONE"] = ["VALIDPHONE","COALESCE(CASE WHEN std.RESULTS ILIKE '%PS01%' OR std.RESULTS ILIKE '%PS02%' THEN 1 ELSE 0 END, 0)"]

        # define row number clause for secondary id
        if src_acc_secid == "''''":
            src_acc_secid_partition = ""
        else:
            src_acc_secid_partition = f" LOWER(CAST({src_acc_secid} as string)),"

        col_logic_list["RN"] = ["RN",f"ROW_NUMBER() OVER (PARTITION BY LOWER(CAST({src_acc_id} as string)),{src_acc_secid_partition} LOWER(CAST({tbl_alias}.STANDARDIZATIONROWID as string)) ORDER BY LOWER(CAST({src_acc_id} as string)),{src_acc_secid_partition} LOWER(CAST({tbl_alias}.STANDARDIZATIONROWID as string)))"]

        # build inner select query
        src_query = Document()
        src_query.append("SELECT * FROM (")
        src_query.newline("\tSELECT DISTINCT")

        for col in col_list_all:
            src_query.newline(f"\t\t{col_logic_list[col][1]} AS {col_logic_list[col][0]},")

        src_query.newline(f"\t\t{col_logic_list['STANDARDIZATIONROWID'][1]} AS {col_logic_list['STANDARDIZATIONROWID'][0]},")
        src_query.newline(f"\t\t{col_logic_list['VALIDEMAIL'][1]} AS {col_logic_list['VALIDEMAIL'][0]},")
        src_query.newline(f"\t\t{col_logic_list['VALIDADDRESS'][1]} AS {col_logic_list['VALIDADDRESS'][0]},")
        src_query.newline(f"\t\t{col_logic_list['VALIDPHONE'][1]} AS {col_logic_list['VALIDPHONE'][0]},")
        src_query.newline(f"\t\t{col_logic_list['RN'][1]} AS {col_logic_list['RN'][0]}")
        src_query.newline(f"\tFROM")
        src_query.newline(f"\t\t&database.STAGE.{self.table_name} {tbl_alias}")
        src_query.newline("\tLEFT JOIN")
        src_query.newline("\t\t&database.STAGE.STANDARDIZATION std")
        src_query.newline(f"\tON")
        src_query.newline(f"\t\tstg.STANDARDIZATIONROWID = std.STANDARDIZATIONROWID")
        src_query.newline("\tGROUP BY")

        # group_special = ["FIRSTNAME", "MIDDLENAME", "LASTNAME", "GENDER", "CITY", "PHONE1", "PHONE2", "PHONE3", "FAX", "EMAIL"]
        group_except_list = ["SOURCEINSERTDATE", "SOURCEUPDATEDATE"]
        for col in col_list_all:
            # if col in group_special:
            col_name = col_logic_list[col][0]
            col_logic = col_logic_list[col][1]
            if col_name in group_except_list:
                src_query = src_query
            elif tbl_alias in col_logic or "std" in col_logic:
                src_query.newline(f"\t\t{col_logic},")
            else:
                src_query.newline(f"\t\t{col_name},")

        src_query.newline(f"\t\t{tbl_alias}.STANDARDIZATIONROWID,")
        src_query.newline(f"\t\tVALIDEMAIL,")
        src_query.newline("\t\tVALIDADDRESS,")
        src_query.newline("\t\tVALIDPHONE")
        src_query.newline("\t) SUB")
        src_query.newline("WHERE SUB.RN = 1;")

        return src_query.out().replace("'","''")

    # create control rawaudience merge query
    def ctrl_ra_merge_query(self):
        # get source query
        src_query = self.ctrl_ra_src_query()

        # column list
        merge_col_list = ["sourcequery", "sourcequeryresulttable", "defaultsortorder", "emailsortorder", "namesortorder", "addresssortorder", "socialsortorder", "phonesortorder"]

        merge_query = Document()

        merge_query.append("MERGE INTO CONTROL.RAWAUDIENCE dest USING")
        merge_query.newline("(")

        merge_query.newline("\tSELECT")
        merge_query.newline(f"\t\t'STAGE.{self.table_name}' AS  rawaudiencetable,")

        for col in merge_col_list:
            if col == "sourcequery":
                merge_query.newline(f"\t\t'{src_query}' AS {col},")
            elif col == "sourcequeryresulttable":
                merge_query.newline(f"\t\t'TMP.RAWAUDIENCE{self.table_name}' AS {col},")
            else:
                merge_query.newline(f"\t\t<{col.upper()}> AS {col},")

        merge_query.trimend(1)

        merge_query.newline(f") src")
        merge_query.newline(f"ON")
        merge_query.newline(f"\tdest.rawaudiencetable = src.rawaudiencetable")
        merge_query.newline(f"WHEN MATCHED AND")

        for col in merge_col_list:
            merge_query.newline(f"\tNOT EQUAL_NULL(dest.{col}, src.{col}) OR")
        merge_query.trimend(3)

        merge_query.newline(f"THEN UPDATE SET")

        for col in merge_col_list:
            merge_query.newline(f"\tdest.{col} = src.{col},")

        merge_query.newline(f"\tdest.dwupdatedate = CURRENT_TIMESTAMP()")
        merge_query.newline(f"WHEN NOT MATCHED THEN")
        merge_query.newline(f"INSERT")
        merge_query.newline("(")
        merge_query.newline(f"\trawaudiencetable,")

        for col in merge_col_list:
            merge_query.newline(f"\t{col},")

        merge_query.newline(f"\tdwinsertdate,")
        merge_query.newline(f"\tdwupdatedate")
        merge_query.newline(")")
        merge_query.newline(f"VALUES")
        merge_query.newline("(")
        merge_query.newline("\tsrc.rawaudiencetable,")

        for col in merge_col_list:
            merge_query.newline(f"\tsrc.{col},")

        merge_query.newline("\tCURRENT_TIMESTAMP(),")
        merge_query.newline("\tCURRENT_TIMESTAMP()")
        merge_query.newline(");")

        return merge_query.out()

    # create control rawaudience file
    def ctrl_ra_file(self, db_folder:str):
        # set output folder
        output_folder = f"{db_folder}{os.sep}data_repo{os.sep}seed_data{os.sep}"

        # get source name
        source_name = self.src_value("RAWAUDIENCESOURCE")

        # get Merge query
        merge_query = self.ctrl_ra_merge_query()

        ra_file = Document()

        ra_file.append(f"/* control.sources inserts for {source_name} version=1 */")
        ra_file.newline("!set variable_substitution=true;")
        ra_file.newline(merge_query)

        fn.filewrite(output_folder,"control-rawaudience.sql",ra_file.out())

        return

    # Create merge to rawaudience SP
    def create_merge_to_rawaudience_sp(self, table_name: str, db_folder: str, tracelog: object):

        column_list = ["RAWAUDIENCETABLE", "RAWAUDIENCESOURCE", "RAWAUDIENCESUBSOURCE", "SOURCEACCOUNTID", "SOURCEACCOUNTSECONDARYID", "ACCOUNTTYPE", "ORGANIZATION", "MEMBERSHIPLEVEL", "ACCOUNTPIN", "ACCOUNTREPRESENTATIVENAME", "ACCOUNTREPRESENTATIVEPHONE", "SOURCEINSERTDATE", "SOURCEUPDATEDATE", "SALUTATION", "PREFIX", "SUFFIX", "TITLE", "BIRTHDATE", "FIRSTNAME", "MIDDLENAME", "LASTNAME", "GENDER", "METROAREA", "ADDRESS1", "ADDRESS2", "ADDRESS3", "CITY", "STATE", "ZIP", "COUNTRY", "LATITUDE", "LONGITUDE", "DISTANCETOVENUE", "PHONE1", "PHONE2", "PHONE3", "FAXNUMBER", "EMAIL", "EMAIL2", "EMAIL3", "EMAIL4", "CONTACTTYPE", "STANDARDIZATIONROWID", "VALIDEMAIL", "VALIDADDRESS", "VALIDPHONE"]
        # define SP name
        merge_sp_name = f"stage.sp_merge{table_name.lower()}intorawaudience()"
        # initialize merge query document
        mergesp = Document()

        # write query
        mergesp.append(f"/* sp_Merge{table_name.upper()}IntoRawAudience (stage) grantobjectname=stage.sp_Merge{table_name.upper()}IntoRawAudience version=1 */")
        mergesp.newline("!set exit_on_error=true;")
        mergesp.newline("!set variable_substitution=true;")
        mergesp.newline("")
        mergesp.newline(f"CREATE OR REPLACE PROCEDURE {merge_sp_name}")
        mergesp.newline("\treturns varchar not null")
        mergesp.newline("\tlanguage sql")
        mergesp.newline("\texecute as caller")
        mergesp.newline("AS")
        mergesp.newline("$$")
        mergesp.newline("\tBEGIN")

        mergesp.newline(f"\t\tMERGE INTO &database.STAGE.RAWAUDIENCE dest USING &database.TMP.RawAudience{table_name.upper()} sor ON")
        mergesp.newline("\t\t\tlower(dest.RAWAUDIENCETABLE) = lower(sor.RAWAUDIENCETABLE)")
        mergesp.newline("\t\t\tAND lower(dest.SOURCEACCOUNTID) = lower(sor.SOURCEACCOUNTID)")
        mergesp.newline("\t\t\tAND lower(dest.SOURCEACCOUNTSECONDARYID) = lower(sor.SOURCEACCOUNTSECONDARYID)")
        mergesp.newline("\t\tWHEN MATCHED AND")
        mergesp.newline("\t\t(")

        for col in column_list:
            mergesp.newline(f"\t\t\tdest.{col} <> sor.{col} OR")

        mergesp.trimend(3)
        mergesp.newline("\t\t)")
        mergesp.newline("\t\tTHEN UPDATE SET")

        for col in column_list:
            mergesp.newline(f"\t\t\tdest.{col} = sor.{col},")

        mergesp.newline("\t\t\tdest.DWUPDATEDATE = now()")
        mergesp.newline("\t\tWHEN NOT MATCHED THEN INSERT")
        mergesp.newline("\t\t(")

        for col in column_list:
            mergesp.newline(f"\t\t\t{col},")

        mergesp.newline("\t\t\tDWUPDATEDATE,")
        mergesp.newline("\t\t\tDWINSERTDATE")

        mergesp.newline("\t\t) VALUES")
        mergesp.newline("\t\t(")

        for col in column_list:
            mergesp.newline(f"\t\t\tsor.{col},")

        mergesp.newline("\t\t\tnow(),")
        mergesp.newline("\t\t\tnow()")
        mergesp.newline("\t\t);")

        mergesp.newline(f"\tRETURN 'FINISHED CALLING STORED PROCEDURE sp_Merge{table_name.upper()}IntoRawAudience';")
        mergesp.newline("\tEND;")
        mergesp.newline("$$;")

        # define output folder and filename
        output_folder = f"{db_folder}data_repo{os.sep}stage{os.sep}"
        filename = f"sp_merge{table_name.lower()}intorawaudience.sql"

        # write query to file
        fn.filewrite(output_folder, filename, mergesp.out())

        # trace log
        fn.print_section_detail(f"MERGEINTO - {filename}\nCreated in: {output_folder}", tracelog)

        return merge_sp_name

    # Create delete orphan from rawaudience SP
    def delete_orphan_from_rawaudience_sp(self, table_name: str, db_folder: str, tracelog: object):

        # define SP name
        delete_sp_name = f"stage.sp_delete{table_name.lower()}orphansfromrawaudience()"
        # initialize merge query document
        deletesp = Document()

        # write query
        deletesp.append(f"/* sp_Delete{table_name.upper()}OrphansFromRawAudience (stage) grantobjectname=stage.sp_Delete{table_name.upper()}OrphansFromRawAudience version=1 */")
        deletesp.newline("!set exit_on_error=true;")
        deletesp.newline("!set variable_substitution=true;")
        deletesp.newline("")
        deletesp.newline(f"CREATE OR REPLACE PROCEDURE {delete_sp_name}")
        deletesp.newline("\treturns varchar not null")
        deletesp.newline("\tlanguage sql")
        deletesp.newline("\texecute as caller")
        deletesp.newline("AS")
        deletesp.newline("$$")
        deletesp.newline("\tBEGIN")

        deletesp.newline("\t\tDELETE FROM &database.STAGE.RAWAUDIENCE TAR")
        deletesp.newline("\t\tUSING (")
        deletesp.newline("\t\t\tSELECT DISTINCT RA.RAWAUDIENCEID")
        deletesp.newline("\t\t\tFROM &database.STAGE.RAWAUDIENCE RA")
        deletesp.newline(f"\t\t\tLEFT JOIN &database.STAGE.{table_name.upper()} RA_SOURCE")
        deletesp.newline("\t\t\t\tON RA.RAWAUDIENCEID = RA_SOURCE.RAWAUDIENCEID")
        deletesp.newline("\t\t\tWHERE")
        deletesp.newline("\t\t\t\tRA_SOURCE.RAWAUDIENCEID IS NULL")
        deletesp.newline(f"\t\t\t\tAND LOWER(RA.RAWAUDIENCETABLE) = 'stage.{table_name.lower()}'")
        deletesp.newline("\t\t) SRC")
        deletesp.newline("\t\tWHERE")
        deletesp.newline("\t\t\tTAR.RAWAUDIENCEID = SRC.RAWAUDIENCEID")
        deletesp.newline("\t\t\tAND TAR.MERGEDELETEFLAG = 'false';")

        deletesp.newline(f"\tRETURN 'FINISHED CALLING STORED PROCEDURE sp_Delete{table_name.upper()}OrphansFromRawAudience';")
        deletesp.newline("\tEND;")
        deletesp.newline("$$;")

        # define output folder and filename
        output_folder = f"{db_folder}data_repo{os.sep}stage{os.sep}"
        filename = f"sp_delete{table_name.lower()}orphansfromrawaudience.sql"

        # write query to file
        fn.filewrite(output_folder, filename, deletesp.out())

        # trace log
        fn.print_section_detail(f"DELETE ORPHANS - {filename}\nCreated in: {output_folder}", tracelog)

        return delete_sp_name

    # Create rawaudience sources file
    def rawaudience_sources(self, table_name: str, db_folder: str, tracelog: object):

        ra_src = {}
        ra_src["name"] = f"{table_name.upper()}RawAudience"
        ra_src["createHistoryIndicator"] = None
        ra_src["deletesIndicator"] = None
        ra_src["deleteFromSourceSql"] = f"CALL &database.STAGE.sp_Delete{table_name.upper()}OrphansFromRawAudience()"
        ra_src["destinationTable"] = None
        ra_src["destinationTableUnique"] = None
        ra_src["importSql"] = None
        ra_src["isStandardizationSource"] = None
        ra_src["mergeDestinationTable"] = None
        ra_src["mergeToStageSql"] = f"CALL &database.STAGE.sp_Merge{table_name.upper()}IntoRawAudience()"
        ra_src["rawaudienceIndicator"] = None
        ra_src["rowCountCheckOverride"] = None
        ra_src["truncateLoadDestinationTable"] = None
        ra_src["uniqueTableCreateSql"] = None
        ra_src["historyTableCreateSql"] = None

        # convert bus rule list into JSON
        json_ra_src = json.dumps(ra_src, indent=2, separators=(", ", ": "))

        # define output folder and filename
        output_folder = f"{db_folder}config_repo{os.sep}rawaudience{os.sep}sources{os.sep}"
        filename = f"{table_name.lower()}rawaudience.json"

        # write query to file
        fn.filewrite(output_folder, filename, json_ra_src)

        # trace log
        fn.print_section_detail(f"SOURCES - {filename}\nCreated in: {output_folder}", tracelog)

# Business Rule file
class BusRules:
    def __init__(self):
        self.BRDoc = Document()
        self.br_array = []
        self.BRDoc.append("[")
        self.hasrules = 0

    def add_rule(self, rule_json:str):
        self.br_array.append(rule_json)
        self.hasrules = 1

    def out(self, table_name:str, db_folder:str, tracelog:object, isPrefect=0):
        if self.hasrules == 1:
            for br in self.br_array:
                self.BRDoc.newline(f"{br},")

            self.BRDoc.trimend(1)
            self.BRDoc.newline("]")

            # define output folder and filename
            output_folder = f"{db_folder}config_repo{os.sep}masterimport{os.sep}businessrules{os.sep}"
            if isPrefect == 0:
                filename = f"{table_name}-BUSRULES.JSON"
            else:
                filename = f"{table_name.lower()}.json"

            # write sources json to file
            fn.filewrite(output_folder, filename, self.BRDoc.out())

            # trace log
            fn.print_section_detail(f"BUSINESS RULES - {filename}\nCreated in: {output_folder}", tracelog)

        return self.hasrules

# Sources file
class Sources:
    def __init__(self):
        self.src_data = {}
        self.sources_append = []
        self.sources_replace = []

    # Create Sources File
    def create_sources(self, source_name:str, table_name:str, primary_keys:str, file_receipt_check:int, raw_audience_indicator:int, source_date_indicator:str, standardization_indicator:int, standardization_query:str, copyinto_filename:str, threshold:int, db_folder:str, tracelog:object):
        # define base key value pairs
        self.src_data["NAME"] = table_name
        self.src_data["SOURCEID"] = 1
        self.src_data["CATEGORY"] = source_name.capitalize()
        self.src_data["DESTINATIONTABLE"] = f"IMPORT.{table_name}"
        self.src_data["DESTINATIONTABLEUNIQUE"] = f"TMP.{table_name}UNIQUE"
        self.src_data["FILERECEIPTCHECK"] = file_receipt_check
        self.src_data["IMPORT_SQL"] = copyinto_filename
        self.src_data["MERGEDESTINATIONTABLE"] = f"STAGE.{table_name}"
        self.src_data["PRIMARYKEYCOLUMNS"] = primary_keys
        self.src_data["RAWAUDIENCEINDICATOR"] = raw_audience_indicator
        self.src_data["SOURCEDATEINDICATOR"] = source_date_indicator
        self.src_data["STANDARDIZATIONINDICATOR"] = standardization_indicator

        # add STANDARDIZATIONQUERY if StandardizationIndicator is 1
        if standardization_indicator == "1":
            self.src_data["STANDARDIZATIONQUERY"] = standardization_query

        self.src_data["TRUNCATETURNOFFSELECTOR"] = 0
        self.src_data["THRESHOLD"] = threshold
        self.src_data["UNIQUESORT"] = "to_datetime(FileDate) desc, FileName desc, FileRowNumber desc"

        # append additional keys from appendkeyslist
        for key in self.sources_append:
            if key[0] == "STAGE_SQL":
                sql_list = str(key[1]).split(",")
                sql_list = [x.strip() for x in sql_list]
                self.src_data[key[0]] = sql_list
            else:
                self.src_data[key[0]] = key[1]

        # replace keys from replace list
        for key in self.sources_replace:
            self.src_data[key[0]] = key[1]

        # put sources object in an array
        src_data_array = [self.src_data]

        # convert sources object array into JSON
        json_src_data = json.dumps(src_data_array, indent=2, separators=(", ", ": "))

        # define output folder and filename
        output_folder = f"{db_folder}config_repo{os.sep}masterimport{os.sep}sources{os.sep}"

        # add API suffix if source is Archtics to match current naming convention
        if source_name.upper() == "ARCHTICS":
            filename = f"{table_name}_API.JSON"
        else:
            filename = f"{table_name}.JSON"

        # write sources json to file
        fn.filewrite(output_folder, filename, json_src_data)

        # trace log
        fn.print_section_detail(f"SOURCES - {filename}\nCreated in: {output_folder}", tracelog)

        return filename

    # Create Sources File
    def create_sources_prefect(self, source_name: str, table_name: str, primary_keys: str, raw_audience_indicator: int, standardization_indicator: int, standardization_query_filename: str, copyinto_filename: str, threshold: int, db_folder: str, tracelog: object):
        # define base key value pairs
        self.src_data["name"] = table_name.lower()
        self.src_data["createHistoryIndicator"] = False
        self.src_data["deletesIndicator"] = False
        self.src_data["deleteFromSourceSql"] = None
        self.src_data["destinationTable"] = f"import.{table_name.lower()}"
        self.src_data["destinationTableUnique"] = f"tmp.{table_name.lower()}unique"

        # define getLastDateProperties values
        getLastDateProperties = {}
        getLastDateProperties["daysBack"] = 0
        getLastDateProperties["lastDateColumn"] = ""
        getLastDateProperties["refresh"] = 0
        getLastDateProperties["schema"] = "stage"
        getLastDateProperties["seasonYearIndicator"] = 0
        getLastDateProperties["whereClause"] = ""
        getLastDateProperties["tableName"] = table_name.lower()

        self.src_data["getLastDateIndicator"] = False
        self.src_data["getLastDateProperties"] = getLastDateProperties

        # define importSql values
        importSql = []

        importSql.append({"sortOrder": 0, "sqlFileName": f"{table_name.lower()}-truncate.sql", "saveResults": False})

        # if there is no copy into file, don't add copy into reference in import sql
        if copyinto_filename != "":
            importSql.append({"sortOrder": 1, "sqlFileName": copyinto_filename, "saveResults": False})

        self.src_data["historyTableCreateSql"] = None
        self.src_data["importSql"] = importSql

        # set raw_audience_indicator to boolean
        raw_audience_indicator_bool = False
        if raw_audience_indicator == "1":
            raw_audience_indicator_bool = True
        else:
            raw_audience_indicator_bool = False

        self.src_data["isRawAudienceSource"] = raw_audience_indicator_bool

        # set standardization_indicator to boolean
        standardization_indicator_bool = False
        if standardization_indicator == "1":
            standardization_indicator_bool = True
        else:
            standardization_indicator_bool = False

        self.src_data["isStandardizationSource"] = standardization_indicator_bool

        if standardization_indicator == "1":
            melissaProperties = {}

            melissaProperties["standardizationtablename"] = f"tmp.{table_name.lower()}_standardization"
            melissaProperties["standardizationquery"] = standardization_query_filename

            self.src_data["melissaproperties"] = melissaProperties


        self.src_data["mergeDestinationTable"] = f"stage.{table_name.lower()}"
        self.src_data["mergeToStageSql"] = None
        self.src_data["primaryKeyColumns"] = primary_keys
        self.src_data["rowCountCheckOverride"] = 1
        self.src_data["sourceQueryFileName"] = table_name
        self.src_data["sourceQueryIncludeDeletedRecords"] = None
        self.src_data["truncateLoadDestinationTable"] = True
        self.src_data["uniqueTableCreateSql"] = None

        # append additional keys from appendkeyslist
        for key in self.sources_append:
            if key[0] == "importSql":
                for val in key[1]:
                    self.src_data[key[0]].append(val)
            else:
                self.src_data[key[0]] = key[1]

        # replace keys from replace list
        for key in self.sources_replace:
            self.src_data[key[0]] = key[1]

        # put sources object in an array
        src_data_array = self.src_data

        # convert sources object array into JSON
        json_src_data = json.dumps(src_data_array, indent=2, separators=(", ", ": "))

        # define output folder and filename
        output_folder = f"{db_folder}config_repo{os.sep}masterimport{os.sep}sources{os.sep}"

        # add API suffix if source is Archtics to match current naming convention
        if source_name.upper() == "ARCHTICS":
            filename = f"{table_name.lower()}_api.json"
        else:
            filename = f"{table_name.lower()}.json"

        # write sources json to file
        fn.filewrite(output_folder, filename, json_src_data)

        # trace log
        fn.print_section_detail(f"SOURCES - {filename}\nCreated in: {output_folder}", tracelog)

        return filename

    # append custom keys
    def append(self, key_name:str, value:str):
        self.sources_append.append([key_name,value])

    # replace key value
    def replace(self, key_name:str, value:str):
        self.sources_replace.append([key_name,value])

# File Transfers file
class File_Transfers:
    def __init__(self):
        self.filetransfers = {}
        self.filetransfersappend=[]

    # Create File Transfers
    def create_filetransfers(self, source_name:str, filesuffixmap:list, db_folder:str, tracelog:object):
        fn.print_section("Working on File Transfers", tracelog)

        # add keys
        self.filetransfers["SOURCENAME"] = source_name.capitalize()
        self.filetransfers["FILESUFFIXMAP"] = filesuffixmap

        # append additional keys from appendkeyslist
        for key in self.filetransfersappend:
            self.filetransfers[key[0]] = key[1]

        # put file transfers object in an array
        filetransfers_array = [self.filetransfers]

        # convert filetransfers object array into JSON
        json_filetransfers_data = json.dumps(filetransfers_array, indent=2, separators=(", ", ": "))

        # define output folder and filename
        output_folder = f"{db_folder}config_repo{os.sep}masterimport{os.sep}file_transfers{os.sep}"

        # add API suffix if source is Archtics to match current naming convention
        if source_name.upper() == "ARCHTICS":
            filename = f"{source_name.upper()}_API.JSON"
        else:
            filename = f"{source_name.upper()}.JSON"

        # write sources json to file
        fn.filewrite(output_folder, filename, json_filetransfers_data)

        fn.print_section_detail(f"FILE_TRANSFERS - {filename}\nCreated in: {output_folder}", tracelog)

    # append keys to file tranfers
    def append(self, key_name:str, value:str):
        self.filetransfersappend.append([key_name, value])

# Environment file
class Environment:
    def __init__(self, envname:str, source_name:str, tracelog:object):
        self.env = {}
        self.env_values = {}
        self.envappend = []
        self.envname = envname

        self.source_name = source_name.upper()
        self.tracelog = tracelog

    def append(self, key_name:str, value:str):
        self.envappend.append([key_name, value])

    def create_env_file(self, db_folder:str):
        fn.print_section("Working on Environment File", self.tracelog)

        # add config file match
        self.env_values["ConfigFileMatch"] = f"{self.source_name.upper()}*.JSON"

        # append keys
        for key in self.envappend:
            self.env_values[key[0]] = key[1]

        self.env[self.source_name] = self.env_values

        # convert filetransfers object array into JSON
        json_env_data = json.dumps(self.env, indent=2, separators=(", ", ": "))

        # define output folder
        output_folder = f"{db_folder}config_repo{os.sep}environment{os.sep}"

        # define filename
        filename = f"{self.source_name.upper()}_{self.envname}.JSON"

        # write sources json to file
        fn.filewrite(output_folder, filename, json_env_data)

        fn.print_section_detail(f"ENVIRONMENT - {filename}\nCreated in: {output_folder}", self.tracelog)