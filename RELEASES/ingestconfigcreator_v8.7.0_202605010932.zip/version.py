version = "8.7.0"
releasedate = "2026-05-01"
