version = "8.7.2"
releasedate = "2026-05-08"
