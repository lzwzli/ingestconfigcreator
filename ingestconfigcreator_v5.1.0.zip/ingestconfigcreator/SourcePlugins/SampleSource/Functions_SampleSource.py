import sys, os
sys.path.append("..")
from IngestConfigCreatorLibrary_Functions import *
from IngestConfigCreatorLibrary_Classes import *

# Sources specific sources append
def fn_sources_append(worksheet:object, database_folder:str, sources_obj:object, tracelog:object):
    tracelog.log("Running Source specific sources append function")

    tracelog.log("")
    return

# Sources specific business rules append
def fn_busrules_append(worksheet:object, busrules_obj:object, database_folder:str, tracelog:object):
    tracelog.log("Running Source specific busrules append function")

    tracelog.log("")
    return

# Sources specific environment append
def fn_env_append(env_obj:object, envname:str, tracelog:object):
    tracelog.log("Running Source specific environment append function")

    tracelog.log("")
    return