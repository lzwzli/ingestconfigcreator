version = "8.7.3"
releasedate = "2026-05-18"
