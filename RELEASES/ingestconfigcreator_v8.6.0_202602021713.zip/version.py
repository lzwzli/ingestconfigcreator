version = "8.6.0"
releasedate = "2026-02-02"
