version = "8.8.0"
releasedate = "2026-08-27"
