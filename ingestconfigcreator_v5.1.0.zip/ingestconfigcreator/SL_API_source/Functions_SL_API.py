import sys, os
sys.path.append("..")
sys.path.append(os.path.join(os.path.dirname(sys.path[0]),"FlatFile_source"))
from Functions_FlatFile import *
from IngestConfigCreatorLibrary_Functions import *
from IngestConfigCreatorLibrary_Classes import *
from importlib import import_module
from datetime import datetime

# ----------------------------------------------------------------
# Create Config Snaplogic API
# ----------------------------------------------------------------
def create_config_sl_api(source_name:str, client:str, database:str, ddfile:str, file_import_match:str, filedate_regex:str, field_delimiter:str, field_enclosed_by:str, copyffoptions:str, acquire_pipeline:str, tracelog:object):

    # ----------------------------------------------------------------
    # Load source specific function file
    # ----------------------------------------------------------------
    has_fn_sources_append = 0
    has_fn_busrules_append = 0
    has_fn_env_append = 0
    has_fn_create_copyinto_custom = 0
    has_fn_file_transfers_append = 0
    has_fn_create_import_DDL_custom = 0

    try:
        # append plugin folder path
        sys.path.append(os.path.join(os.path.dirname(sys.path[0]), f"ingestconfigcreator\\SourcePlugins\\{source_name.capitalize()}"))

        # load source specific functions file
        functions_plugin_name = f"Functions_{source_name.capitalize()}"
        functions_plugin = import_module(functions_plugin_name)

        tracelog.log("")
        tracelog.log(f"Imported {functions_plugin_name}.")

        # try to load sources_append function
        try:
            fn_sources_append = getattr(functions_plugin, "fn_sources_append")
            tracelog.log(f"{indent}{functions_plugin_name} fn_sources_append function loaded.")
            has_fn_sources_append = 1
        except:
            tracelog.log(f"{indent}No fn_sources_append function found in {functions_plugin_name}.")

        # try to load busrules_append function
        try:
            fn_busrules_append = getattr(functions_plugin, "fn_busrules_append")
            tracelog.log(f"{indent}{functions_plugin_name} fn_busrules_append function loaded.")
            has_fn_busrules_append = 1
        except:
            tracelog.log(f"{indent}No fn_busrules_append function found in {functions_plugin_name}.")

        # try to load env_append function
        try:
            fn_env_append = getattr(functions_plugin, "fn_env_append")
            tracelog.log(f"{indent}{functions_plugin_name} fn_env_append function loaded.")
            has_fn_env_append = 1
        except:
            tracelog.log(f"{indent}No fn_env_append function found in {functions_plugin_name}.")

        # try to load custom copy into
        try:
            fn_create_copyinto_custom = getattr(functions_plugin, "fn_create_copyinto_custom")
            tracelog.log(f"{indent}{functions_plugin_name} fn_create_copyinto_custom loaded.")
            has_fn_create_copyinto_custom = 1
        except:
            tracelog.log(f"{indent}No fn_create_copyinto_custom function found in {functions_plugin_name}.")

        # try to load file transfers append
        try:
            fn_file_transfers_append = getattr(functions_plugin, "fn_file_transfers_append")
            tracelog.log(f"{indent}{functions_plugin_name} fn_file_transfers_append loaded.")
            has_fn_file_transfers_append = 1
        except:
            tracelog.log(f"{indent}No custom fn_file_transfers_append function found in {functions_plugin_name}.")

        # try to load custom create import ddl
        try:
            fn_create_import_DDL_custom = getattr(functions_plugin, "fn_create_import_DDL_custom")
            tracelog.log(f"{indent}{functions_plugin_name} fn_create_import_DDL_custom loaded.")
            has_fn_create_import_DDL_custom = 1
        except:
            tracelog.log(f"{indent}No custom fn_create_import_DDL function found in {functions_plugin_name}.")

    except:
        tracelog.log(f"No source specific functions loaded.")

    # set CustomFileFormatOptions to empty string if no custom options provided
    if copyffoptions is None:
        CustomFileFormatOptions = ""
    else:
        CustomFileFormatOptions = f" {copyffoptions}"

    # set timestamp
    now = datetime.now()
    dts = now.strftime("%Y%m%d%H%M")

    # tracelog variables
    # TraceLog = Logger()
    tracelog_filename = f"{client}_{database}_{source_name}_{dts}.txt"

    # define output folders
    client_folder = os.path.dirname(os.path.abspath(ddfile)) + "\\" + client.upper()
    database_folder = client_folder + "\\" + database + "\\"
    ref_folder = f"{database_folder}\\ForReferenceOnly\\"
    os.makedirs(ref_folder, exist_ok=True)

    # console output variables
    startendfiller = "=" * 5

    # ----------------------------------------------------------------
    # START
    # ----------------------------------------------------------------
    tracelog.log("")
    tracelog.log(f"{startendfiller} START {startendfiller}")

    # -----------------------------------------------------------------------
    # Read data dictionary file
    # -----------------------------------------------------------------------
    wslist = []

    # read WorksheetList worksheet from ddfile
    wslist_sheet = pd.read_excel(ddfile, sheet_name="WorksheetList")

    # get row index list where Ready column = Y or y
    ws_ready_idx = ilookup(wslist_sheet, "Ready")

    # get list of worksheet names based on row index where Ready column = Y or y
    for ws_ready_idx_key in ws_ready_idx:
        wslist += [wslist_sheet.values[ws_ready_idx_key][0]]

    # -----------------------------------------------------------------------
    # Create keys for File Transfers file
    # -----------------------------------------------------------------------
    filesuffixmap = {}

    # -----------------------------------------------------------------------
    # For each worksheet, create necessary artifacts: Import DDL, Stage DDL, CopyInto, Sources
    # -----------------------------------------------------------------------
    # initialize resource list
    data_resources = []
    config_resources = []

    for wslist_key in wslist:
        print_section(f"Working on {wslist_key}", tracelog)

        # try to read worksheet. If not found, skip to next sheet.
        try:
            wsheet = SourceTable(ddfile, wslist_key, tracelog)
        except Exception as errmsg:
            tracelog.log(errmsg)
            continue

        # store table info in variables
        # TableName. Exit loop if TableName not found or if it is empty.
        try:
            TableName = str(wsheet.table_name())
            TableNameUpper = TableName.upper()
        except:
            continue

        # FileReceiptCheck
        FileReceiptCheck = str(wsheet.filereceiptcheck())

        # Threshold
        Threshold = str(wsheet.threshold())

        # StandardizationIndicator
        StandardizationIndicator = str(wsheet.standardization_ind())

        # RawAudienceIndicator
        RawAudienceIndicator = str(wsheet.rawaudience_ind())

        # SourceDateIndicator
        SourceDateIndicator = str(wsheet.sourcedate_ind())

        # FileSuffixMap. Exit loop if not found or empty.
        try:
            FileSuffixMap = str(wsheet.filesuffixmap())
        except:
            continue

        # FileMatchText. Exit loop if not found or empty.
        try:
            FileMatchText = str(wsheet.filematchtext())
        except:
            continue

        # FileType. Take file extension from FileImportMatch
        FileTypeList = file_import_match.split(".")
        FileTypeList.reverse()
        FileType = FileTypeList[0].upper()

        # ----------------------------------------------------------------
        # Get list of columns
        # ----------------------------------------------------------------
        col_list = wsheet.columns()

        # ----------------------------------------------------------------
        # Initialize Business Rule File
        # ----------------------------------------------------------------
        bus_rules = BusRules()

        # ----------------------------------------------------------------
        # Add unique work table business rule if CreateKeyhash = 1
        # ----------------------------------------------------------------
        # asssume default state of not needing to create key hash
        CreateKeyhash = "0"
        Keyhash = ""

        # try to create keyhash if CreateKeyhash key exists
        try:
            CreateKeyhash, Keyhash = wsheet.create_keyhash()
            # If CreateKeyhash is true, create business rules
            if CreateKeyhash == "1":
                WT_busrule_json = create_unique_worktable_busrule(TableNameUpper, Keyhash, tracelog)
                bus_rules.add_rule(WT_busrule_json)
        except:
            CreateKeyhash = "0"
            Keyhash = ""

        # ----------------------------------------------------------------
        # Get Primary Key columns where PrimaryKey == Y or y
        # ----------------------------------------------------------------
        if CreateKeyhash == "1":
            primary_keys = "KEYHASH"
            primary_key_DDL = "PRIMARY KEY (KEYHASH)"
        else:
            primary_keys, primary_key_DDL = wsheet.primary_keys_string()

        primary_keys_list = wsheet.primary_keys()

        # ----------------------------------------------------------------
        # Get columns where IsPhone == Y or y
        # ----------------------------------------------------------------
        phone_cols = wsheet.phone_columns()

        # ----------------------------------------------------------------
        # Create Import DDL File
        # ----------------------------------------------------------------
        if has_fn_create_import_DDL_custom==1:
            fn_create_import_DDL_custom(TableNameUpper, col_list, dts, database_folder, tracelog)
        else:
            create_import_DDL(TableNameUpper, col_list, dts, database_folder, tracelog)

        data_resources.append(["IMPORT", TableNameUpper])

        # ----------------------------------------------------------------
        # Create Stage DDL File
        # ----------------------------------------------------------------
        create_stage_DDL(TableNameUpper, col_list, primary_key_DDL, phone_cols, StandardizationIndicator, RawAudienceIndicator, dts, database_folder, tracelog)
        data_resources.append(["STAGE", TableNameUpper])

        # ----------------------------------------------------------------
        # Create CopyInto File
        # ----------------------------------------------------------------

        if has_fn_create_copyinto_custom==1:
            copyinto_filename = fn_create_copyinto_custom(client, source_name, TableNameUpper, col_list, FileMatchText, filedate_regex, field_delimiter, dts, database_folder, tracelog, field_enclosed_by, CustomFileFormatOptions)
        else:
            copyinto_filename = create_copyinto(client, source_name, TableNameUpper, col_list, FileMatchText, filedate_regex, field_delimiter, dts, database_folder, tracelog, field_enclosed_by, CustomFileFormatOptions)

        if copyinto_filename != None or copyinto_filename != "null":
            config_resources.append(["sources", copyinto_filename])


        # ----------------------------------------------------------------
        # Create Sources File
        # ----------------------------------------------------------------
        sources_obj = Sources()

        # add GETLASTDATEINDICATOR to sources
        sources_obj.append("GETLASTDATEINDICATOR", "1")

        # add FileMatchText to sources
        if FileMatchText.upper() != "EXCLUDEFROMFILETRANSFERS":
            sources_obj.append("FILEMATCHTEXT", FileMatchText)

        # add UniqueWorkTable to sources
        if CreateKeyhash == "1":
            sources_obj.append("UNIQUEWORKTABLE", f"TMP.{TableNameUpper}")

        # generate standardization query
        StandardizationQuery = ""
        if StandardizationIndicator == "1":
            # get standardization sheet name
            std_sheet_name = str(wsheet.standardization_sheet())
            tracelog.log(f"Standardization sheet name = {std_sheet_name}")

            try:
                # initialize standardization object
                StdObj = StdSheet(ddfile, std_sheet_name, bus_rules)

                # generate standardization query for sources file
                StdQueryDoc = StdObj.std_query()
                StandardizationQuery = StdQueryDoc.out_str()

                # ouput standardization query to file
                tracelog.log(f"{indent}Output {TableName} Standardization Query")

                filewrite(ref_folder, f"{TableName} Standardization Query.sql", StdQueryDoc.out())

                # generate standardization business rule and add to business rule document
                StdObj.create_std_busrule()

            except Exception as stdobjerr:
                tracelog.log(stdobjerr)

        # run source specific functions
        if has_fn_sources_append == 1:
            fn_sources_append(wsheet, database_folder, sources_obj, tracelog)

        # create sources file
        sources_filename = sources_obj.create_sources(source_name, TableNameUpper, primary_keys, FileReceiptCheck, RawAudienceIndicator, SourceDateIndicator, StandardizationIndicator, StandardizationQuery, copyinto_filename, Threshold, database_folder, tracelog)

        config_resources.append(["sources", sources_filename])

        # ----------------------------------------------------------------
        # Create RawAudience Business Rule
        # ----------------------------------------------------------------
        if RawAudienceIndicator == "1":
            tracelog.log(f"RawAudienceIndicator = {RawAudienceIndicator}")

            # get rawaudience sheet name
            ra_sheet_name = str(wsheet.rawaudience_sheet())
            tracelog.log(f"{indent}RawAudienceSheet = {ra_sheet_name}")

            try:
                # initialize rawaudience object
                rawaud = RawAudSheet(ddfile, ra_sheet_name, TableName, bus_rules)
                tracelog.log(f"{indent}Creating Stage RawAudience Business Rule")
                rawaud.create_stg_rawaud_busrule()
                tracelog.log(f"{indent}Creating Tmp RawAudience Business Rule")
                rawaud.create_tmp_rawaud_busrule()

                # control-rawaudience
                tracelog.log(f"{indent}Creating control-rawaudience.sql file")
                rawaud.ctrl_ra_file(database_folder)

            except Exception as rawauderr:
                tracelog.log(f"{indent}RawAudience Error: {rawauderr}")

        # ----------------------------------------------------------------
        # Create filesuffixmap for File Transfers
        # ----------------------------------------------------------------
        if FileSuffixMap.upper() != "EXCLUDEFROMFILETRANSFERS":
            filesuffixmap[FileSuffixMap] = sources_filename

        # ----------------------------------------------------------------
        # Add Phone formatter business rule if RawAudience is 1 and there are phone columns
        # ----------------------------------------------------------------
        if RawAudienceIndicator != "1" and len(phone_cols) != 0:
            tracelog.log("")
            tracelog.log(f"Phone columns found but not creating phone formatter business rule since RawAudienceIndicator is 0")
            tracelog.log("")
        elif RawAudienceIndicator == "1" and len(phone_cols) != 0:
            tracelog.log("")
            tracelog.log(f"Phone columns count = {len(phone_cols)}")
            tracelog.log(f"{indent}Creating phone formatter business rule")
            tracelog.log("")
            pf_busrule_json = create_phone_formatter_busrule(TableName, primary_keys_list, phone_cols)
            bus_rules.add_rule(pf_busrule_json)

        # ----------------------------------------------------------------
        # Run source specific fn_busrules_append
        # ----------------------------------------------------------------
        if has_fn_busrules_append == 1:
            fn_busrules_append(wsheet, bus_rules, database_folder, tracelog)

        # ----------------------------------------------------------------
        # Create Business Rules File
        # ----------------------------------------------------------------
        # if there are business rules to output, append to config deployment script
        if bus_rules.out(TableName, database_folder, tracelog) == 1:
            config_resources.append(["businessrules", f"{TableNameUpper}-busrules.JSON"])

    # ----------------------------------------------------------------
    # Create File Transfers File
    # ----------------------------------------------------------------
    filetransfers_obj = File_Transfers()

    # add AquirePipeline to filetransfers
    filetransfers_obj.append("AQUIRE_PIPELINE", acquire_pipeline)

    # add fileimportmatch to filetransfers
    filetransfers_obj.append("FILEIMPORTMATCH", file_import_match)

    # load fn_file_transfers_append
    if has_fn_file_transfers_append == 1:
        client_project = get_client_project(client)
        fn_file_transfers_append(filetransfers_obj, client_project, tracelog)

    # create file transfers file
    filetransfers_obj.create_filetransfers(source_name, filesuffixmap, database_folder, tracelog)
    config_resources.append(["file_transfers", f"{source_name.upper()}.JSON"])

    # ----------------------------------------------------------------
    # Create Environment File
    # ----------------------------------------------------------------
    env_list = ["PROD", "QA", "DEV"]

    for env in env_list:
        env_obj = Environment(env,source_name,tracelog)

        if has_fn_env_append == 1:
            fn_env_append(env_obj, env, tracelog)

        env_obj.create_env_file(database_folder)

    # ----------------------------------------------------------------
    # Create Deployment Script
    # ----------------------------------------------------------------
    # Set environment
    if client == database:
        env = "PROD"
    elif "qa" in database.lower():
        env = "QA"
    elif "dev" in database.lower():
        env = "DEV"
    else:
        env = "NA"

    # create data repo deploy scripts
    data_deploy_scripts = create_deployment_scripts(client, database, env, source_name, "data", data_resources)
    # add phone formatter deployment
    if StandardizationIndicator == 1:
        data_deploy_scripts += f".\\installComponent.ps1 -cn {client} -toDB {database} -env {env} -fr base -s 1public -c fn_phoneformatter -silent\n"
    # add control rawaudience deployment
    if RawAudienceIndicator == 1:
        data_deploy_scripts += f".\\installComponent.ps1 -cn {client} -toDB {database} -env {env} -fr {source_name} -s seed_data -c control-rawaudience -silent\n"

    # create config repo deploy scripts
    config_deploy_scripts = create_deployment_scripts(client, database, env, source_name, "config", config_resources)

    print_section("Deployment Scripts", tracelog)
    tracelog.log("--data repo")
    tracelog.log(data_deploy_scripts)
    tracelog.log("--config repo")
    tracelog.log(config_deploy_scripts)

    # ----------------------------------------------------------------
    # END
    # ----------------------------------------------------------------
    tracelog.log("")
    tracelog.log(f"{startendfiller} END {startendfiller}")
    tracelog.log("")

    # ----------------------------------------------------------------
    # Output Trace Log to File
    # ----------------------------------------------------------------
    tracelogmsg = tracelog.out()
    filewrite(database_folder, tracelog_filename, tracelogmsg)

    print(f"Trace log \"{tracelog_filename}\" created in: {database_folder}\n")