from Library.Class.Document import *
import Library.Flatten_basic as Flatten_basic

def flattenjson_seatgeekevents(table_name:str, table_name_raw:str, col_list:list):
    flattendoc = Document()

    def split_show_name(source_column:str, column_name:str):
        colstring = f"\tsplit({source_column},',')[Show_Name.index]::string AS {column_name},"
        return colstring

    def replace_string(source_column:str, column_name:str):
        colstring = f"\t\tREPLACE(REPLACE(REPLACE({source_column}.value::string, '[',''), '\"', ''), ']','') AS {column_name},"
        return colstring

    def flatten_table(output_name:str, table_to_parse:str="PRODUCT_DETAILS"):
        if output_name != "Show_Name":
            output_name = output_name.upper()

        tablestring = f"\t\tLATERAL FLATTEN(input => PARSE_JSON({table_to_parse}), OUTER => true) {output_name},"
        return tablestring

    outer_select_columns = Document()
    inner_select_columns = Document()
    flatten_tables = Document()
    where_clause = Document()
    for col in col_list:
        if col[1].upper() == "EVENT_PRODUCT_ID":
            outer_select_columns.newline(f"\t{col[0].upper()} AS {col[1].upper()},")
            inner_select_columns.newline(f"\t\t{col[0]},")
        elif col[1].upper() == "EVENT_DATE":
            outer_select_columns.newline(f"\t{col[0]},")
            inner_select_columns.newline(f"\t\t{col[0]},")
        elif col[1].upper() == "EVENT":
            outer_select_columns.newline(f"\t{col[0]}.value::string AS {col[1]},")
            inner_select_columns.newline(replace_string(col[0], col[0]))
            flatten_tables.newline(flatten_table(col[0]))
            where_clause.newline(f"\t\t{col[0]}.path = '{col[0]}' AND")
        elif col[1].upper() == "EVENT_TIER":
            outer_select_columns.newline(split_show_name(col[0].upper(),col[1]))
            inner_select_columns.newline(replace_string(col[0].upper(),col[0].upper()))
            flatten_tables.newline(flatten_table(col[0]))
            where_clause.newline(f"\t\t{col[0].upper()}.path = '{col[0]}' AND")
        elif col[1].upper() == "SEASONNAME":
            outer_select_columns.newline(f"\tREPLACE(split({col[0].upper()},',')[Show_Name.index]::string, 'HISTORIC', year(to_datetime(EVENT_DATE))) AS {col[1].upper()},")
            inner_select_columns.newline(replace_string(col[0].upper(), col[0].upper()))
            flatten_tables.newline(flatten_table(col[0]))
            where_clause.newline(f"\t\t{col[0].upper()}.path = '{col[0]}' AND")
        else:
            outer_select_columns.newline(split_show_name(col[1].upper(), col[1].upper()))
            inner_select_columns.newline(replace_string(col[0].upper(), col[1].upper()))
            flatten_tables.newline(flatten_table(col[0]))
            where_clause.newline(f"\t\t{col[0].upper()}.path = '{col[0]}' AND")

    outer_select_columns.trimend(1)
    inner_select_columns.trimend(1)
    flatten_tables.trimend(1)
    where_clause.newline("\t\tproduct_type = 'Event'")

    inner_select = Document()

    inner_select.newline("\tSELECT")
    inner_select.newline("\t\tFILEDATE,")
    inner_select.newline("\t\tFILENAME,")
    inner_select.newline("\t\tFILEROWNUMBER,")
    inner_select.newline(inner_select_columns.out())
    inner_select.newline("\tFROM")
    inner_select.newline("\t\t&database.IMPORT.SEATGEEKPRODUCTS,")
    inner_select.newline(flatten_tables.out())
    inner_select.newline("\tWHERE")
    inner_select.newline(where_clause.out())

    flattendoc.newline("SELECT")
    flattendoc.newline("\tFILEDATE,")
    flattendoc.newline("\tFILENAME,")
    flattendoc.newline("\tFILEROWNUMBER,")
    flattendoc.newline(outer_select_columns.out())
    flattendoc.newline("FROM (")
    flattendoc.newline(inner_select.out())
    flattendoc.newline("),")
    flattendoc.newline("LATERAL FLATTEN(input => split(Show_Name, ','), OUTER => TRUE) Show_Name")

    return flattendoc.out()

def flattenjson_seatgeekplans(table_name:str, table_name_raw:str, col_list:list):
    flattendoc = Document()

    def split_string(source_column:str, column_name:str, data_type:str):
        inner_split = f"IFNULL(split({source_column.upper()}, ',')[event.index]::string, split({source_column.upper()}, ',')[0]::string)"

        if "NUMBER" in data_type:
            colstring = f"\tTRY_CAST({inner_split} AS INT) AS {column_name.upper()},"
        else:
            colstring = f"\t{inner_split} AS {column_name},"
        return colstring

    def replace_string(source_column: str, column_name: str):
        colstring = f"\t\tREPLACE(REPLACE(REPLACE({source_column}.value::string, '[',''), '\"', ''), ']','') AS {column_name.upper()},"
        return colstring

    def flatten_table(output_name: str, table_to_parse: str = "PRODUCT_DETAILS"):
        tablestring = f"\t\tLATERAL FLATTEN(input => PARSE_JSON({table_to_parse}), OUTER => true) {output_name.lower()},"
        return tablestring

    outer_select_columns = Document()
    inner_select_columns = Document()
    flatten_tables = Document()
    where_clause = Document()
    for col in col_list:
        if col[1].upper() == "PLAN_PRODUCT_ID":
            outer_select_columns.newline(f"\t{col[0]} AS {col[1].upper()},")
            inner_select_columns.newline(f"\t\t{col[0]},")
        elif col[1].upper() == "EVENT":
            outer_select_columns.newline(f"\t{col[0].lower()}.value::string AS {col[1].upper()},")
            inner_select_columns.newline(replace_string(col[0].lower(), col[0].lower()))
            flatten_tables.newline(flatten_table(col[0]))
            where_clause.newline(f"\t\t{col[0]}.path = '{col[1]}' AND")
        elif col[1].upper() == "EVENT_DATE":
            outer_select_columns.newline(f"\tTRY_CAST(split({col[0].lower()}, ',')[event.index]::string AS TIMESTAMP) AS {col[1].upper()},")
            inner_select_columns.newline(replace_string(col[0].lower(), col[0].lower()))
            flatten_tables.newline(flatten_table(col[0]))
            where_clause.newline(f"\t\t{col[0]}.path = '{col[1]}' AND")
        elif col[1].upper() == "PLANNAME":
            outer_select_columns.newline(f"\t{col[0].upper()} AS {col[1].upper()},")
            inner_select_columns.newline(f"\t\t{col[0].upper()},")
        else:
            outer_select_columns.newline(split_string(col[1].upper(), col[1].upper(), col[2]))
            inner_select_columns.newline(replace_string(col[0], col[1].upper()))
            flatten_tables.newline(flatten_table(col[0]))
            where_clause.newline(f"\t\t{col[0]}.path = '{col[1]}' AND")

    outer_select_columns.trimend(1)
    inner_select_columns.trimend(1)
    flatten_tables.trimend(1)
    where_clause.newline("\t\tproduct_type = 'Series'")

    inner_select = Document()

    inner_select.newline("\tSELECT")
    inner_select.newline("\t\tFILEDATE,")
    inner_select.newline("\t\tFILENAME,")
    inner_select.newline("\t\tFILEROWNUMBER,")
    inner_select.newline(inner_select_columns.out())
    inner_select.newline("\tFROM")
    inner_select.newline("\t\t&database.IMPORT.SEATGEEKPRODUCTS,")
    inner_select.newline(flatten_tables.out())
    inner_select.newline("\tWHERE")
    inner_select.newline(where_clause.out())

    flattendoc.newline("SELECT")
    flattendoc.newline("\tFILEDATE,")
    flattendoc.newline("\tFILENAME,")
    flattendoc.newline("\tFILEROWNUMBER,")
    flattendoc.newline(outer_select_columns.out())
    flattendoc.newline("FROM (")
    flattendoc.newline(inner_select.out())
    flattendoc.newline("),")
    flattendoc.newline("LATERAL FLATTEN(input => split(event, ','), OUTER => TRUE) event")

    return flattendoc.out()

def flattenjson(table_name:str, table_name_raw:str, col_list:list):
    if table_name.upper() == "SEATGEEKEVENTS":
        flattendoc = flattenjson_seatgeekevents(table_name, table_name_raw, col_list)
    elif table_name.upper() == "SEATGEEKPLANS":
        flattendoc = flattenjson_seatgeekplans(table_name, table_name_raw, col_list)
    else:
        flattendoc = Flatten_basic.flattenjson(table_name, table_name_raw, col_list)

    return flattendoc