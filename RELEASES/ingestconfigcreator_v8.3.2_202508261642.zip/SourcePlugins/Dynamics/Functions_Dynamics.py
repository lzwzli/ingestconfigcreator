# custom_filedate = "TO_CHAR(REGEXP_SUBSTR(REPLACE(SPLIT_PART(SPLIT_PART(METADATA$FILENAME, '/', -1), '-', -1),'-',''), '[0-9]{14}', 1, 1))"
custom_filedate = "TO_CHAR(SUBSTR(REGEXP_SUBSTR(SPLIT_PART(METADATA$FILENAME, '/', -1), '[0-9]{20}'), 1, 14))"
