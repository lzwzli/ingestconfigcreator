import sys, os
sys.path.append("..")
from IngestConfigCreatorLibrary_Functions import *
from IngestConfigCreatorLibrary_Classes import *

# ----------------------------------------------------------------
# Create SOQL Query
# ----------------------------------------------------------------
def create_SOQL_query(salesforce_object_name:str, column_list:list, rawaudience_indicator:str):
    soql = Document()

    soql.append("SELECT")

    for row in column_list:
        soql.newline(f"\t{row[0]},")

    soql.trimend(1)

    soql.newline(f"FROM")
    soql.newline(f"\t{salesforce_object_name}")
    soql.newline("WHERE")
    if rawaudience_indicator == "1":
        soql.newline(f"\tMasterRecordId = null AND ")

    soql.newline(f"\tDAY_ONLY(LastModifiedDate) >= %DATE%")

    return soql

# ----------------------------------------------------------------
# Salesforce specific sources append
# ----------------------------------------------------------------
def fn_sources_append(worksheet:object, database_folder:str, sources_obj:object, tracelog:object, isPrefect=0 ):
    tracelog.log("Running Salesforce specific sources append function")

    # create output folder
    ref_folder = f"{database_folder}{os.sep}ForReferenceOnly{os.sep}"
    sources_folder = f"{database_folder}{os.sep}masterimport{os.sep}sources{os.sep}"
    os.makedirs(ref_folder, exist_ok=True)

    # get table name
    if isPrefect == 0:
        table_name = worksheet.table_name()
    else:
        table_name = worksheet.table_name().lower()

    # get salesforce object name
    sf_obj = worksheet.salesforce_object_name()

    # get rawaudienceindicator
    rawaudience_ind = worksheet.rawaudience_ind()

    # get column list
    col_list = worksheet.columns()

    # create SOQL query
    tracelog.log(f"{indent}Create SOQL Query")
    soql = create_SOQL_query(sf_obj, col_list, rawaudience_ind)

    if isPrefect == 0:
        # output SOQL query to file
        tracelog.log(f"{indent}Output {sf_obj} SOQL Query")
        filewrite(ref_folder, f"{sf_obj} SOQL Query.txt", soql.out())
    else:
        filewrite(sources_folder, f"salesforce{str(sf_obj).lower().replace('salesforce','')}-select.soql", soql.out())

    # add SOQL to sources file
    tracelog.log(f"{indent}Add to sources list")
    if isPrefect == 0:
        sources_obj.append("SOURCEQUERYTEXT", soql.out_str())
    else:
        sources_obj.append("sourceQueryFileName", f"salesforce{str(sf_obj).lower().replace('salesforce','')}-select.soql")

    # add IMPORTSOURCEINDICATOR to sources file
    if isPrefect == 0:
        sources_obj.append("IMPORTSOURCEINDICATOR", "SOQL")
    else:
        sources_obj.append("sourceType", "SOQL")

    # add SALESFORCEOBJECTNAME to sources file
    if isPrefect == 0:
        sources_obj.append("SALESFORCEOBJECTNAME", sf_obj)
    else:
        sources_obj.append("salesforceObjectName", None)

    # getLastDate
    if isPrefect == 0:
        # add SEASONYEARINDICATOR to sources file
        sources_obj.append("SEASONYEARINDICATOR", 0)
        # add TABLENAME to sources file
        sources_obj.append("TABLENAME", table_name)
        # add REFRESH to sources file
        sources_obj.append("REFRESH", 0)
        # add DAYSBACK to sources file
        sources_obj.append("DAYSBACK", 0)
        # add SCHEMA to sources file
        sources_obj.append("SCHEMA", "STAGE")
        # add WHERECLAUSE to sources file
        sources_obj.append("WHERECLAUSE", None)
    else:
        sources_obj.replace("getLastDateIndicator", True)
        sources_obj.append("rowCountCheckOverride", 1)

        # define getLastDateProperties values
        getLastDateProperties = {}
        getLastDateProperties["daysBack"] = 0
        getLastDateProperties["lastDateColumn"] = "LastModifiedDate"
        getLastDateProperties["refresh"] = 0
        getLastDateProperties["schema"] = "stage"
        getLastDateProperties["seasonYearIndicator"] = 0
        getLastDateProperties["whereClause"] = ""
        getLastDateProperties["tableName"] = table_name
        sources_obj.append("getLastDateProperties", getLastDateProperties)

    tracelog.log("")
    return

# ----------------------------------------------------------------
# Append Environment
# ----------------------------------------------------------------
def fn_env_append(env_obj:object, envname:str, tracelog:object):
    tracelog.log("Running Salesforce specific environment append function")

    env_obj.append("QueryAccount", f"REPLACE_WITH_{envname}_SALESFORCE_ACCOUNT")

    tracelog.log("")
    return

# ----------------------------------------------------------------
# Append File Transfers
# ----------------------------------------------------------------
def fn_file_transfers_append(file_transfers_obj:object, client_project:str, tracelog:object):
    tracelog.log("Running Salesforce specific file_transfers append function")

    # add acquire pipeline
    file_transfers_obj.append("AQUIRE_PIPELINE", f"../{client_project}/Salesforce_Acquire_Pipeline")

    # add MASTERSCHEDULE
    file_transfers_obj.append("MASTERSCHEDULE", f"../{client_project}/SalesforceMasterImport")

    tracelog.log("")
    return

# ----------------------------------------------------------------
# Append Business Rules
# ----------------------------------------------------------------
def fn_busrules_append(worksheet:object, busrules_obj:object, database_folder:str, tracelog:object):
    tracelog.log("Running Salesforce specific busrules append function")

    # salesforce object name
    sf_obj = worksheet.salesforce_object_name()

    # ----------------------------------------------------------------
    # ACCOUNT
    # ----------------------------------------------------------------
    if sf_obj.upper() == "ACCOUNT":
        output_folder = f"{database_folder}ForReferenceOnly{os.sep}SalesforceAccount_BusRules{os.sep}"
        tracelog.log("Generate Salesforce Account Business Rules.")
        tracelog.log("")

        # ----------------------------------------------------------------
        # Rule 0_0
        # ----------------------------------------------------------------
        busrule = {}
        busrule["RULENAME"] = "SalesforceAccount_0_0"
        busrule["RUNORDER"] = 0
        busrule["RUNPOSITION"] = 0

        rulequerydoc = Document()
        rulequerydoc.append("UPDATE &database.IMPORT.SALESFORCEACCOUNT dest")
        rulequerydoc.newline("SET dest.BILLINGSTREET = src.NEWBILLINGSTREET")
        rulequerydoc.newline("\tFROM (")
        rulequerydoc.newline("\t\tSELECT")
        rulequerydoc.newline("\t\t\tID,")
        rulequerydoc.newline("\t\t\tBILLINGSTREET,")
        rulequerydoc.newline("\t\t\tREPLACE(REPLACE(REPLACE(REGEXP_REPLACE(BILLINGSTREET,'[0-9]{8,}_[0-9]{1,}\\\\|[0-9]+\\\\|[0-9]+\\\\|',''),'\\n',' '),'\\r',' '),'  ',' ') AS NEWBILLINGSTREET")
        rulequerydoc.newline("\t\tFROM")
        rulequerydoc.newline("\t\t\t&database.IMPORT.SALESFORCEACCOUNT")
        rulequerydoc.newline("\t\tWHERE")
        rulequerydoc.newline("\t\t\tBILLINGSTREET LIKE '%\\n%'")
        rulequerydoc.newline("\t) src")
        rulequerydoc.newline("WHERE")
        rulequerydoc.newline("\tdest.ID = src.ID")
        rulequerydoc.newline(";")

        # write out Rule Query to file
        filewrite(output_folder, "SalesforceAccount_0_0 UPDATE IMPORT SALESFORCEACCOUNT RULE QUERY.sql", rulequerydoc.out())

        busrule["RULEQUERY"] = rulequerydoc.out_str()

        json_busrule = json.dumps(busrule, indent=2, separators=(", ", ": "))

        busrules_obj.add_rule(json_busrule)

        # ----------------------------------------------------------------
        # Rule 1_4
        # ----------------------------------------------------------------
        busrule = {}
        busrule["RULENAME"] = "SalesforceAccount_1_4"
        busrule["RUNORDER"] = 1
        busrule["RUNPOSITION"] = 4

        rulequerydoc = Document()
        rulequerydoc.append("MERGE INTO &database.STAGE.SALESFORCEACCOUNTARCHIVE dest")
        rulequerydoc.newline("USING (")
        rulequerydoc.newline("\tSELECT sa.*")
        rulequerydoc.newline("\t\tsa.*")
        rulequerydoc.newline("\tFROM")
        rulequerydoc.newline("\t\t&database.STAGE.SALESFORCEACCOUNT sa")
        rulequerydoc.newline("\tWHERE (")
        rulequerydoc.newline("\t\tLOWER(sa.ISDELETED) = 'true'")
        rulequerydoc.newline("\t\tAND EQUAL_NULL(TRIM(sa.MASTERRECORDID),'')")
        rulequerydoc.newline("\t)")
        rulequerydoc.newline(") src")
        rulequerydoc.newline("ON dest.ID = src.ID")
        rulequerydoc.newline("WHEN NOT MATCHED THEN INSERT (")

        insert_cols = ["FILEDATE", "FILENAME", "FILEROWNUMBER", "DWINSERTDATE", "DWUPDATEDATE", "DW_ACCOUNT_ID__C", "AccountSource", "Account_External_HPM_SF_ID__c", "Account_Sync_Status__c", "BillingCity", "BillingCountry", "BillingGeocodeAccuracy", "BillingLatitude", "BillingLongitude", "BillingPostalCode", "BillingState", "BillingStreet", "CreatedById", "CreatedDate", "Description", "Id", "Industry", "IsDeleted", "Jigsaw", "JigsawCompanyId", "LastActivityDate", "LastModifiedById", "LastModifiedDate", "LastReferencedDate", "LastViewedDate", "MasterRecordId", "Name", "NumberOfEmployees", "OwnerId", "ParentId", "Phone", "PhotoUrl", "RecordTypeId", "ShippingCity", "ShippingCountry", "ShippingGeocodeAccuracy", "ShippingLatitude", "ShippingLongitude", "ShippingPostalCode", "ShippingState", "ShippingStreet", "SicDesc", "SystemModstamp", "Type", "Website"]

        for col in insert_cols:

            rulequerydoc.newline(f"\t{col},")

        rulequerydoc.trimend(1)

        rulequerydoc.newline(")")
        rulequerydoc.newline("VALUES (")

        for col in insert_cols:
            rulequerydoc.newline(f"\tsrc.{col},")

        rulequerydoc.trimend(1)

        rulequerydoc.newline(");")

        # write out Rule Query to file
        filewrite(output_folder, "SalesforceAccount_1_4 MERGE SALESFORCEACCOUNTARCHIVE RULE QUERY.sql",
                  rulequerydoc.out())

        busrule["RULEQUERY"] = rulequerydoc.out_str()

        json_busrule = json.dumps(busrule, indent=2, separators=(", ", ": "))

        busrules_obj.add_rule(json_busrule)

        # ----------------------------------------------------------------
        # Rule 2_4
        # ----------------------------------------------------------------
        busrule = {}
        busrule["RULENAME"] = "SalesforceAccount_2_4"
        busrule["RUNORDER"] = 2
        busrule["RUNPOSITION"] = 4

        rulequerydoc = Document()
        rulequerydoc.append("DELETE FROM &database.STAGE.SALESFORCEACCOUNT")
        rulequerydoc.newline("WHERE ID IN (")
        rulequerydoc.newline("\tSELECT")
        rulequerydoc.newline("\t\tsa.ID")
        rulequerydoc.newline("\tFROM")
        rulequerydoc.newline("\t\t&database.STAGE.SALESFORCEACCOUNT sa")
        rulequerydoc.newline("\tWHERE (")
        rulequerydoc.newline("\t\tLOWER(sa.ISDELETED) = 'true'")
        rulequerydoc.newline("\t\tAND EQUAL_NULL(TRIM(sa.MASTERRECORDID),'')")
        rulequerydoc.newline("\t\tAND sa.ID IN (")
        rulequerydoc.newline("\t\t\tSELECT")
        rulequerydoc.newline("\t\t\t\tID")
        rulequerydoc.newline("\t\t\tFROM")
        rulequerydoc.newline("\t\t\t\t&database.STAGE.SALESFORCEACCOUNTARCHIVE")
        rulequerydoc.newline("\t\t\tGROUP BY ID")
        rulequerydoc.newline("\t\t)")
        rulequerydoc.newline("\t);")

        # write out Rule Query to file
        filewrite(output_folder, "SalesforceAccount_2_4 DELETE FROM SALESFORCEACCOUNT RULE QUERY.sql", rulequerydoc.out())

        busrule["RULEQUERY"] = rulequerydoc.out_str()

        json_busrule = json.dumps(busrule, indent=2, separators=(", ", ": "))

        busrules_obj.add_rule(json_busrule)

        # ----------------------------------------------------------------
        # Rule 3_4
        # ----------------------------------------------------------------
        busrule = {}
        busrule["RULENAME"] = "SalesforceAccount_3_4"
        busrule["RUNORDER"] = 3
        busrule["RUNPOSITION"] = 4

        rulequerydoc = Document()
        rulequerydoc.append("UPDATE &database.STAGE.SALESFORCEACCOUNT_HISTORY TAR")
        rulequerydoc.newline("SET")
        rulequerydoc.newline("\tTAR.ACTIVETODATE = CURRENT_TIMESTAMP(),")
        rulequerydoc.newline("\tTAR.DWUPDATEDATE = CURRENT_TIMESTAMP()")
        rulequerydoc.newline("FROM (")
        rulequerydoc.newline("\tSELECT")

        history_select_list = ["ID", "NAME", "BILLINGSTREET", "BILLINGCITY", "BILLINGSTATE", "BILLINGPOSTALCODE", "BILLINGCOUNTRY", "PHONE"]

        for col in history_select_list:
            rulequerydoc.newline(f"\t\tHIST.{col},")

        rulequerydoc.trimend(1)

        rulequerydoc.newline("\tFROM")
        rulequerydoc.newline("\t\t&database.STAGE.SALESFORCEACCOUNT_HISTORY HIST")
        rulequerydoc.newline("\tLEFT JOIN")
        rulequerydoc.newline("\t\t&database.STAGE.SALESFORCEACCOUNT STG")
        rulequerydoc.newline("\tON")

        for col in history_select_list:
            rulequerydoc.newline(f"\t\tHIST.{col} = STG.{col} AND")

        rulequerydoc.trimend(4)

        rulequerydoc.newline("\tWHERE")
        rulequerydoc.newline("\t\tSTG.ID IS NULL")
        rulequerydoc.newline(") SRC")
        rulequerydoc.newline("WHERE")

        for col in history_select_list:
            rulequerydoc.newline(f"TAR.{col} = SRC.{col} AND")

        rulequerydoc.newline("TAR.RECORDNUMBER = 1 AND")
        rulequerydoc.newline("TAR.ACTIVETODATE = TRY_TO_TIMESTAMP('2999-12-31');")

        # write out Rule Query to file
        filewrite(output_folder, "SalesforceAccount_3_4 UPDATE SALESFORCEACCOUNT HISTORY RULE QUERY.sql", rulequerydoc.out())

        busrule["RULEQUERY"] = rulequerydoc.out_str()

        json_busrule = json.dumps(busrule, indent=2, separators=(", ", ": "))

        busrules_obj.add_rule(json_busrule)

        # ----------------------------------------------------------------
        # Rule 4_4
        # ----------------------------------------------------------------
        busrule = {}
        busrule["RULENAME"] = "SalesforceAccount_4_4"
        busrule["RUNORDER"] = 4
        busrule["RUNPOSITION"] = 4

        rulequerydoc = Document()
        rulequerydoc.append("MERGE INTO &database.STAGE.SALESFORCEACCOUNT_HISTORY DEST")
        rulequerydoc.newline("USING &database.STAGE.SALESFORCEACCOUNT SRC")
        rulequerydoc.newline("ON")

        for col in history_select_list:
            rulequerydoc.newline(f"\tDEST.{col} = SRC.{col} AND")

        rulequerydoc.newline("\tDEST.RECORDNUMBER = 1 AND")
        rulequerydoc.newline("\tDEST.ACTIVETODATE = TRY_TO_TIMESTAMP('2999-12-31')")
        rulequerydoc.newline("WHEN MATCHED AND")

        match_not_null_cols = ["FILEDATE", "FILENAME", "FILEROWNUMBER", "DW_ACCOUNT_ID__C", "AccountSource", "Account_External_HPM_SF_ID__c", "Account_Sync_Status__c", "BillingGeocodeAccuracy", "BillingLatitude", "BillingLongitude", "CreatedById", "CreatedDate", "Description", "Industry", "IsDeleted", "Jigsaw", "JigsawCompanyId", "LastActivityDate", "LastModifiedById", "LastModifiedDate", "LastReferencedDate", "LastViewedDate", "MasterRecordId", "NumberOfEmployees", "OwnerId", "ParentId", "PhotoUrl", "RecordTypeId", "ShippingCity", "ShippingCountry", "ShippingGeocodeAccuracy", "ShippingLatitude", "ShippingLongitude", "ShippingPostalCode", "ShippingState", "ShippingStreet", "SicDesc", "SystemModstamp", "Type", "Website"]

        for col in match_not_null_cols:
            rulequerydoc.newline(f"\tNOT EQUAL_NULL(DEST.{col}, SRC.{col}) OR")

        rulequerydoc.trimend(3)

        rulequerydoc.newline("THEN UPDATE SET")

        for col in match_not_null_cols:
            rulequerydoc.newline(f"\tDEST.{col} = SRC.{col},")

        rulequerydoc.newline("\tDEST.DWUPDATEDATE = CURRENT_TIMESTAMP()")
        rulequerydoc.newline("WHEN NOT MATCHED THEN INSERT (")

        history_insert_cols = ["FILEDATE", "FILENAME", "FILEROWNUMBER", "DWINSERTDATE", "DWUPDATEDATE", "DW_ACCOUNT_ID__C", "AccountSource", "Account_External_HPM_SF_ID__c", "Account_Sync_Status__c", "BillingCity", "BillingCountry", "BillingGeocodeAccuracy", "BillingLatitude", "BillingLongitude", "BillingPostalCode", "BillingState", "BillingStreet", "CreatedById", "CreatedDate", "Description", "Id", "Industry", "IsDeleted", "Jigsaw", "JigsawCompanyId", "LastActivityDate", "LastModifiedById", "LastModifiedDate", "LastReferencedDate", "LastViewedDate", "MasterRecordId", "Name", "NumberOfEmployees", "OwnerId", "ParentId", "Phone", "PhotoUrl", "RecordTypeId", "ShippingCity", "ShippingCountry", "ShippingGeocodeAccuracy", "ShippingLatitude", "ShippingLongitude", "ShippingPostalCode", "ShippingState", "ShippingStreet", "SicDesc", "SystemModstamp", "Type", "Website", "ACTIVEFROMDATE", "ACTIVETODATE", "RECORDNUMBER"]

        for col in history_insert_cols:
            rulequerydoc.newline(f"\t{col},")

        rulequerydoc.trimend(1)

        rulequerydoc.newline(")")
        rulequerydoc.newline("VALUES (")


        for col in history_insert_cols:
            if col == "DWINSERTDATE" or col == "DWUPDATEDATE" or col == "ACTIVEFROMDATE":
                rulequerydoc.newline("\tCURRENT_TIMESTAMP(),")
            elif col == "ACTIVETODATE":
                rulequerydoc.newline("\tTRY_TO_TIMESTAMP('2999-12-31'),")
            elif col == "RECORDNUMBER":
                rulequerydoc.newline("\tNULL")
            else:
                rulequerydoc.newline(f"\tSRC.{col},")

        rulequerydoc.newline(");")

        # write out Rule Query to file
        filewrite(output_folder, "SalesforceAccount_4_4 MERGE INTO SALESFORCEACCOUNT HISTORY RULE QUERY.sql",
                  rulequerydoc.out())

        busrule["RULEQUERY"] = rulequerydoc.out_str()

        json_busrule = json.dumps(busrule, indent=2, separators=(", ", ": "))

        busrules_obj.add_rule(json_busrule)

        # ----------------------------------------------------------------
        # Rule 5_4
        # ----------------------------------------------------------------
        busrule = {}
        busrule["RULENAME"] = "SalesforceAccount_5_4"
        busrule["RUNORDER"] = 5
        busrule["RUNPOSITION"] = 4

        rulequerydoc = Document()
        rulequerydoc.append("UPDATE &database.STAGE.SALESFORCEACCOUNT_HISTORY TAR")
        rulequerydoc.newline("SET")
        rulequerydoc.newline("\tTAR.RECORDNUMBER = SRC.RECORDNUMBER_NEW")
        rulequerydoc.newline("FROM (")
        rulequerydoc.newline("\tSELECT")

        for col in history_select_list:
            rulequerydoc.newline(f"\t\t{col},")

        rulequerydoc.newline("\t\tROW_NUMBER() OVER (")
        rulequerydoc.newline("\t\t\tPARTITION BY ID")
        rulequerydoc.newline("\t\t\tORDER BY")
        rulequerydoc.newline("\t\t\t\tDATE_TRUNC(SECOND, ACTIVEFROMDATE) DESC,")
        rulequerydoc.newline("\t\t\t\tDWINSERTDATE DESC,")
        rulequerydoc.newline("\t\t\t\tDWUPDATEDATE DESC")
        rulequerydoc.newline("\t\t) AS RECORDNUMBER_NEW")
        rulequerydoc.newline("\tFROM")
        rulequerydoc.newline("\t\t&database.STAGE.SALESFORCEACCOUNT_HISTORY")
        rulequerydoc.newline("\t) SRC")
        rulequerydoc.newline("WHERE")

        for col in history_select_list:
            rulequerydoc.newline(f"TAR.{col} = SRC.{col} AND")

        rulequerydoc.trimend(4)
        rulequerydoc.newline(";")

        # write out Rule Query to file
        filewrite(output_folder, "SalesforceAccount_5_4 UPDATE SALESFORCEACCOUNT HISTORY RULE QUERY.sql", rulequerydoc.out())

        busrule["RULEQUERY"] = rulequerydoc.out_str()

        json_busrule = json.dumps(busrule, indent=2, separators=(", ", ": "))

        busrules_obj.add_rule(json_busrule)


    # ----------------------------------------------------------------
    # CONTACT
    # ----------------------------------------------------------------
    if sf_obj.upper() == "CONTACT":
        output_folder = f"{database_folder}ForReferenceOnly{os.sep}SalesforceContact_BusRules{os.sep}"
        tracelog.log("Generate Salesforce Contact Business Rules.")
        tracelog.log("")


    # ----------------------------------------------------------------
    # LEAD
    # ----------------------------------------------------------------
    if sf_obj.upper() == "LEAD":
        output_folder = f"{database_folder}ForReferenceOnly{os.sep}SalesforceLead_BusRules{os.sep}"
        tracelog.log("Generate Salesforce Lead Business Rules.")
        tracelog.log("")


    tracelog.log("")
    return
