To Use IngestConfigCreator, you can just run

    python .\IngestConfigCreator.py

and enter the parameter values as prompted.

Any required parameters that are not provided will be re-prompted.

The output report will contain a command with the parameters provided as arguments for future runs.