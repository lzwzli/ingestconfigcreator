import sys, os
sys.path.append("..")
from IngestConfigCreatorLibrary_Functions import *
from IngestConfigCreatorLibrary_Classes import *
from importlib import import_module

need_flatten = 0
# ----------------------------------------------------------------
# Create Flatten Insert File
# ----------------------------------------------------------------

# Create FLATTENJSON CTE for use in Flatten SQL Insert query
# contact
def flattenjson_contacts(table_name, table_name_raw, column_list):
    jsonelements = []
    flattendoc = Document()
    # create JSON elements list
    for col in column_list:
        jsonelements.append(f"\t\tSTRIP_NULL_VALUE(raw.JSONDATA:{col[0]})::varchar AS {col[1].upper()}")

    flattendoc.append("\tSELECT")
    flattendoc.newline("\t\traw.FILEDATE,")
    flattendoc.newline("\t\traw.FILENAME,")
    flattendoc.newline("\t\traw.FILEROWNUMBER,")
    flattendoc.newlinelist(jsonelements)
    flattendoc.append(",")
    flattendoc.newline("\t\traw.DW_CREATED_DATE,")
    flattendoc.newline("\t\traw.DW_CREATED_BY")
    flattendoc.newline(f"\tFROM (")
    flattendoc.newline(f"\t\tSELECT *")
    flattendoc.newline(f"\t\tFROM &database.IMPORT.{table_name_raw}")
    flattendoc.newline(f"\t\tWHERE")
    flattendoc.newline("\t\t\tTO_TIMESTAMP(RPAD(FILEDATE,14,'0'), 'YYYYMMDDHH24MISS') >")
    flattendoc.newline("\t\t\t(")
    flattendoc.newline(f"\t\t\t\tSELECT IFNULL(MAX(TO_TIMESTAMP(RPAD(FILEDATE,14,'0'), 'YYYYMMDDHH24MISS')),TO_TIMESTAMP('1900-01-01'))")
    flattendoc.newline(f"\t\t\t\tFROM &database.STAGE.{table_name}")
    flattendoc.newline("\t\t\t)")
    flattendoc.newline("\t\t\tAND JSONDATA <> '{}'")
    flattendoc.newline("\t) raw")

    return flattendoc.out()

# survey definitions
def flattenjson_surveydefinitions(table_name, table_name_raw, column_list):
    jsonelements = []
    flattendoc = Document()
    # create JSON elements list
    for col in column_list:
        jsonelements.append(f"\t\tSTRIP_NULL_VALUE(GET_PATH(JSONDATA:json:result,'{col[0]}')) AS {col[1].upper()}")

    flattendoc.append("\tSELECT")
    flattendoc.newline("\t\traw.FILEDATE,")
    flattendoc.newline("\t\traw.FILENAME,")
    flattendoc.newline("\t\traw.FILEROWNUMBER,")
    flattendoc.newlinelist(jsonelements)
    flattendoc.append(",")
    flattendoc.newline("\t\traw.DW_CREATED_DATE,")
    flattendoc.newline("\t\traw.DW_CREATED_BY")
    flattendoc.newline(f"\tFROM (")
    flattendoc.newline(f"\t\tSELECT *")
    flattendoc.newline(f"\t\tFROM &database.IMPORT.{table_name_raw}")
    flattendoc.newline(f"\t\tWHERE")
    flattendoc.newline("\t\t\tTO_TIMESTAMP(RPAD(FILEDATE,14,'0'), 'YYYYMMDDHH24MISS') >")
    flattendoc.newline("\t\t\t(")
    flattendoc.newline(f"\t\t\t\tSELECT IFNULL(MAX(TO_TIMESTAMP(RPAD(FILEDATE,14,'0'), 'YYYYMMDDHH24MISS')),TO_TIMESTAMP('1900-01-01'))")
    flattendoc.newline(f"\t\t\t\tFROM &database.STAGE.{table_name}")
    flattendoc.newline("\t\t\t)")
    flattendoc.newline("\t) raw")

    return flattendoc.out()

# survey questions
def flattenjson_surveyquestions(table_name, table_name_raw, column_list):
    jsonelements = []
    flattendoc = Document()
    # create JSON elements list
    for col in column_list:
        if col[1].upper() == "SURVEYID":
            jsonelements.append(f"\t\tSTRIP_NULL_VALUE(JSONDATA:json:result:{col[0]}) AS {col[1].upper()}")
        elif col[1].upper() == "DATAEXPORTTAG" or col[1].upper() == "QUESTIONTYPE" or col[1].upper() == "SELECTOR" or col[1].upper() == "SUBSELECTOR":
            jsonelements.append(f"\t\tSTRIP_NULL_VALUE(questions.value:{col[0]}) :: varchar AS {col[1].upper()}")
        elif col[1].upper() == "QUESTIONID":
            jsonelements.append(f"\t\tCASE\n\t\t\tWHEN STRIP_NULL_VALUE (questions.value:QuestionType) :: varchar = 'Matrix' OR STRIP_NULL_VALUE (questions.value:QuestionType) :: varchar = 'MC'\n\t\t\tTHEN COALESCE(questions.key||'_'||choices.key, questions.key, 'N/A')\n\t\t\tELSE\n\t\t\t\tCASE\n\t\t\t\t\tWHEN STRIP_NULL_VALUE (questions.value:QuestionType) :: varchar = 'PGR'\n\t\t\t\t\tTHEN COALESCE(questions.key||'_0_GROUP', 'N/A')\n\t\t\t\t\tELSE IFNULL(questions.key,'N/A')\n\t\t\t\tEND\n\t\tEND AS QUESTIONID")
        elif col[1].upper() == "QUESTIONTEXT":
            jsonelements.append(f"\t\tCASE\n\t\t\tWHEN STRIP_NULL_VALUE (questions.value:QuestionType) :: varchar = 'Matrix' OR STRIP_NULL_VALUE (questions.value:QuestionType) :: varchar = 'MC'\n\t\t\tTHEN STRIP_NULL_VALUE (questions.value:QuestionDescription) || ' ' || REGEXP_REPLACE(REGEXP_REPLACE(STRIP_NULL_VALUE (choices.value:Display) :: varchar, '</.*?>' ) , '<.*?>', ' ' )\n\t\t\tELSE STRIP_NULL_VALUE (questions.value:QuestionDescription)\n\t\tEND AS QUESTIONTEXT")
        else:
            jsonelements.append(f"\t\tnull AS {col[1].upper()}")

    flattendoc.append("\tSELECT")
    flattendoc.newline("\t\traw.FILEDATE,")
    flattendoc.newline("\t\traw.FILENAME,")
    flattendoc.newline("\t\traw.FILEROWNUMBER,")
    flattendoc.newlinelist(jsonelements)
    flattendoc.append(",")
    flattendoc.newline("\t\traw.DW_CREATED_DATE,")
    flattendoc.newline("\t\traw.DW_CREATED_BY")
    flattendoc.newline(f"\tFROM (")
    flattendoc.newline(f"\t\tSELECT *")
    flattendoc.newline(f"\t\tFROM &database.IMPORT.QUALTRICSSURVEYDEFINITIONS_RAW")
    flattendoc.newline(f"\t\tWHERE")
    flattendoc.newline("\t\t\tTO_TIMESTAMP(RPAD(FILEDATE,14,'0'), 'YYYYMMDDHH24MISS') >")
    flattendoc.newline("\t\t\t(")
    flattendoc.newline(f"\t\t\t\tSELECT IFNULL(MAX(TO_TIMESTAMP(RPAD(FILEDATE,14,'0'), 'YYYYMMDDHH24MISS')),TO_TIMESTAMP('1900-01-01'))")
    flattendoc.newline(f"\t\t\t\tFROM &database.STAGE.{table_name}")
    flattendoc.newline("\t\t\t)")
    flattendoc.newline("\t) raw, LATERAL flatten(JSONDATA:json:result:Questions) questions, TABLE(flatten(INPUT => questions.value:Choices, OUTER => TRUE)) choices")

    return flattendoc.out()

# survey responses
def flattenjson_surveyresponses(table_name, table_name_raw, column_list):
    jsonelements = []
    flattendoc = Document()
    # create JSON elements list
    for col in column_list:
        if col[1].upper() == "RESPONSEID":
            jsonelements.append(f"\t\tSTRIP_NULL_VALUE(raw.JSONDATA:{col[0]}) AS {col[1].upper()}")
        elif col[1].upper() == "STARTDATE" or col[1].upper() == "ENDDATE" or col[1].upper() == "STATUS" or col[1].upper() == "IPADDRESS" or col[1].upper() == "PROGRESS" or col[1].upper() == "DURATION" or col[1].upper() == "FINISHED" or col[1].upper() == "RECORDEDDATE" or col[1].upper() == "LOCATIONLATITUDE" or col[1].upper() == "LOCATIONLONGITUDE" or col[1].upper() == "USERLANGUAGE" or col[1].upper() == "EMAILID":
            jsonelements.append(f"\t\tSTRIP_NULL_VALUE(raw.JSONDATA:values:{col[0]}) :: {col[2]} AS {col[1].upper()}")
        elif col[1].upper() == "SURVEYID":
            jsonelements.append(f"\t\tSPLIT_PART(SPLIT_PART(raw.FILENAME, '/', -1), '-', 3) AS {col[1].upper()}")
        elif col[1].upper() == "QUESTIONRESPONSE":
            jsonelements.append(f"\t\tCASE\n\t\t\tWHEN SPLIT_PART (fvalues.path, '[', 1) :: varchar ILIKE '%_TEXT'\n\t\t\tTHEN STRIP_NULL_VALUE (COALESCE(values_flat.value, fvalues.value)) :: varchar\n\t\t\tELSE STRIP_NULL_VALUE (COALESCE(labels_flat.value, labels.value)) :: varchar\n\t\tEND AS QUESTIONRESPONSE")
        elif col[1].upper() == "QUESTIONID":
            jsonelements.append(f"\t\tCASE\n\t\t\tWHEN SPLIT_PART (fvalues.path, '[', 1) :: varchar ILIKE 'QID%'\n\t\t\tTHEN\n\t\t\t\tCASE\n\t\t\t\t\tWHEN SPLIT_PART (fvalues.path, '[', 1) :: varchar ILIKE '%_TEXT'\n\t\t\t\t\tTHEN REPLACE ( SPLIT_PART (fvalues.path, '[', 1), '_TEXT' ) :: varchar\n\t\t\t\t\tELSE REPLACE ( SPLIT_PART (fvalues.path, '[', 1), '_NPS_GROUP' ) :: varchar\n\t\t\t\tEND\n\t\t\tELSE REPLACE ( SPLIT_PART (labels.path, '[', 1), '_NPS_GROUP' ) :: varchar\n\t\tEND AS QUESTIONID")

    flattendoc.append("\tSELECT")
    flattendoc.newline("\t\traw.FILEDATE,")
    flattendoc.newline("\t\traw.FILENAME,")
    flattendoc.newline("\t\traw.FILEROWNUMBER,")
    flattendoc.newlinelist(jsonelements)
    flattendoc.append(",")
    flattendoc.newline("\t\traw.DW_CREATED_DATE,")
    flattendoc.newline("\t\traw.DW_CREATED_BY")
    flattendoc.newline(f"\tFROM")
    flattendoc.newline(f"\t\t&database.IMPORT.{table_name_raw} raw,")
    flattendoc.newline("\t\tTABLE(FLATTEN (INPUT => raw.JSONDATA:labels)) labels,")
    flattendoc.newline("\t\tTABLE(FLATTEN (INPUT => labels.value, OUTER => TRUE )) labels_flat,")
    flattendoc.newline("\t\tTABLE(FLATTEN (INPUT => raw.JSONDATA:values)) fvalues,")
    flattendoc.newline("\t\tTABLE(FLATTEN (INPUT => fvalues.value, OUTER => TRUE )) values_flat")
    flattendoc.newline("\tWHERE")
    flattendoc.newline("\t\tTO_TIMESTAMP(RPAD(FILEDATE,14,'0'), 'YYYYMMDDHH24MISS') >")
    flattendoc.newline("\t\t(")
    flattendoc.newline(f"\t\t\tSELECT IFNULL(MAX(TO_TIMESTAMP(RPAD(FILEDATE,14,'0'), 'YYYYMMDDHH24MISS')),TO_TIMESTAMP('1900-01-01'))")
    flattendoc.newline(f"\t\t\tFROM &database.STAGE.{table_name}")
    flattendoc.newline("\t\t)")
    flattendoc.newline("\t\tAND raw.JSONDATA <> '{}'")
    flattendoc.newline("\t\tAND QUESTIONID ilike 'QI%'")



    return flattendoc.out()

# create flatten
def create_flatten(source_name:str, table_name:str, table_name_raw:str, column_list:list, version:str, db_folder:str, tracelog:object, isPrefect=0):
    # initialize Flatten Document
    Flatten = Document()
    insertcolumns = []

    # create column list for insert and json sections
    for col in column_list:
        insertcolumns.append(f"\t{col[1].upper()}")

    # initialize elements of insert statement
    Flatten.append(f"/*{table_name} Flatten Insert version={version} generated by config generator */")
    Flatten.newline(f"INSERT INTO &database.IMPORT.{table_name}")
    Flatten.newline("(")
    Flatten.newline("\tFILEDATE,")
    Flatten.newline("\tFILENAME,")
    Flatten.newline("\tFILEROWNUMBER,")
    Flatten.newlinelist(insertcolumns)
    Flatten.append(",")
    Flatten.newline("\tDW_CREATED_DATE,")
    Flatten.newline("\tDW_CREATED_BY")
    Flatten.newline(")")
    Flatten.newline(f"WITH FLATTENJSON AS")
    Flatten.newline("(")
    if table_name.upper()=="QUALTRICSCONTACTS":
        Flatten.newline(flattenjson_contacts(table_name, table_name_raw, column_list))
    elif table_name.upper()=="QUALTRICSSURVEYDEFINITIONS":
        Flatten.newline(flattenjson_surveydefinitions(table_name, table_name_raw, column_list))
    elif table_name.upper()=="QUALTRICSSURVEYQUESTIONS":
        Flatten.newline(flattenjson_surveyquestions(table_name, table_name_raw, column_list))
    elif table_name.upper()=="QUALTRICSSURVEYRESPONSES":
        Flatten.newline(flattenjson_surveyresponses(table_name, table_name_raw, column_list))
    Flatten.newline(")")
    Flatten.newline("SELECT")
    Flatten.newline("\tFILEDATE,")
    Flatten.newline("\tFILENAME,")
    Flatten.newline("\tFILEROWNUMBER,")
    Flatten.newlinelist(insertcolumns)
    Flatten.append(",")
    Flatten.newline("\tDW_CREATED_DATE,")
    Flatten.newline("\tDW_CREATED_BY")
    Flatten.newline("FROM FLATTENJSON;")

    # define output folder and filename
    output_folder = f"{db_folder}masterimport{os.sep}sources{os.sep}"
    if isPrefect == 0:
        filename = f"{table_name.upper()}_FLATTEN.sql"
    else:
        filename = f"{table_name.lower()}-flatten.sql"

    # write flatten insert to file
    filewrite(output_folder, filename, Flatten.out())

    # trace log
    print_section_detail(f"FLATTEN - {filename}\nCreated in: {output_folder}", tracelog)

    return filename

# ----------------------------------------------------------------
# Create CopyInto File
# ----------------------------------------------------------------
def fn_create_copyinto_custom(client:str, source_name:str, table_name:str, column_list:list, file_match_text:str, filedate_regex:str, field_delimiter:str, version:str, database_folder:str, tracelog:object, field_enclosed_by:str, custom_fileformat_options:str, isPrefect=0):

    # create Flatten
    create_flatten(source_name, table_name, f"{table_name}_RAW", column_list, version, database_folder, tracelog, 1)

    if table_name.upper() == "QUALTRICSSURVEYQUESTIONS":
        return "null"
    else:
        # initialize CopyInto Document
        CopyInto = Document()

        # format custom_fileformat_options
        custom_fileformat_options = custom_fileformat_options.strip()

        if custom_fileformat_options == "None":
            custom_fileformat_options = ""
        elif custom_fileformat_options != '':
            custom_fileformat_options = f" {custom_fileformat_options}"
        else:
            custom_fileformat_options = ""

        # define stage location path
        stage_location = f"@&database.IMPORT.IMPORTSTAGING/{source_name.capitalize()}/&database"

        # initialize elements of the CopyInto statement
        CopyInto.append(f"/*{table_name} Copy Into version={version} generated by config generator */")
        CopyInto.newline(f"COPY INTO &database.IMPORT.{table_name}_RAW")
        CopyInto.newline("(")
        CopyInto.newline("\tFILEDATE,")
        CopyInto.newline("\tFILENAME,")
        CopyInto.newline("\tFILEROWNUMBER,")
        CopyInto.newline("\tJSONDATA")
        CopyInto.newline(")")
        CopyInto.newline("FROM")
        CopyInto.newline("(")
        CopyInto.newline("\tSELECT")
        CopyInto.newline(f"\t\tREPLACE(REGEXP_SUBSTR(METADATA$filename, '{filedate_regex}', 1, 1), '-', '') FILEDATE,")
        CopyInto.newline("\t\tMETADATA$FILENAME,")
        CopyInto.newline("\t\tMETADATA$FILE_ROW_NUMBER,")
        CopyInto.newline("\t\tPARSE_JSON(T.\"$1\") AS JSONDATA")
        CopyInto.newline("\tFROM ")
        CopyInto.append(f"{stage_location} T")
        CopyInto.newline(")")
        CopyInto.newline(f"PATTERN = '{client.upper()}/{source_name.capitalize()}/&database/{file_match_text}'")
        CopyInto.newline("ON_ERROR = CONTINUE")
        CopyInto.newline("FORCE = FALSE")
        CopyInto.newline("LOAD_UNCERTAIN_FILES = TRUE")
        CopyInto.newline(f"FILE_FORMAT = (TYPE = JSON{custom_fileformat_options})")
        CopyInto.newline(";")

        # define output folder and filename
        output_folder = f"{database_folder}masterimport{os.sep}sources{os.sep}"
        if isPrefect == 0:
            filename = f"{table_name.upper()}_COPYINTO.sql"
        else:
            filename = f"{table_name.lower()}-copy.sql"

        # write copyinto to file
        filewrite(output_folder, filename, CopyInto.out())

        # trace log
        print_section_detail(f"COPYINTO - {filename}\nCreated in: {output_folder}", tracelog)

        tracelog.log("")

        return filename

# ----------------------------------------------------------------
# Create Import DDL
# ----------------------------------------------------------------
def fn_create_import_DDL_custom(table_name:str, column_list:list, version:str, db_folder:str, tracelog:object):
    #----------
    # Import Raw
    #----------
    # initialize Import DDL Document
    ImportDDL_Raw = Document()

    # create complete import DDL per table
    ImportDDL_Raw.append(f"/*{table_name}_RAW (Import) grantObjectName={table_name}_RAW version={version} generated by config generator */")
    ImportDDL_Raw.newline(f"CREATE OR REPLACE TABLE IMPORT.{table_name}_RAW")
    ImportDDL_Raw.newline("(")
    ImportDDL_Raw.newline("\tFILEDATE\tVARCHAR(16777216),")
    ImportDDL_Raw.newline("\tFILENAME\tVARCHAR(16777216),")
    ImportDDL_Raw.newline("\tFILEROWNUMBER\tNUMBER(38, 0),")
    ImportDDL_Raw.newline("\tJSONDATA\tVARIANT,")
    ImportDDL_Raw.newline("\tDW_CREATED_DATE\tTIMESTAMP_LTZ\tNOT NULL DEFAULT CURRENT_TIMESTAMP(),")
    ImportDDL_Raw.newline("\tDW_CREATED_BY\tVARCHAR(100)\tNOT NULL DEFAULT CURRENT_USER()")
    ImportDDL_Raw.newline(");")

    # define output folder and filename
    output_folder = f"{db_folder}data_tables{os.sep}import{os.sep}"
    filename = f"{table_name.upper()}_RAW.sql"

    # write import DDL to file
    filewrite(output_folder, filename, ImportDDL_Raw.out())

    # trace log
    print_section_detail(f"IMPORT RAW DDL - {filename}\nCreated in: {output_folder}", tracelog)

    #----------
    # Import
    #----------
    # initialize Import DDL Document
    ImportDDL = Document()

    # IMPORT - read column list and create column list for table creation
    importcolumns = getDDLcolumns(column_list, "import")

    # create complete import DDL per table
    ImportDDL.append(
        f"/*{table_name} (Import) grantObjectName={table_name} version={version} generated by config generator */")
    ImportDDL.newline(f"CREATE OR REPLACE TABLE IMPORT.{table_name}")
    ImportDDL.newline("(")
    ImportDDL.newline("\tFILEDATE\tVARCHAR(16777216),")
    ImportDDL.newline("\tFILENAME\tVARCHAR(16777216),")
    ImportDDL.newline("\tFILEROWNUMBER\tNUMBER(38, 0),")
    ImportDDL.newlinelist(importcolumns)
    ImportDDL.append(",")
    ImportDDL.newline("\tDW_CREATED_DATE\tTIMESTAMP_LTZ\tNOT NULL,")
    ImportDDL.newline("\tDW_CREATED_BY\tVARCHAR(100)\tNOT NULL")
    ImportDDL.newline(");")

    # define output folder and filename
    output_folder = f"{db_folder}data_tables{os.sep}import{os.sep}"
    filename = f"{table_name.upper()}.sql"

    # write import DDL to file
    filewrite(output_folder, filename, ImportDDL.out())

    # trace log
    print_section_detail(f"IMPORT DDL - {filename}\nCreated in: {output_folder}", tracelog)

    return

# ----------------------------------------------------------------
# Append File Transfers
# ----------------------------------------------------------------
def fn_file_transfers_append(file_transfers_obj:object, client_project:str, tracelog:object):
    tracelog.log("Running Qualtrics specific file_transfers append function")

    # file_transfers_obj.append("MASTERSCHEDULE", f"../Shared_Qualtrics_V1.0.0/Qualtrics_Import_Master")

    tracelog.log("")
    return

# ----------------------------------------------------------------
# Sources Append
# ----------------------------------------------------------------
def fn_sources_append(worksheet:object, database_folder:str, sources_obj:object, tracelog:object, isPrefect=0):
    tracelog.log("Running Qualtrics specific sources append function")

    # get table name
    table_name = worksheet.table_name()
    if isPrefect == 0:
        sources_obj.replace("GETLASTDATEINDICATOR", 0)
        sources_obj.append("DAYSBACK", 0)
        sources_obj.append("REFRESH", 0)
        sources_obj.append("SCHEMA", "Stage")
        sources_obj.append("SEASONYEARINDICATOR", 0)
        sources_obj.append("WHERECLAUSE", "")

    if table_name.upper() == "QUALTRICSSURVEYQUESTIONS" or table_name.upper() == "QUALTRICSSURVEYDEFINITIONS":
        if isPrefect == 0:
            sources_obj.append("LASTDATECOLNAME", None)
            sources_obj.append("ROWCOUNTCHECKOVERRIDE", 1)
        else:
            sources_obj.append("rowCountCheckOverride", 1)

    elif table_name.upper() == "QUALTRICSSURVEYRESPONSES":
        if isPrefect == 0:
            sources_obj.append("LASTDATECOLNAME", "DWUPDATEDATE")
            sources_obj.append("ROWCOUNTCHECKOVERRIDE", 1)
        else:
            sources_obj.replace("getLastDateIndicator", True)
            sources_obj.append("rowCountCheckOverride", 1)

            # define getLastDateProperties values
            getLastDateProperties = {}
            getLastDateProperties["daysBack"] = 0
            getLastDateProperties["lastDateColumn"] = "DWUPDATEDATE"
            getLastDateProperties["refresh"] = 0
            getLastDateProperties["schema"] = "stage"
            getLastDateProperties["seasonYearIndicator"] = 0
            getLastDateProperties["whereClause"] = ""
            getLastDateProperties["tableName"] = table_name
            sources_obj.append("getLastDateProperties", getLastDateProperties)
    else:
        if isPrefect == 0:
            sources_obj.append("LASTDATECOLNAME", None)

    if isPrefect == 0:
        flatten_filename = f"{table_name.upper()}_FLATTEN.sql"
    else:
        flatten_filename = f"{table_name.lower()}-flatten.sql"

    if table_name.upper() == "QUALTRICSSURVEYDEFINITIONS":
        if isPrefect == 0:
            sources_obj.append("STAGE_SQL", f"{flatten_filename}, QUALTRICSSURVEYQUESTIONS_FLATTEN.sql")
        else:
            sources_obj.append("importSql", [{"sortOrder": 2, "sqlFileName": flatten_filename}, {"sortOrder": 3, "sqlFileName": "qualtricssurveyquestions-flatten.sql"}])

    else:
        if isPrefect == 0:
            sources_obj.append("STAGE_SQL", flatten_filename)
        else:
            sources_obj.append("importSql", [{"sortOrder": 2, "sqlFileName": flatten_filename}])

    tracelog.log("")

    return