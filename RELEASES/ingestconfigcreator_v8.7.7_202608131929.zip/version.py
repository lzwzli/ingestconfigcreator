version = "8.7.7"
releasedate = "2026-08-13"
