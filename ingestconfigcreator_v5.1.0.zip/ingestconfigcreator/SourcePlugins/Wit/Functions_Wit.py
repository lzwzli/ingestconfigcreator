import sys, os
sys.path.append("..")
from IngestConfigCreatorLibrary_Functions import *
from IngestConfigCreatorLibrary_Classes import *
from importlib import import_module

# ----------------------------------------------------------------
# Sources Append
# ----------------------------------------------------------------
def fn_sources_append(worksheet:object, database_folder:str, sources_obj:object, tracelog:object, isPrefect=0):
    tracelog.log("Running WIT specific sources append function")

    # get table name
    if isPrefect == 0:
        table_name = worksheet.table_name()
    else:
        table_name = worksheet.table_name().lower()

    if table_name.upper() == "WITENTRIES":
        if isPrefect == 0:
            sources_obj.append("ROWCOUNTCHECKOVERRIDE", 1)
        else:
            sources_obj.append("rowCountCheckOverride", 1)

    elif table_name.upper() == "WITLISTS":
        if isPrefect == 0:
            sources_obj.append("STAGE_SQL", "WITENTRIES_FLATTEN.sql, WITLISTS_FLATTEN.sql")

    tracelog.log("")

    return